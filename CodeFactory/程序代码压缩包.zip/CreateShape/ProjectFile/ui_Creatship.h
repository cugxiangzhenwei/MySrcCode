/********************************************************************************
** Form generated from reading UI file 'Creatship.ui'
**
** Created: Sat Sep 24 02:21:49 2011
**      by: Qt User Interface Compiler version 4.7.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CREATSHIP_H
#define UI_CREATSHIP_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QGroupBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>

QT_BEGIN_NAMESPACE

class Ui_CreatShip
{
public:
    QLineEdit *RasterName;
    QLineEdit *ShapName;
    QPushButton *OpenRasterBtn;
    QPushButton *SaveShapeBtn;
    QLabel *labelRows;
    QLabel *labelCols;
    QPushButton *CreateBtn;
    QPushButton *CancelBtn;
    QGroupBox *groupBox;
    QSpinBox *SpinBoxRows;
    QSpinBox *SpinBoxCols;
    QGroupBox *groupBox_2;
    QGroupBox *groupBox_3;

    void setupUi(QDialog *CreatShip)
    {
        if (CreatShip->objectName().isEmpty())
            CreatShip->setObjectName(QString::fromUtf8("CreatShip"));
        CreatShip->resize(382, 295);
        CreatShip->setStyleSheet(QString::fromUtf8("background-color: rgb(225, 255, 206);"));
        RasterName = new QLineEdit(CreatShip);
        RasterName->setObjectName(QString::fromUtf8("RasterName"));
        RasterName->setGeometry(QRect(20, 30, 231, 31));
        RasterName->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 255, 255);\n"
"font: 11pt \"\345\256\213\344\275\223\";"));
        ShapName = new QLineEdit(CreatShip);
        ShapName->setObjectName(QString::fromUtf8("ShapName"));
        ShapName->setGeometry(QRect(22, 80, 231, 31));
        ShapName->setStyleSheet(QString::fromUtf8("background-color: rgb(170, 255, 255);\n"
"font: 11pt \"\345\256\213\344\275\223\";"));
        OpenRasterBtn = new QPushButton(CreatShip);
        OpenRasterBtn->setObjectName(QString::fromUtf8("OpenRasterBtn"));
        OpenRasterBtn->setGeometry(QRect(270, 30, 75, 31));
        OpenRasterBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 210, 246);\n"
"font: 11pt \"\345\256\213\344\275\223\";"));
        SaveShapeBtn = new QPushButton(CreatShip);
        SaveShapeBtn->setObjectName(QString::fromUtf8("SaveShapeBtn"));
        SaveShapeBtn->setGeometry(QRect(270, 80, 75, 31));
        SaveShapeBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 210, 246);\n"
"font: 11pt \"\345\256\213\344\275\223\";"));
        labelRows = new QLabel(CreatShip);
        labelRows->setObjectName(QString::fromUtf8("labelRows"));
        labelRows->setGeometry(QRect(40, 170, 71, 31));
        labelRows->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\256\213\344\275\223\";"));
        labelCols = new QLabel(CreatShip);
        labelCols->setObjectName(QString::fromUtf8("labelCols"));
        labelCols->setGeometry(QRect(200, 180, 61, 16));
        labelCols->setStyleSheet(QString::fromUtf8("font: 11pt \"\345\256\213\344\275\223\";"));
        CreateBtn = new QPushButton(CreatShip);
        CreateBtn->setObjectName(QString::fromUtf8("CreateBtn"));
        CreateBtn->setGeometry(QRect(50, 230, 75, 31));
        CreateBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 210, 246);\n"
"font: 11pt \"\345\256\213\344\275\223\";"));
        CancelBtn = new QPushButton(CreatShip);
        CancelBtn->setObjectName(QString::fromUtf8("CancelBtn"));
        CancelBtn->setGeometry(QRect(230, 230, 75, 31));
        CancelBtn->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 210, 246);\n"
"font: 11pt \"\345\256\213\344\275\223\";"));
        groupBox = new QGroupBox(CreatShip);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(10, 140, 351, 71));
        SpinBoxRows = new QSpinBox(groupBox);
        SpinBoxRows->setObjectName(QString::fromUtf8("SpinBoxRows"));
        SpinBoxRows->setGeometry(QRect(101, 31, 61, 21));
        SpinBoxRows->setFrame(true);
        SpinBoxRows->setAlignment(Qt::AlignCenter);
        SpinBoxRows->setKeyboardTracking(true);
        SpinBoxRows->setMinimum(1);
        SpinBoxRows->setMaximum(100);
        SpinBoxRows->setProperty("RowsFilter", QVariant(0u));
        SpinBoxCols = new QSpinBox(groupBox);
        SpinBoxCols->setObjectName(QString::fromUtf8("SpinBoxCols"));
        SpinBoxCols->setGeometry(QRect(270, 30, 51, 22));
        SpinBoxCols->setAlignment(Qt::AlignCenter);
        SpinBoxCols->setMinimum(1);
        SpinBoxCols->setMaximum(100);
        SpinBoxCols->setValue(1);
        SpinBoxCols->setProperty("FilterCols", QVariant(0u));
        groupBox_2 = new QGroupBox(CreatShip);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 10, 351, 121));
        groupBox_3 = new QGroupBox(CreatShip);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 220, 351, 51));
        groupBox_2->raise();
        groupBox_3->raise();
        groupBox->raise();
        SaveShapeBtn->raise();
        ShapName->raise();
        RasterName->raise();
        OpenRasterBtn->raise();
        labelRows->raise();
        labelCols->raise();
        CreateBtn->raise();
        CancelBtn->raise();

        retranslateUi(CreatShip);

        QMetaObject::connectSlotsByName(CreatShip);
    } // setupUi

    void retranslateUi(QDialog *CreatShip)
    {
        CreatShip->setWindowTitle(QApplication::translate("CreatShip", "\345\210\233\345\273\272\347\237\242\351\207\217\346\226\207\344\273\266", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        CreatShip->setToolTip(QString());
#endif // QT_NO_TOOLTIP
        OpenRasterBtn->setText(QApplication::translate("CreatShip", "\346\211\223\345\274\200\346\240\205\346\240\274", 0, QApplication::UnicodeUTF8));
        SaveShapeBtn->setText(QApplication::translate("CreatShip", "\344\277\235\345\255\230\347\237\242\351\207\217", 0, QApplication::UnicodeUTF8));
        labelRows->setText(QApplication::translate("CreatShip", "\345\210\222\345\210\206\350\241\214\346\225\260\357\274\232", 0, QApplication::UnicodeUTF8));
        labelCols->setText(QApplication::translate("CreatShip", "\345\210\222\345\210\206\345\210\227\346\225\260\357\274\232", 0, QApplication::UnicodeUTF8));
        CreateBtn->setText(QApplication::translate("CreatShip", "\345\210\233\345\273\272", 0, QApplication::UnicodeUTF8));
        CancelBtn->setText(QApplication::translate("CreatShip", "\345\217\226\346\266\210", 0, QApplication::UnicodeUTF8));
        groupBox->setTitle(QApplication::translate("CreatShip", "\345\210\222\345\210\206\350\241\214\345\210\227\346\225\260", 0, QApplication::UnicodeUTF8));
        SpinBoxRows->setSuffix(QString());
        groupBox_2->setTitle(QString());
        groupBox_3->setTitle(QString());
    } // retranslateUi

};

namespace Ui {
    class CreatShip: public Ui_CreatShip {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CREATSHIP_H
