#include <QApplication>
#include "standarddialog.h"
int main(int argc,char *argv[])
{
	QApplication app(argc,argv);
	CStandardDialog *pDlg=new CStandardDialog;
	pDlg->show();

	return app.exec();
}