//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RsProc.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_RSPROCTYPE                  129
#define IDD_SHOW_MODEL                  130
#define IDD_DIALOG_GREY                 132
#define IDD_DIALOG_COLOR                133
#define IDI_ICON1                       135
#define IDD_HIST_DLG                    136
#define IDC_TAB_SHOW_MODEL              1013
#define IDC_COMBO_GREY                  1016
#define IDC_COMBO_G                     1017
#define IDC_COMBO_B                     1018
#define IDC_STATIC_BAND_NUM             1020
#define IDC_COMBO_R                     1021
#define IDC_RADIO_R                     1022
#define IDC_RADIO_G                     1023
#define IDC_RADIO_B                     1024
#define IDC_STATIC_BAND_SEL             1025
#define ID_SHOW_MODEL                   32771
#define ID_HIST_SHOW                    32772
#define ID_HIST_EQUAL_SHOW              32773
#define ID_SELF_FIT_STRECT              32774
#define ID_Laplasian                    32776
#define ID_Sobel                        32777
#define ID_Laplasian_Outline            32778
#define ID_Sobel_Outline                32779
#define ID_32780                        32780
#define ID_PreWitt                      32781
#define ID_32782                        32782
#define ID_                             32783
#define ID_PrintScreen                  32784
#define ID_BUTTON32786                  32786
#define ID_MO                           32786
#define ID_32788                        32788
#define ID_32789                        32789
#define ID_32790                        32790
#define ID_32791                        32791
#define ID_32792                        32792
#define ID_32793                        32793
#define ID_TRANSLATION                  32794
#define ID_MIRROR                       32795
#define ID_Transpose                    32796
#define ID_Zoom                         32797
#define ID_Rotate                       32798
#define ID_32799                        32799
#define ID_MOVE_IMAGE                   32800

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32801
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
