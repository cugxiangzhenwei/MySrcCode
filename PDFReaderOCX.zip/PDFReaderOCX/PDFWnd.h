#pragma once

#include <atlbase.h>
#include <atlcom.h>
#import "..\\RadaeePDF\\Debug\\RadaeePDF.dll" no_namespace
#define WM_RATIO_CHANGED (WM_USER+3001)
#define WM_PAGE_CHANGED (WM_USER+3002)
#define WM_FINDING (WM_USER+3003)
#define WM_SAVING (WM_USER+3004)
#define WM_PRINTING (WM_USER+3005)
#define WM_SNAPSHOT (WM_USER+3006)
#define WM_URI (WM_USER+3007)

class CPDFBookmark : public COleDispatchDriver
{
public:
	CPDFBookmark(){} // ���� COleDispatchDriver Ĭ�Ϲ��캯��
	CPDFBookmark(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CPDFBookmark(const CPDFBookmark& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}

	// ����
public:

	// ����
public:


	// IPDFBookmark ����
public:
	LPDISPATCH get_child()
	{
		LPDISPATCH result;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, NULL);
		return result;
	}
	LPDISPATCH get_next()
	{
		LPDISPATCH result;
		InvokeHelper(0x2, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, NULL);
		return result;
	}
	CString get_label()
	{
		CString result;
		InvokeHelper(0x3, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
		return result;
	}
	long get_pageno()
	{
		long result;
		InvokeHelper(0x4, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	double get_top()
	{
		double result;
		InvokeHelper(0x5, DISPATCH_PROPERTYGET, VT_R8, (void*)&result, NULL);
		return result;
	}

	// IPDFBookmark ����
public:

};

class CPDFUrlBuffer : public COleDispatchDriver
{
public:
	//[id(1), helpstring("method open")] HRESULT open([in] BSTR url, [out,retval] VARIANT_BOOL* ret);
	//[propget, id(2), helpstring("property is_support_rc")] HRESULT is_support_rc([out, retval] VARIANT_BOOL* pVal);
	//[propget, id(3), helpstring("property file_size")] HRESULT file_size([out, retval] LONG* pVal);
	//[propget, id(4), helpstring("property total_read")] HRESULT total_read([out, retval] LONG* pVal);
	//[id(5), helpstring("method read")] HRESULT read(long size, [out,retval] LONG* ret);
	//[id(6), helpstring("method Close")] HRESULT Close(void);
public:
	CPDFUrlBuffer(){} // ���� COleDispatchDriver Ĭ�Ϲ��캯��
	CPDFUrlBuffer(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {}
	CPDFUrlBuffer(const CPDFUrlBuffer& dispatchSrc) : COleDispatchDriver(dispatchSrc) {}
	// ����
	void Create()
	{
		CreateDispatch( __uuidof(PDFUrlBuffer) );
	}
	// IPDFDocument ����
public:
	BOOL open(LPCTSTR url)
	{
		BOOL result;
		static BYTE parms[] = VTS_BSTR;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, url);
		return result;
	}
	long read(long size)
	{
		long result;
		static BYTE parms[] = VTS_I4;
		InvokeHelper(0x5, DISPATCH_METHOD, VT_I4, (void*)&result, parms, size);
		return result;
	}
	void close()
	{
		InvokeHelper(0x6, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	// IPDFDocument ����
public:
	BOOL get_is_support_rc()
	{
		BOOL result;
		InvokeHelper(0x2, DISPATCH_PROPERTYGET, VT_BOOL, (void*)&result, NULL);
		return result;
	}
	long get_file_size()
	{
		long result;
		InvokeHelper(0x3, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	long get_total_read()
	{
		long result;
		InvokeHelper(0x4, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
};


class CPDFDocument : public COleDispatchDriver,
	public IDispEventImpl<0, CPDFDocument, &__uuidof(_IPDFDocumentEvents), &__uuidof(__RadaeePDFLib), 1, 0>
{
public:
	CWnd *ownner;
BEGIN_SINK_MAP(CPDFDocument)
	SINK_ENTRY_EX(0, __uuidof(_IPDFDocumentEvents), 1, &OnPrinting)
	SINK_ENTRY_EX(0, __uuidof(_IPDFDocumentEvents), 2, &OnSaving)
	SINK_ENTRY_EX(0, __uuidof(_IPDFDocumentEvents), 3, &OnRenderEnd)
END_SINK_MAP()
	STDMETHOD(OnPrinting)( LONG page, LONG page_count )
	{
		if( ownner )
			ownner->PostMessage( WM_PRINTING, page, page_count );
		return S_OK;
	}
	STDMETHOD(OnSaving)( LONG page, LONG page_count )
	{
		if( ownner )
			ownner->PostMessage( WM_SAVING, page, page_count );
		return S_OK;
	}
	STDMETHOD(OnRenderEnd)( LONG page, LONG flag )
	{
		return S_OK;
	}
public:
	CPDFDocument(){ownner = NULL;} // ���� COleDispatchDriver Ĭ�Ϲ��캯��
	CPDFDocument(LPDISPATCH pDispatch) : COleDispatchDriver(pDispatch) {ownner = NULL;}
	CPDFDocument(const CPDFDocument& dispatchSrc) : COleDispatchDriver(dispatchSrc) {ownner = NULL;}
	// ����
	void Create()
	{
		CreateDispatch( __uuidof(PDFDocument) );
		DispEventAdvise( m_lpDispatch );
	}
public:

	// ����
public:


	// IPDFDocument ����
public:
	BOOL open(LPCTSTR filename, LPCTSTR password)
	{
		BOOL result;
		static BYTE parms[] = VTS_BSTR VTS_BSTR ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, filename, password);
		return result;
	}
	BOOL open_url(LPDISPATCH buf, LPCTSTR password)
	{
		BOOL result;
		static BYTE parms[] = VTS_DISPATCH VTS_BSTR ;
		InvokeHelper(0xe, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, buf, password);
		return result;
	}
	BOOL save_copy(LPCTSTR dest, BOOL rem_sec)
	{
		BOOL result;
		static BYTE parms[] = VTS_BSTR VTS_BOOL ;
		InvokeHelper(0xf, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, dest, rem_sec);
		return result;
	}
	BOOL save_page(LPCTSTR file_name, int pageno, double resx, double resy)
	{
		BOOL result;
		static BYTE parms[] = VTS_BSTR VTS_I4 VTS_R8 VTS_R8;
		InvokeHelper(0x16, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, file_name, pageno, resx, resy);
		return result;
	}
	void *save_page_mem(int pageno, double resx, double resy)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_R8 VTS_R8;
		InvokeHelper(0x17, DISPATCH_METHOD, VT_I4, (void*)&result, parms, pageno, resx, resy);
		return (void *)result;
	}
	void release_page_mem(void *data)
	{
		static BYTE parms[] = VTS_I4;
		InvokeHelper(0x18, DISPATCH_METHOD, VT_EMPTY, NULL, parms, data);
	}
	void close()
	{
		InvokeHelper(0x2, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	long get_page_count()
	{
		long result;
		InvokeHelper(0x3, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	long get_error_code()
	{
		long result;
		InvokeHelper(0x4, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	double get_page_width(long pageno)
	{
		double result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x5, DISPATCH_PROPERTYGET, VT_R8, (void*)&result, parms, pageno);
		return result;
	}
	double get_page_height(long pageno)
	{
		double result;
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x6, DISPATCH_PROPERTYGET, VT_R8, (void*)&result, parms, pageno);
		return result;
	}
	CString get_meta_data(LPCTSTR name)
	{
		CString result;
		static BYTE parms[] = VTS_BSTR ;
		InvokeHelper(0x7, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, parms, name);
		return result;
	}
	LPDISPATCH get_first_bookmark()
	{
		LPDISPATCH result;
		InvokeHelper(0x8, DISPATCH_METHOD, VT_DISPATCH, (void*)&result, NULL);
		return result;
	}
	long save_as(LPCTSTR filename, long type)
	{
		long result;
		static BYTE parms[] = VTS_BSTR VTS_I4 ;
		InvokeHelper(0x9, DISPATCH_METHOD, VT_I4, (void*)&result, parms, filename, type);
		return result;
	}
	long print(LPCTSTR title, long page_start, long page_end, double page_ratio, long copies, long align, long printer)
	{
		long result;
		static BYTE parms[] = VTS_BSTR VTS_I4 VTS_I4 VTS_R8 VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0xa, DISPATCH_METHOD, VT_I4, (void*)&result, parms, title, page_start, page_end, page_ratio, copies, align, printer);
		return result;
	}
	long render_page(HDC hdc, long page_no, double resx, double resy, long offx, long offy, BOOL print_mode)
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_R8 VTS_R8 VTS_I4 VTS_I4 VTS_BOOL ;
		InvokeHelper(0xb, DISPATCH_METHOD, VT_I4, (void*)&result, parms, hdc, page_no, resx, resy, offx, offy, print_mode);
		return result;
	}
	void cancel_session(long session)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0xc, DISPATCH_METHOD, VT_EMPTY, NULL, parms, session);
	}
	void set_mark(LPCTSTR img, long x, long y, long w, long h, long alignx, long aligny, long flag)
	{
		static BYTE parms[] = VTS_BSTR VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x10, DISPATCH_METHOD, VT_EMPTY, NULL, parms, img, x, y, w, h, alignx, aligny, flag);
	}
	void set_mark_pages(long start, long count)
	{
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0x11, DISPATCH_METHOD, VT_EMPTY, NULL, parms, start, count);
	}
	void clear_mark(void)
	{
		InvokeHelper(0x12, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void set_filter_password(LPCTSTR password)
	{
		static BYTE parms[] = VTS_BSTR ;
		InvokeHelper(0x15, DISPATCH_METHOD, VT_EMPTY, NULL, parms, password);
	}
	// IPDFDocument ����
public:

};


class CPDFWndViewer;
class CPDFWndThumbs : public CWnd,
	public IDispEventImpl<0, CPDFWndThumbs, &__uuidof(_IPDFThumbsEvents), &__uuidof(__RadaeePDFLib), 1, 0>
{
public:
	CPDFWndThumbs()
	{
		notifee = NULL;
		ownner = NULL;
		book = NULL;
		roll = NULL;
	}
BEGIN_SINK_MAP(CPDFWndThumbs)
	SINK_ENTRY_EX(0, __uuidof(_IPDFThumbsEvents), 1, &OnClickPage)
END_SINK_MAP()
	STDMETHOD(OnClickPage)( LONG page );
	CPDFWndViewer *notifee;
	class CPDFWndBook *book;
	class CPDFWndRoll *roll;
	CWnd *ownner;
protected:
	DECLARE_DYNCREATE(CPDFWndThumbs)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0xE1B0EDE0, 0x15BB, 0x43DE, { 0xBA, 0x30, 0x68, 0xED, 0xF5, 0xD1, 0x3, 0xAF } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
						const RECT& rect, CWnd* pParentWnd, UINT nID, 
						CCreateContext* pContext = NULL)
	{ 
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID);
		EventAdvise();
		return ret;
	}

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, 
				UINT nID, CFile* pPersist = NULL, BOOL bStorage = FALSE,
				BSTR bstrLicKey = NULL)
	{ 
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
			pPersist, bStorage, bstrLicKey); 
		EventAdvise();
		return ret;
	}
	void EventAdvise()
	{
		if( m_pCtrlSite )
			DispEventAdvise( m_pCtrlSite->m_pObject );
	}

// ����
public:

// ����
public:

// IPDFThumbs

// Functions
//

	void put_BackColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	unsigned long get_BackColor()
	{
		unsigned long result;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	BOOL attach_doc(LPDISPATCH doc)
	{
		BOOL result;
		static BYTE parms[] = VTS_DISPATCH ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, doc);
		return result;
	}
	void detach_doc()
	{
		InvokeHelper(0x2, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void goto_page(long page_no)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x3, DISPATCH_METHOD, VT_EMPTY, NULL, parms, page_no);
	}
	void put_PageBackColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(0x4, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}

// Properties
//

};

class CPDFWndBMTree : public CWnd,
	public IDispEventImpl<0, CPDFWndBMTree, &__uuidof(_IPDFBMTreeEvents), &__uuidof(__RadaeePDFLib), 1, 0>
{
public:
	CPDFWndBMTree()
	{
		notifee = NULL;
		ownner = NULL;
		book = NULL;
		roll = NULL;
	}
BEGIN_SINK_MAP(CPDFWndBMTree)
	SINK_ENTRY_EX(0, __uuidof(_IPDFBMTreeEvents), 1, &OnItemSelected)
	SINK_ENTRY_EX(0, __uuidof(_IPDFBMTreeEvents), 2, &OnAccessURI)
END_SINK_MAP()
	STDMETHOD(OnItemSelected)( BSTR label, LONG page_no, DOUBLE top );
	STDMETHOD(OnAccessURI)( BSTR uri );

	CPDFWndViewer *notifee;
	class CPDFWndBook *book;
	class CPDFWndRoll *roll;
	CWnd *ownner;
protected:
	DECLARE_DYNCREATE(CPDFWndBMTree)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0x28C52C84, 0xE943, 0x4C42, { 0x8A, 0x1F, 0x17, 0xEE, 0x49, 0x8E, 0x91, 0x6E } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
						const RECT& rect, CWnd* pParentWnd, UINT nID, 
						CCreateContext* pContext = NULL)
	{
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID);
		EventAdvise();
		return ret;
	}

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, 
				UINT nID, CFile* pPersist = NULL, BOOL bStorage = FALSE,
				BSTR bstrLicKey = NULL)
	{ 
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
			pPersist, bStorage, bstrLicKey);
		EventAdvise();
		return ret;
	}
	void EventAdvise()
	{
		if( m_pCtrlSite )
			DispEventAdvise( m_pCtrlSite->m_pObject );
	}

// ����
public:


// ����
public:

// IPDFBMTree

// Functions
//

	void put_BackColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	unsigned long get_BackColor()
	{
		unsigned long result;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	BOOL attach_doc(LPDISPATCH doc)
	{
		BOOL result;
		static BYTE parms[] = VTS_DISPATCH ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, doc);
		return result;
	}
	void detach_doc()
	{
		InvokeHelper(0x2, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}

// Properties
//



};

class CPDFWndViewer : public CWnd,
	public IDispEventImpl<0, CPDFWndViewer, &__uuidof(_IPDFViewerEvents), &__uuidof(__RadaeePDFLib), 1, 0>
{
public:
	CPDFWndViewer(){notifee = NULL;ownner = NULL;}
BEGIN_SINK_MAP(CPDFWndViewer)
	SINK_ENTRY_EX(0, __uuidof(_IPDFViewerEvents), 1, &OnFinding)
	SINK_ENTRY_EX(0, __uuidof(_IPDFViewerEvents), 2, &OnRatioChanged)
	SINK_ENTRY_EX(0, __uuidof(_IPDFViewerEvents), 3, &OnPageNoChanged)
	SINK_ENTRY_EX(0, __uuidof(_IPDFViewerEvents), 4, &OnSnapshot)
	SINK_ENTRY_EX(0, __uuidof(_IPDFViewerEvents), 5, &OnAccessURI)
END_SINK_MAP()
	STDMETHOD(OnPageNoChanged)( LONG page );
	STDMETHOD(OnRatioChanged)( DOUBLE ratio );
	STDMETHOD(OnFinding)( LONG page_no, LONG page_count );
	STDMETHOD(OnSnapshot)( LONG x, LONG y );
	STDMETHOD(OnAccessURI)( BSTR uri );

	CPDFWndThumbs *notifee;
	CWnd *ownner;
protected:
	DECLARE_DYNCREATE(CPDFWndViewer)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0x3AB65BA7, 0xFCFC, 0x4656, { 0xBD, 0x1B, 0x40, 0xF4, 0x73, 0x3A, 0x9D, 0x68 } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
						const RECT& rect, CWnd* pParentWnd, UINT nID, 
						CCreateContext* pContext = NULL)
	{ 
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); 
		EventAdvise();
		return ret;
	}

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, 
				UINT nID, CFile* pPersist = NULL, BOOL bStorage = FALSE,
				BSTR bstrLicKey = NULL)
	{ 
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
			pPersist, bStorage, bstrLicKey); 
		EventAdvise();
		return ret;
	}
	void EventAdvise()
	{
		if( m_pCtrlSite )
			DispEventAdvise( m_pCtrlSite->m_pObject );
	}
	void access_uri( LPCTSTR uri )
	{
		CString msg;
		msg.Format( _T("do you want to connect to \"%s\""), uri );
		if( MessageBox( msg, NULL, MB_YESNO ) == IDYES )
		{
			ShellExecute( m_hWnd, _T("open"), uri, NULL, NULL, SW_SHOW );
		}
	}
// ����
public:

// ����
public:

// IPDFViewer

// Functions
//

	void put_BackColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	unsigned long get_BackColor()
	{
		unsigned long result;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	BOOL attach_doc(LPDISPATCH doc)
	{
		BOOL result;
		static BYTE parms[] = VTS_DISPATCH ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, doc);
		return result;
	}
	void detach_doc()
	{
		InvokeHelper(0x2, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	long get_layout()
	{
		long result;
		InvokeHelper(0x3, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_layout(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x3, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	long get_fit_mode()
	{
		long result;
		InvokeHelper(0x4, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_fit_mode(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x4, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	double get_ratio()
	{
		double result;
		InvokeHelper(0x5, DISPATCH_PROPERTYGET, VT_R8, (void*)&result, NULL);
		return result;
	}
	void put_ratio(double newValue)
	{
		static BYTE parms[] = VTS_R8 ;
		InvokeHelper(0x5, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	long get_tool()
	{
		long result;
		InvokeHelper(0x6, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_tool(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x6, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	long get_current_page()
	{
		long result;
		InvokeHelper(0x7, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_current_page(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x7, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	void goto_first_page()
	{
		InvokeHelper(0x8, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void goto_prev_page()
	{
		InvokeHelper(0x9, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void goto_next_page()
	{
		InvokeHelper(0xa, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void goto_last_page()
	{
		InvokeHelper(0xb, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void scroll_line_down()
	{
		InvokeHelper(0xc, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void scroll_line_up()
	{
		InvokeHelper(0xd, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void scroll_page_up()
	{
		InvokeHelper(0xe, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void scroll_page_down()
	{
		InvokeHelper(0xf, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void mouse_wheel(long delta)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x10, DISPATCH_METHOD, VT_EMPTY, NULL, parms, delta);
	}
	unsigned long get_PageBackColor()
	{
		unsigned long result;
		InvokeHelper(0x11, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	void put_PageBackColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(0x11, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	long find(LPCTSTR sfind, long start_page, long start_obj, BOOL lookup, BOOL match_case, BOOL match_whole)
	{
		long result;
		static BYTE parms[] = VTS_BSTR VTS_I4 VTS_I4 VTS_BOOL VTS_BOOL VTS_BOOL ;
		InvokeHelper(0x12, DISPATCH_METHOD, VT_I4, (void*)&result, parms, sfind, start_page, start_obj, lookup, match_case, match_whole);
		return result;
	}
	void cancel_find(long session)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x13, DISPATCH_METHOD, VT_EMPTY, NULL, parms, session);
	}
	void goto_pos(long page_no, double top)
	{
		static BYTE parms[] = VTS_I4 VTS_R8 ;
		InvokeHelper(0x14, DISPATCH_METHOD, VT_EMPTY, NULL, parms, page_no, top);
	}
	CString get_selected_string()
	{
		CString result;
		InvokeHelper(0x15, DISPATCH_PROPERTYGET, VT_BSTR, (void*)&result, NULL);
		return result;
	}
	BOOL save_snapshot_to_file(LPCTSTR filename)
	{
		BOOL result;
		static BYTE parms[] = VTS_BSTR;
		InvokeHelper(0x16, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, filename);
		return result;
	}
	void save_snapshot_to_clipboard()
	{
		InvokeHelper(0x17, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	long point_to_page( LONG x, LONG y )
	{
		long result;
		static BYTE parms[] = VTS_I4 VTS_I4 ;
		InvokeHelper(0x18, DISPATCH_METHOD, VT_I4, (void*)&result, parms, x, y );
		return result;
	}
	BOOL save_page_from_point( LONG page, LPCTSTR bmp_filename )
	{
		BOOL result;
		static BYTE parms[] = VTS_I4 VTS_BSTR;
		InvokeHelper(0x19, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, page, bmp_filename );
		return result;
	}
	void set_sel_color(long r, long g, long b, long a)
	{
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x1d, DISPATCH_METHOD, VT_EMPTY, NULL, parms, r, g, b, a);
	}
	void keys_set_color(long r, long g, long b, long a)
	{
		static BYTE parms[] = VTS_I4 VTS_I4 VTS_I4 VTS_I4 ;
		InvokeHelper(0x1e, DISPATCH_METHOD, VT_EMPTY, NULL, parms, r, g, b, a);
	}
	void keys_add(LPCTSTR key)
	{
		static BYTE parms[] = VTS_BSTR ;
		InvokeHelper(0x1f, DISPATCH_METHOD, VT_EMPTY, NULL, parms, key);
	}
	void keys_add_not(LPCTSTR key)
	{
		static BYTE parms[] = VTS_BSTR ;
		InvokeHelper(0x20, DISPATCH_METHOD, VT_EMPTY, NULL, parms, key);
	}
	void keys_clear(void)
	{
		InvokeHelper(0x21, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}

// Properties
//

	void put_ShowCover(BOOL newValue)
	{
		static BYTE parms[] = VTS_BOOL ;
		InvokeHelper(26, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	void put_PagesLeftToRight(BOOL newValue)
	{
		static BYTE parms[] = VTS_BOOL ;
		InvokeHelper(27, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
};

class CPDFWndBook : public CWnd,
	public IDispEventImpl<0, CPDFWndBook, &__uuidof(_IPDFBookEvents), &__uuidof(__RadaeePDFLib), 1, 0>
{
public:
	CPDFWndBook(){ownner = NULL;}
BEGIN_SINK_MAP(CPDFWndBook)
	SINK_ENTRY_EX(0, __uuidof(_IPDFBookEvents), 1, &OnPageNoChanged)

END_SINK_MAP()
	STDMETHOD(OnPageNoChanged)( LONG page );

	CWnd *ownner;
protected:
	DECLARE_DYNCREATE(CPDFWndBook)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0x7D8CDA93, 0xA94C, 0x4FE3, { 0x9F, 0x05, 0xC2, 0x5A, 0x7F, 0x00, 0x33, 0xF4 } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
						const RECT& rect, CWnd* pParentWnd, UINT nID, 
						CCreateContext* pContext = NULL)
	{
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); 
		EventAdvise();
		return ret;
	}

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, 
				UINT nID, CFile* pPersist = NULL, BOOL bStorage = FALSE,
				BSTR bstrLicKey = NULL)
	{
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
			pPersist, bStorage, bstrLicKey); 
		EventAdvise();
		return ret;
	}
	void EventAdvise()
	{
		if( m_pCtrlSite )
			DispEventAdvise( m_pCtrlSite->m_pObject );
	}
// ����
public:
	unsigned long get_PageBackColor()
	{
		unsigned long result;
		InvokeHelper(0x6, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	void put_PageBackColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(0x6, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}

// ����
public:

// IPDFBook

// Functions
//

	void put_BackColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	unsigned long get_BackColor()
	{
		unsigned long result;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	void put_BorderColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(DISPID_BORDERCOLOR, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	unsigned long get_BorderColor()
	{
		unsigned long result;
		InvokeHelper(DISPID_BORDERCOLOR, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	void put_BorderVisible(BOOL newValue)
	{
		static BYTE parms[] = VTS_BOOL ;
		InvokeHelper(DISPID_BORDERVISIBLE, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	BOOL get_BorderVisible()
	{
		BOOL result;
		InvokeHelper(DISPID_BORDERVISIBLE, DISPATCH_PROPERTYGET, VT_BOOL, (void*)&result, NULL);
		return result;
	}
	BOOL attach_doc(LPDISPATCH doc)
	{
		BOOL result;
		static BYTE parms[] = VTS_DISPATCH ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, doc);
		return result;
	}
	void detach_doc()
	{
		InvokeHelper(0x2, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void roll_papers_forward( long papers )
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x3, DISPATCH_METHOD, VT_EMPTY, NULL, parms, papers);
	}
	void roll_papers_backward( long papers )
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x4, DISPATCH_METHOD, VT_EMPTY, NULL, parms, papers);
	}

// Properties
//

	long get_current_page()
	{
		long result;
		InvokeHelper(0x5, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_current_page(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x5, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}

};


class CPDFWndRoll : public CWnd,
	public IDispEventImpl<0, CPDFWndRoll, &__uuidof(_IPDFRollEvents), &__uuidof(__RadaeePDFLib), 1, 0>
{
public:
	CPDFWndRoll(){ownner = NULL;}
BEGIN_SINK_MAP(CPDFWndRoll)
	SINK_ENTRY_EX(0, __uuidof(_IPDFRollEvents), 1, &OnPageNoChanged)

END_SINK_MAP()
	STDMETHOD(OnPageNoChanged)( LONG page );

	CWnd *ownner;
protected:
	DECLARE_DYNCREATE(CPDFWndRoll)
public:
	CLSID const& GetClsid()
	{
		//7EE80AA2-5CF1-4A8C-B77F-EB86DBC83074
		static CLSID const clsid
			= { 0x7EE80AA2, 0x5CF1, 0x4A8C, { 0xB7, 0x7F, 0xEB, 0x86, 0xDB, 0xC8, 0x30, 0x74 } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle,
						const RECT& rect, CWnd* pParentWnd, UINT nID, 
						CCreateContext* pContext = NULL)
	{
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); 
		EventAdvise();
		return ret;
	}

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, 
				UINT nID, CFile* pPersist = NULL, BOOL bStorage = FALSE,
				BSTR bstrLicKey = NULL)
	{
		BOOL ret = CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
			pPersist, bStorage, bstrLicKey); 
		EventAdvise();
		return ret;
	}
	void EventAdvise()
	{
		if( m_pCtrlSite )
			DispEventAdvise( m_pCtrlSite->m_pObject );
	}
// ����
public:
	unsigned long get_PageBackColor()
	{
		unsigned long result;
		InvokeHelper(0x3, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	void put_PageBackColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(0x3, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	long get_Orientation()
	{
		unsigned long result;
		InvokeHelper(0x9, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_Orientation(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x9, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}

	unsigned long get_max_delta()
	{
		unsigned long result;
		InvokeHelper(0x6, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_max_delta(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x6, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}

	unsigned long get_cell_width()
	{
		unsigned long result;
		InvokeHelper(0x7, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_cell_width(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x7, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}

	unsigned long get_edge_width()
	{
		unsigned long result;
		InvokeHelper(0x8, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_edge_width(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x8, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
// ����
public:

// IPDFBook

// Functions
//

	void put_BackColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	unsigned long get_BackColor()
	{
		unsigned long result;
		InvokeHelper(DISPID_BACKCOLOR, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	void put_BorderColor(unsigned long newValue)
	{
		static BYTE parms[] = VTS_UI4 ;
		InvokeHelper(DISPID_BORDERCOLOR, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	unsigned long get_BorderColor()
	{
		unsigned long result;
		InvokeHelper(DISPID_BORDERCOLOR, DISPATCH_PROPERTYGET, VT_UI4, (void*)&result, NULL);
		return result;
	}
	void put_BorderVisible(BOOL newValue)
	{
		static BYTE parms[] = VTS_BOOL ;
		InvokeHelper(DISPID_BORDERVISIBLE, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
	BOOL get_BorderVisible()
	{
		BOOL result;
		InvokeHelper(DISPID_BORDERVISIBLE, DISPATCH_PROPERTYGET, VT_BOOL, (void*)&result, NULL);
		return result;
	}
	BOOL attach_doc(LPDISPATCH doc)
	{
		BOOL result;
		static BYTE parms[] = VTS_DISPATCH ;
		InvokeHelper(0x1, DISPATCH_METHOD, VT_BOOL, (void*)&result, parms, doc);
		return result;
	}
	void detach_doc()
	{
		InvokeHelper(0x2, DISPATCH_METHOD, VT_EMPTY, NULL, NULL);
	}
	void roll_pages( long pages )
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x5, DISPATCH_METHOD, VT_EMPTY, NULL, parms, pages);
	}
	long get_current_page()
	{
		long result;
		InvokeHelper(0x4, DISPATCH_PROPERTYGET, VT_I4, (void*)&result, NULL);
		return result;
	}
	void put_current_page(long newValue)
	{
		static BYTE parms[] = VTS_I4 ;
		InvokeHelper(0x4, DISPATCH_PROPERTYPUT, VT_EMPTY, NULL, parms, newValue);
	}
// Properties
//

};
