
// MainFrm.h : interface of the CMainFrame class
//

#pragma once
#include "ToolBarMain.h"
#include "ToolBarView.h"

class CChildFrame;
class CMainFrame : public CMDIFrameWndEx
{
	DECLARE_DYNAMIC(CMainFrame)
public:
	CMainFrame();

// Attributes
public:

// Operations
public:

// Overrides
public:
	CToolBarMain      m_wndToolBar;
	CToolBarView      m_wndViewBar;
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL LoadFrame(UINT nIDResource, DWORD dwDefaultStyle = WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, CWnd* pParentWnd = NULL, CCreateContext* pContext = NULL);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CMFCMenuBar       m_wndMenuBar;
	CMFCStatusBar     m_wndStatusBar;
	CMFCToolBarImages m_UserImages;
	CChildFrame *get_active_child()
	{
		CFrameWnd *pFrame = GetActiveFrame();
		if( pFrame == this ) return NULL;
		return (CChildFrame *)pFrame;
	}
// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnWindowManager();
	afx_msg void OnViewCustomize();
	afx_msg LRESULT OnToolbarCreateNew(WPARAM wp, LPARAM lp);
	afx_msg void OnApplicationLook(UINT id);
	afx_msg void OnUpdateApplicationLook(CCmdUI* pCmdUI);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()

	afx_msg void OnHelpRadaeehome();
	afx_msg void OnViewFullscreen();
	afx_msg void OnUpdateEditFind(CCmdUI *pCmdUI);
	afx_msg void OnUpdateInternalFindoption(CCmdUI *pCmdUI);
	afx_msg void OnInternalFindoption();
	afx_msg void OnUpdateInternalFindup(CCmdUI *pCmdUI);
	afx_msg void OnUpdateInternalFinddown(CCmdUI *pCmdUI);
	afx_msg void OnInternalFinddown();
	afx_msg void OnInternalFindup();
	afx_msg void OnUpdateToolGotopage(CCmdUI *pCmdUI);
	afx_msg void OnToolGotopage();
	afx_msg void OnUpdateViewZoomto(CCmdUI *pCmdUI);
	afx_msg void OnUpdateToolDrag(CCmdUI *pCmdUI);
	afx_msg void OnToolDrag();
	afx_msg void OnUpdateToolTextselection(CCmdUI *pCmdUI);
	afx_msg void OnToolTextselection();
	afx_msg void OnToolFirstpage();
	afx_msg void OnUpdateToolFirstpage(CCmdUI *pCmdUI);
	afx_msg void OnToolPreviouspage();
	afx_msg void OnUpdateToolPreviouspage(CCmdUI *pCmdUI);
	afx_msg void OnToolNextpage();
	afx_msg void OnUpdateToolNextpage(CCmdUI *pCmdUI);
	afx_msg void OnToolLastpage();
	afx_msg void OnUpdateToolLastpage(CCmdUI *pCmdUI);
	afx_msg void OnPagelayoutSingle();
	afx_msg void OnUpdatePagelayoutSingle(CCmdUI *pCmdUI);
	afx_msg void OnPagelayoutContinuous();
	afx_msg void OnUpdatePagelayoutContinuous(CCmdUI *pCmdUI);
	afx_msg void OnPagelayoutFolio();
	afx_msg void OnUpdatePagelayoutFolio(CCmdUI *pCmdUI);
	afx_msg void OnPagelayoutFoliocontinuous();
	afx_msg void OnUpdatePagelayoutFoliocontinuous(CCmdUI *pCmdUI);
	afx_msg void OnViewZoomin();
	afx_msg void OnUpdateViewZoomin(CCmdUI *pCmdUI);
	afx_msg void OnViewZoomout();
	afx_msg void OnUpdateViewZoomout(CCmdUI *pCmdUI);
	afx_msg void OnUpdateViewFitwidth(CCmdUI *pCmdUI);
	afx_msg void OnViewFitwidth();
	afx_msg void OnUpdateViewFitpage(CCmdUI *pCmdUI);
	afx_msg void OnViewFitpage();
	afx_msg void OnToolShortcuts();
	afx_msg void OnToolPreference();
	afx_msg void OnToolSnapshot();
	afx_msg void OnUpdateToolSnapshot(CCmdUI *pCmdUI);
	afx_msg void OnUpdateInternalZoomto(CCmdUI *pCmdUI);
	afx_msg void OnUpdateInternalGotopage(CCmdUI *pCmdUI);
	afx_msg void OnUpdateInternalPagesize(CCmdUI *pCmdUI);
	afx_msg void OnFilePrint();
	afx_msg void OnUpdateFilePrint(CCmdUI *pCmdUI);
	afx_msg void OnDropFiles(HDROP hDropInfo);
//protected:
//	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	afx_msg void OnUpdatePagelayoutBookstyle(CCmdUI *pCmdUI);
	afx_msg void OnPagelayoutBookstyle();
	afx_msg void OnPagelayoutRollpage();
	afx_msg void OnUpdatePagelayoutRollpage(CCmdUI *pCmdUI);
	afx_msg void OnHelpHelp();
};


