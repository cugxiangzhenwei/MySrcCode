#pragma once

#ifdef _WIN32_WCE
#error "Windows CE ��֧�� CDHtmlDialog��"
#endif 

// CDlgAbout2 �Ի���

class CDlgAbout2 : public CDHtmlDialog
{
	DECLARE_DYNCREATE(CDlgAbout2)

public:
	CDlgAbout2(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgAbout2();
// ��д
	HRESULT OnButtonOK(IHTMLElement *pElement);
	HRESULT OnButtonCancel(IHTMLElement *pElement);

// �Ի�������
	enum { IDD = IDD_DIALOG_ABOUT2, IDH = IDR_HTML_DLGABOUT2 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
	DECLARE_DHTML_EVENT_MAP()
};
