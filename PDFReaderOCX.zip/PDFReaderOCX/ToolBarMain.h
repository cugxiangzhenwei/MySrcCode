#pragma once


// CToolBarMain

class CToolBarMain : public CMFCToolBar
{
	DECLARE_DYNAMIC(CToolBarMain)

public:
	CToolBarMain();
	virtual ~CToolBarMain();
	void set_text_goto_page( LPCTSTR str );
protected:
	virtual void OnReset();
	DECLARE_MESSAGE_MAP()
};


