// DlgShortcut.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "DlgShortcut.h"


// CDlgShortcut �Ի���

IMPLEMENT_DYNAMIC(CDlgShortcut, CDialog)

CDlgShortcut::CDlgShortcut(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgShortcut::IDD, pParent)
	, m_sName(_T(""))
	, m_sPath(_T(""))
{
	m_bAddFromView = FALSE;
}

CDlgShortcut::~CDlgShortcut()
{
}

void CDlgShortcut::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_NAME, m_sName);
	DDX_Text(pDX, IDC_EDIT_DESTINATION, m_sPath);
}


BEGIN_MESSAGE_MAP(CDlgShortcut, CDialog)
	ON_BN_CLICKED(IDC_BROWSE, &CDlgShortcut::OnBnClickedBrowse)
	ON_BN_CLICKED(IDOK, &CDlgShortcut::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgShortcut ��Ϣ��������

void CDlgShortcut::OnBnClickedBrowse()
{
	UpdateData();
	CFileDialog dlg( TRUE, NULL, m_sPath, 6, _T("Adobe PDF Files(*.pdf)|*.pdf||") );
	if( dlg.DoModal() != IDOK ) return;
	m_sPath = dlg.GetPathName();
	UpdateData( FALSE );
}

void CDlgShortcut::OnBnClickedOk()
{
	UpdateData();
	if( m_sName.IsEmpty() )
	{
		MessageBox( _T("The name can't be empty!") );
		return;
	}
	if( m_sPath.IsEmpty() )
	{
		MessageBox( _T("The destination can't be empty!") );
		return;
	}
	OnOK();
}

BOOL CDlgShortcut::OnInitDialog()
{
	CDialog::OnInitDialog();
	if( m_bAddFromView )
	{
		CEdit *pEdit = (CEdit *)GetDlgItem(IDC_EDIT_DESTINATION);
		pEdit->SetReadOnly( TRUE );
		GetDlgItem( IDC_BUTTON_BROWSE )->EnableWindow( FALSE );
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}
