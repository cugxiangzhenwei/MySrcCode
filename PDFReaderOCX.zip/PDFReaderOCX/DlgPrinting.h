#pragma once
#include "PDFWnd.h"
#include "afxcmn.h"

// CDlgPrinting �Ի���

class CDlgPrinting : public CDialog
{
	DECLARE_DYNAMIC(CDlgPrinting)

public:
	CDlgPrinting(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgPrinting();
	//PDF_CHECKER_PRINT m_cfg;
// �Ի�������
	enum { IDD = IDD_DIALOG_PROGRESS_PRINT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
protected:
	virtual void OnCancel();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	CProgressCtrl m_pPrint;
	OLE_HANDLE m_session;
	CPDFDocument *doc;
	wchar_t wsTitle[256];
	HANDLE printer;
	int page_start;
	int page_end;
	int copies;
	int align;
	int arrange;
};
