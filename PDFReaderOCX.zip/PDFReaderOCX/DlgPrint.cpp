// DlgPrint.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "DlgPrint.h"

// CDlgPrint �Ի���

IMPLEMENT_DYNAMIC(CDlgPrint, CDialog)

PRINTER_INFO_4 *CDlgPrint::ms_pInfos = NULL;
CDlgPrint::PRN_CONFIG *CDlgPrint::ms_pConfs = NULL;
DWORD CDlgPrint::ms_dwNum = 0;

void CDlgPrint::PrnListInit()
{
	if( !ms_pInfos )
	{
		DWORD dwNeed = 0;
		DWORD dwRet = 0;
		EnumPrinters( PRINTER_ENUM_NAME|PRINTER_ENUM_CONNECTIONS, NULL, 4, NULL, 0, &dwNeed, &dwRet );
		ms_pInfos = (PRINTER_INFO_4 *)malloc( dwNeed );
		EnumPrinters( PRINTER_ENUM_NAME|PRINTER_ENUM_CONNECTIONS, NULL, 4, (LPBYTE)ms_pInfos, dwNeed, &dwNeed, &dwRet );
		ms_dwNum = dwRet;
		ms_pConfs = (PRN_CONFIG *)malloc( sizeof( PRN_CONFIG ) * dwRet );
		int ip = 0;
		while( ip < dwRet )
		{
			OpenPrinter( ms_pInfos[ip].pPrinterName, &ms_pConfs[ip].hPrinter, NULL );
			dwNeed = DocumentProperties( NULL, ms_pConfs[ip].hPrinter, ms_pInfos[ip].pPrinterName, NULL, NULL, 0 );
			ms_pConfs[ip].pDModeCur = (DEVMODE *)malloc( dwNeed );
			dwNeed = DocumentProperties( NULL, ms_pConfs[ip].hPrinter, ms_pInfos[ip].pPrinterName, ms_pConfs[ip].pDModeCur, NULL, DM_OUT_BUFFER );
			ip++;
		}
	}
}

void CDlgPrint::PrnListUninit()
{
	if( ms_pInfos )
	{
		int ip = 0;
		while( ip < ms_dwNum )
		{
			free( ms_pConfs[ip].pDModeCur );
			ClosePrinter( ms_pConfs[ip].hPrinter );
			ip++;
		}
		free( ms_pInfos );
		free( ms_pConfs );
		ms_pInfos = NULL;
		ms_pConfs = NULL;
		ms_dwNum = 0;
	}
}

CDlgPrint::CDlgPrint(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPrint::IDD, pParent)
{
}

CDlgPrint::~CDlgPrint()
{
}

void CDlgPrint::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO_PRINTERS, m_cPrinters);
	DDX_Control(pDX, IDC_STATIC_STATUS, m_sStatus);
	DDX_Control(pDX, IDC_STATIC_TYPE, m_sType);
	DDX_Control(pDX, IDC_COMBO_ALIGN, m_cAlign);
	DDX_Control(pDX, IDC_COMBO_ARRANGE, m_cArrange);
}


BEGIN_MESSAGE_MAP(CDlgPrint, CDialog)
	ON_CBN_SELCHANGE(IDC_COMBO_PRINTERS, &CDlgPrint::OnCbnSelchangeComboPrinters)
	ON_BN_CLICKED(IDC_RADIO_ALL, &CDlgPrint::OnBnClickedRadioAll)
	ON_BN_CLICKED(IDC_RADIO_CURRENT, &CDlgPrint::OnBnClickedRadioCurrent)
	ON_BN_CLICKED(IDC_RADIO_CUSTOM, &CDlgPrint::OnBnClickedRadioCustom)
	ON_BN_CLICKED(IDC_BUTTON_PROPERTY, &CDlgPrint::OnBnClickedButtonProperty)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDOK, &CDlgPrint::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgPrint ��Ϣ��������

BOOL CDlgPrint::OnInitDialog()
{
	CDialog::OnInitDialog();
	DWORD dwRet = 0;
	PrnListInit();
	if( ms_dwNum == 0 )
		MessageBox( _T("There are no printers on your system!") );
	else
	{
		int ip = 0;
		while( ip < ms_dwNum )
		{
			m_cPrinters.AddString( ms_pInfos[ip].pPrinterName );
			ip++;
		}
		TCHAR sBuf[512];
		dwRet = 511;
		GetDefaultPrinter( sBuf, &dwRet );
		m_cPrinters.SelectString( -1, sBuf );
		OnCbnSelchangeComboPrinters();
	}
	CheckDlgButton( IDC_RADIO_ALL, 1 );
	GetDlgItem( IDC_EDIT_PAGE1 )->EnableWindow( FALSE );
	GetDlgItem( IDC_EDIT_PAGE2 )->EnableWindow( FALSE );
	SetDlgItemInt( IDC_EDIT_COPIES, 1 );
	m_cAlign.AddString( _T("left") );
	m_cAlign.AddString( _T("center") );
	m_cAlign.AddString( _T("right") );
	m_cAlign.SetCurSel( 1 );
	m_cArrange.AddString( _T("100%") );
	m_cArrange.AddString( _T("70.71% (two in one)") );
	m_cArrange.AddString( _T("50% (four in one)") );
	m_cArrange.SetCurSel( 0 );
	SetTimer( 100, 1000, NULL );
	SetDlgItemInt( IDC_EDIT_PAGE1, 1 );
	SetDlgItemInt( IDC_EDIT_PAGE2, m_pDoc->get_page_count() );
	return TRUE;
}

void CDlgPrint::OnTimer(UINT_PTR nIDEvent)
{
	OnCbnSelchangeComboPrinters();
	CDialog::OnTimer(nIDEvent);
}

void CDlgPrint::OnCbnSelchangeComboPrinters()
{
	int sel = m_cPrinters.GetCurSel();
	if( sel < 0 ) return;
	DWORD dwNeed = 0;
	GetPrinter( ms_pConfs[sel].hPrinter, 2, NULL, 0, &dwNeed );
	PRINTER_INFO_2 *info = (PRINTER_INFO_2 *)malloc( dwNeed );
	GetPrinter( ms_pConfs[sel].hPrinter, 2, (LPBYTE)info, dwNeed, &dwNeed );
	if( !info->Status )
		m_sStatus.SetWindowText( _T("ready") );
	else
	{
		switch( info->Status )
		{
		case PRINTER_STATUS_BUSY:// The printer is busy.  
			m_sStatus.SetWindowText( _T("busy") );
			break;
		case PRINTER_STATUS_DOOR_OPEN:// The printer door is open. 
			m_sStatus.SetWindowText( _T("door opened") );
			break;
		case PRINTER_STATUS_ERROR:// The printer is in an error state. 
			m_sStatus.SetWindowText( _T("error") );
			break;
		case PRINTER_STATUS_INITIALIZING:// The printer is initializing.  
			m_sStatus.SetWindowText( _T("initializing") );
			break;
		case PRINTER_STATUS_IO_ACTIVE:// The printer is in an active input/output state 
			m_sStatus.SetWindowText( _T("ready") );
			break;
		case PRINTER_STATUS_MANUAL_FEED:// The printer is in a manual feed state. 
			m_sStatus.SetWindowText( _T("a manual feed") );
			break;
		case PRINTER_STATUS_NO_TONER:// The printer is out of toner. 
			m_sStatus.SetWindowText( _T("out of toner") );
			break;
		case PRINTER_STATUS_NOT_AVAILABLE:// The printer is not available for printing.  
			m_sStatus.SetWindowText( _T("not available") );
			break;
		case PRINTER_STATUS_OFFLINE:// The printer is offline.  
			m_sStatus.SetWindowText( _T("offline") );
			break;
		case PRINTER_STATUS_OUT_OF_MEMORY:// The printer has run out of memory.  
			m_sStatus.SetWindowText( _T("out of memory") );
			break;
		case PRINTER_STATUS_OUTPUT_BIN_FULL:// The printer's output bin is full.  
			m_sStatus.SetWindowText( _T("output bin is full") );
			break;
		case PRINTER_STATUS_PAGE_PUNT:// The printer cannot print the current page. 
			m_sStatus.SetWindowText( _T("can't print current page") );
			break;
		case PRINTER_STATUS_PAPER_JAM:// Paper is jammed in the printer  
			m_sStatus.SetWindowText( _T("paper jammed") );
			break;
		case PRINTER_STATUS_PAPER_OUT:// The printer is out of paper. 
			m_sStatus.SetWindowText( _T("out of paper") );
			break;
		case PRINTER_STATUS_PAPER_PROBLEM:// The printer has a paper problem.  
			m_sStatus.SetWindowText( _T("paper problem") );
			break;
		case PRINTER_STATUS_PAUSED:// The printer is paused. 
			m_sStatus.SetWindowText( _T("paused") );
			break;
		case PRINTER_STATUS_PENDING_DELETION:// The printer is being deleted.  
			m_sStatus.SetWindowText( _T("deleted") );
			break;
		case PRINTER_STATUS_POWER_SAVE:// The printer is in power save mode.  
			m_sStatus.SetWindowText( _T("power save mode") );
			break;
		case PRINTER_STATUS_PRINTING:// The printer is printing. 
			m_sStatus.SetWindowText( _T("printing") );
			break;
		case PRINTER_STATUS_PROCESSING:// The printer is processing a print job.  
			m_sStatus.SetWindowText( _T("processing") );
			break;
		case PRINTER_STATUS_SERVER_UNKNOWN:// The printer status is unknown.  
			m_sStatus.SetWindowText( _T("unknown") );
			break;
		case PRINTER_STATUS_TONER_LOW:// The printer is low on toner. 
			m_sStatus.SetWindowText( _T("low on toner") );
			break;
		case PRINTER_STATUS_USER_INTERVENTION:// The printer has an error that requires the user to do something. 
			m_sStatus.SetWindowText( _T("hard error") );
			break;
		case PRINTER_STATUS_WAITING:// The printer is waiting.  
			m_sStatus.SetWindowText( _T("waiting") );
			break;
		case PRINTER_STATUS_WARMING_UP:
			m_sStatus.SetWindowText( _T("warning") );
			break;
		}
	}
	m_sType.SetWindowText( info->pDriverName );
	free( info );
}

void CDlgPrint::OnBnClickedRadioAll()
{
	GetDlgItem( IDC_EDIT_PAGE1 )->EnableWindow( IsDlgButtonChecked( IDC_RADIO_CUSTOM ) );
	GetDlgItem( IDC_EDIT_PAGE2 )->EnableWindow( IsDlgButtonChecked( IDC_RADIO_CUSTOM ) );
}

void CDlgPrint::OnBnClickedRadioCurrent()
{
	GetDlgItem( IDC_EDIT_PAGE1 )->EnableWindow( IsDlgButtonChecked( IDC_RADIO_CUSTOM ) );
	GetDlgItem( IDC_EDIT_PAGE2 )->EnableWindow( IsDlgButtonChecked( IDC_RADIO_CUSTOM ) );
}

void CDlgPrint::OnBnClickedRadioCustom()
{
	GetDlgItem( IDC_EDIT_PAGE1 )->EnableWindow( IsDlgButtonChecked( IDC_RADIO_CUSTOM ) );
	GetDlgItem( IDC_EDIT_PAGE2 )->EnableWindow( IsDlgButtonChecked( IDC_RADIO_CUSTOM ) );
}

void CDlgPrint::OnBnClickedButtonProperty()
{
	int sel = m_cPrinters.GetCurSel();
	if( sel < 0 ) return;
	DocumentProperties( m_hWnd, ms_pConfs[sel].hPrinter, ms_pInfos[sel].pPrinterName, ms_pConfs[sel].pDModeCur, ms_pConfs[sel].pDModeCur, DM_IN_BUFFER|DM_OUT_BUFFER|DM_IN_PROMPT );
}

void CDlgPrint::OnBnClickedOk()
{
	m_iPrnSel = m_cPrinters.GetCurSel();
	if( IsDlgButtonChecked( IDC_RADIO_CUSTOM ) )
	{
		m_iPage1 = GetDlgItemInt( IDC_EDIT_PAGE1 );
		m_iPage2 = GetDlgItemInt( IDC_EDIT_PAGE2 );
	}
	else if( IsDlgButtonChecked( IDC_RADIO_CURRENT ) )
		m_iPage1 = m_iPage2 = m_iPageCur;
	else
	{
		m_iPage1 = 1;
		m_iPage2 = m_pDoc->get_page_count();
	}
	if( m_iPage1 > m_iPage2 || m_iPage1 > m_pDoc->get_page_count() || m_iPage2 > m_pDoc->get_page_count() ||
		m_iPage1 <= 0 || m_iPage2 <= 0 )
	{
		MessageBox( _T("Invalid page number.") );
		return;
	}
	m_iCopies = GetDlgItemInt( IDC_EDIT_COPIES );
	if( m_iCopies < 1 ) m_iCopies = 1;
	m_iAlign = m_cAlign.GetCurSel();
	m_iArrange = m_cArrange.GetCurSel();
	OnOK();
}
