
// stdafx.cpp : source file that includes just the standard includes
// PDFReader.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



LPCTSTR LHGetFileName( LPCTSTR szFullPath )
{
	int ipre = -1;
	int ipos = 0;
	while( szFullPath[ipos] )
	{
		if( szFullPath[ipos] == '\\' ||
			szFullPath[ipos] == '/' )
			ipre = ipos;
		ipos++;
	}
	return szFullPath + ipre + 1;
}

BOOL AFXAPI AfxOleInitEx()
{
	_AFX_THREAD_STATE* pState = AfxGetThreadState();
	ASSERT(!pState->m_bNeedTerm);    // calling it twice?

	// Special case DLL context to assume that the calling app initializes OLE.
	// For DLLs where this is not the case, those DLLs will need to initialize
	// OLE for themselves via OleInitialize.  This is done since MFC cannot provide
	// automatic uninitialize for DLLs because it is not valid to shutdown OLE
	// during a DLL_PROCESS_DETACH.
	if (afxContextIsDLL)
	{
		pState->m_bNeedTerm = -1;  // -1 is a special flag
		return TRUE;
	}

	// first, initialize OLE
	SCODE sc = ::CoInitializeEx( NULL, 0 );
	if (FAILED(sc))
	{
		// warn about non-NULL success codes
#ifdef _DEBUG
		TRACE(traceOle, 0, _T("Warning: OleInitialize returned scode = %s.\n"),
			AfxGetFullScodeString(sc));
#endif
		goto InitFailed;
	}
	// termination required when OleInitialize does not fail
	pState->m_bNeedTerm = TRUE;

	// hook idle time and exit time for required OLE cleanup
	CWinThread* pThread; pThread = AfxGetThread();
	ASSERT(pThread);
	pThread->m_lpfnOleTermOrFreeLib = AfxOleTermOrFreeLib;

	// allocate and initialize default message filter
	if (pThread->m_pMessageFilter == NULL)
	{
		pThread->m_pMessageFilter = new COleMessageFilter;
		ASSERT(AfxOleGetMessageFilter() != NULL);
		AfxOleGetMessageFilter()->Register();
	}
	return TRUE;

InitFailed:
	AfxOleTerm();
	return FALSE;
}


BOOL ExtSetRegKey(LPCTSTR lpszKey, LPCTSTR lpszValue, LPCTSTR lpszValueName = NULL)
{
	if (lpszValueName == NULL)
	{
		if (::RegSetValue(HKEY_CLASSES_ROOT, lpszKey, REG_SZ,
			  lpszValue, lstrlen(lpszValue) * sizeof(TCHAR)) != ERROR_SUCCESS)
		{
			return FALSE;
		}
		return TRUE;
	}
	else
	{
		HKEY hKey;

		if(::RegCreateKey(HKEY_CLASSES_ROOT, lpszKey, &hKey) == ERROR_SUCCESS)
		{
			LONG lResult = ::RegSetValueEx(hKey, lpszValueName, 0, REG_SZ,
				(CONST BYTE*)lpszValue, (lstrlen(lpszValue) + 1) * sizeof(TCHAR));

			if(::RegCloseKey(hKey) == ERROR_SUCCESS && lResult == ERROR_SUCCESS)
				return TRUE;
		}
		return FALSE;
	}
}


BOOL ExtDeleteRegKey(LPCTSTR lpszKey)
{
	// copy the string
	LPTSTR lpszKeyCopy = _tcsdup(lpszKey);
	LPTSTR lpszLast = lpszKeyCopy + lstrlen(lpszKeyCopy);

	// work until the end of the string
	while (lpszLast != NULL)
	{
		*lpszLast = '\0';
		lpszLast = _tcsdec(lpszKeyCopy, lpszLast);

		// try to open that key
		HKEY hKey;
		if (::RegOpenKey(HKEY_CLASSES_ROOT, lpszKeyCopy, &hKey) != ERROR_SUCCESS)
			break;

		// enumerate the keys underneath
		TCHAR szScrap[MAX_PATH+1];
		DWORD dwLen = sizeof(szScrap) / sizeof(szScrap[0]);
		BOOL bItExists = FALSE;

		if (::RegEnumKey(hKey, 0, szScrap, dwLen) == ERROR_SUCCESS)
			bItExists = TRUE;
		::RegCloseKey(hKey);

		// found one?  quit looping
		if (bItExists)
			break;

		// otherwise, delete and find the previous backwhack
		::RegDeleteKey(HKEY_CLASSES_ROOT, lpszKeyCopy);
		lpszLast = _tcsrchr(lpszKeyCopy, '\\');
	}

	// release the string and return
	free(lpszKeyCopy);
	return TRUE;
}

void UnRegExtType( LPCTSTR sExt, LPCTSTR sDocName )
{
	if( sExt[0] == '.' )
		ExtDeleteRegKey( sExt );
	else
	{
		TCHAR sText[32];
		sText[0] = '.';
		sText[1] = 0;
		lstrcat( sText, sExt );
		ExtDeleteRegKey( sText );
	}
	ExtDeleteRegKey( sDocName );
}

void RegExtType( LPCTSTR sExt, LPCTSTR sDocName, int iIcon )
{
	TCHAR sPathName[_MAX_PATH];
	//TCHAR szLongPathName[_MAX_PATH];
	BOOL bNotify;
	GetModuleFileName( AfxGetApp()->m_hInstance, sPathName, _MAX_PATH);
	//GetModuleFileName( AfxGetApp()->m_hInstance, szLongPathName, _MAX_PATH);
	//::GetShortPathName(szLongPathName, sPathName, _MAX_PATH);

	{
		LONG lLen;
		lLen = MAX_PATH;
		TCHAR sVal[MAX_PATH];
		//�ж��Ƿ��Ѿ�ע��
		bNotify = TRUE;
		if( RegQueryValue( HKEY_CLASSES_ROOT, sDocName, sVal, &lLen ) == ERROR_SUCCESS )
			bNotify = FALSE;
	}

	ExtSetRegKey( sDocName, sDocName );
	TCHAR sDefIcon[256];
	TCHAR sDefIconRef[256];
	lstrcpy( sDefIcon, sDocName );
	lstrcat( sDefIcon, _T("\\DefaultIcon") );
#ifndef _UNICODE
	sprintf( sDefIconRef, _T("\"%s\",%d"), sPathName, iIcon );
#else
	swprintf( sDefIconRef, _T("\"%s\",%d"), sPathName, iIcon );
#endif
	ExtSetRegKey( sDefIcon, sDefIconRef );

	TCHAR sOper[256];
	TCHAR sOperRef[256];
	TCHAR sCmdLine[256];
	lstrcpy( sCmdLine, _T("\"") );
	lstrcpy( sCmdLine + 1, sPathName );
	lstrcat( sCmdLine, _T("\"") );
	lstrcat( sCmdLine, _T(" \"%1\"") );

	//�򿪲���
	/*
	lstrcpy( sOper, sDocName );
	lstrcat( sOper, _T("\\shell\\open\\ddeexec") );
	lstrcpy( sOperRef, _T("[open(\"%1\")]") );
	ExtSetRegKey( sOper, sOperRef );
	*/

	lstrcpy( sOper, sDocName );
	lstrcat( sOper, _T("\\shell\\open\\command") );
	ExtSetRegKey( sOper, sCmdLine );

	/*
	//��ӡ����
	lstrcpy( sOper, sDocName );
	lstrcat( sOper, _T("\\shell\\print\\ddeexec") );
	lstrcpy( sOperRef, _T("[print(\"%1\")]") );
	ExtSetRegKey( sOper, sOperRef );
	lstrcpy( sOper, sDocName );
	lstrcat( sOper, _T("\\shell\\print\\command") );
	ExtSetRegKey( sOper, sCmdLine );

	//��ӡ������
	lstrcpy( sOper, sDocName );
	lstrcat( sOper, _T("\\shell\\printto\\ddeexec") );
	lstrcpy( sOperRef, _T("[printto(\"%1\",\"%2\",\"%3\",\"%4\")]") );
	ExtSetRegKey( sOper, sOperRef );
	lstrcpy( sOper, sDocName );
	lstrcat( sOper, _T("\\shell\\printto\\command") );
	ExtSetRegKey( sOper, sCmdLine );]
	*/

	if( sExt[0] == '.' )
		ExtSetRegKey( sExt, sDocName );
	else
	{
		TCHAR sRegExt[128];
		sRegExt[0] = '.';
		sRegExt[1] = 0;
		lstrcat( sRegExt, sExt );
		ExtSetRegKey( sRegExt, sDocName );
	}
	if(bNotify) SHChangeNotify(SHCNE_ASSOCCHANGED, SHCNF_IDLIST|SHCNF_FLUSH, NULL, NULL);
}
