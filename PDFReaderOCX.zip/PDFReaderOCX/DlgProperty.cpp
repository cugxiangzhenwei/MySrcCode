// DlgProperty.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "DlgProperty.h"


// CDlgProperty �Ի���

IMPLEMENT_DYNAMIC(CDlgProperty, CDialog)

CDlgProperty::CDlgProperty(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgProperty::IDD, pParent)
	, m_sVer(_T(""))
	, m_iPages(0)
	, m_sTitle(_T(""))
	, m_sAuthor(_T(""))
	, m_sCreator(_T(""))
	, m_sProducer(_T(""))
	, m_sKeywords(_T(""))
	, m_sFileName(_T(""))
{

}

CDlgProperty::~CDlgProperty()
{
}

void CDlgProperty::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_VER, m_sVer);
	DDX_Text(pDX, IDC_EDIT_PAGES, m_iPages);
	DDX_Text(pDX, IDC_EDIT_TITLE, m_sTitle);
	DDX_Text(pDX, IDC_EDIT_AUTHOR, m_sAuthor);
	DDX_Text(pDX, IDC_EDIT_CREATOR, m_sCreator);
	DDX_Text(pDX, IDC_EDIT_PRODUCER, m_sProducer);
	DDX_Text(pDX, IDC_EDIT_KEYWORDS, m_sKeywords);
	DDX_Text(pDX, IDC_EDIT_FILENAME, m_sFileName);
}


BEGIN_MESSAGE_MAP(CDlgProperty, CDialog)
END_MESSAGE_MAP()


// CDlgProperty ��Ϣ��������
