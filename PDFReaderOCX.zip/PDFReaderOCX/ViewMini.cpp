// ViewMini.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "ViewMini.h"


// CViewMini

IMPLEMENT_DYNAMIC(CViewMini, CDockablePane)

CViewMini::CViewMini()
{

}

CViewMini::~CViewMini()
{
}


BEGIN_MESSAGE_MAP(CViewMini, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()



// CViewMini ��Ϣ��������


int CViewMini::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;
	RECT rcWnd;
	GetClientRect( &rcWnd );
	if( m_wndMini.Create( NULL, WS_VISIBLE|WS_CHILD, rcWnd, this, 1 ) )
	{
		m_wndMini.put_PageBackColor( theApp.m_preference.clrBack_Page );
		m_wndMini.put_BackColor( theApp.m_preference.clrBack );
	}
	return 0;
}

void CViewMini::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	if( IsWindow(m_wndMini) )
		m_wndMini.MoveWindow( 0, 0, cx, cy );
}
