
// ChildFrm.cpp : implementation of the CChildFrame class
//

#include "stdafx.h"
#include "PDFReader.h"

#include "ChildFrm.h"
#include "PDFReaderDoc.h"
#include "PDFReaderView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CChildFrame

IMPLEMENT_DYNCREATE(CChildFrame, CMDIChildWndEx)

BEGIN_MESSAGE_MAP(CChildFrame, CMDIChildWndEx)
	ON_COMMAND(ID_VIEW_CAPTION_BAR, &CChildFrame::OnViewCaptionBar)
	ON_UPDATE_COMMAND_UI(ID_VIEW_CAPTION_BAR, &CChildFrame::OnUpdateViewCaptionBar)
	ON_COMMAND(ID_VIEW_OUTLINE, &CChildFrame::OnViewOutline)
	ON_COMMAND(ID_VIEW_MINI, &CChildFrame::OnViewMini)
	ON_UPDATE_COMMAND_UI(ID_VIEW_OUTLINE, &CChildFrame::OnUpdateViewOutline)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MINI, &CChildFrame::OnUpdateViewMini)
END_MESSAGE_MAP()

// CChildFrame construction/destruction

CChildFrame::CChildFrame()
{
	m_bEnableFloatingBars = TRUE;
}

CChildFrame::~CChildFrame()
{
}

BOOL CChildFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying the CREATESTRUCT cs
	if( !CMDIChildWndEx::PreCreateWindow(cs) )
		return FALSE;

	return TRUE;
}

int CChildFrame::get_pageno()
{
	return GetRDView()->get_pageno();
}

void CChildFrame::get_page_size_inch( int page, double &inch_width, double &inch_height )
{
	GetRDView()->get_page_size_inch( page, inch_width, inch_height );
}

int CChildFrame::get_page_count()
{
	return GetRDView()->get_page_count();
}

void CChildFrame::page_down()
{
	GetRDView()->page_down();
}

void CChildFrame::page_up()
{
	GetRDView()->page_up();
}

void CChildFrame::set_ratio( double ratio )
{
	GetRDView()->set_fit_mode( fit_none );
	GetRDView()->set_ratio( ratio );
}

double CChildFrame::get_ratio()
{
	return GetRDView()->get_ratio();
}

void CChildFrame::roll_papers( int papers )
{
	GetRDView()->roll_papers( papers );
}

void CChildFrame::goto_page( int page )
{
	GetRDView()->goto_page( page );
}

void CChildFrame::set_view_style( int style )
{
	GetRDView()->set_view_style( style );
}

int CChildFrame::get_view_style()
{
	return GetRDView()->get_view_style();
}

CPDFDocument *CChildFrame::get_doc()
{
	return GetRDView()->get_doc();
}

void CChildFrame::do_print( HANDLE prn, int page_start, int page_end, int copies, int align, int arrange )
{
	GetRDView()->do_print( prn, page_start, page_end, copies, align, arrange );
}

pdf_tool CChildFrame::get_drag_mode()
{
	return GetRDView()->get_drag_mode();
}

void CChildFrame::set_drag_mode(pdf_tool mode )
{
	return GetRDView()->set_drag_mode(mode);
}

pdf_fit_mode CChildFrame::get_fit_mode()
{
	return GetRDView()->get_fit_mode();
}

void CChildFrame::set_fit_mode( pdf_fit_mode mode )
{
	GetRDView()->set_fit_mode( mode );
}

BOOL CChildFrame::is_find_case()
{
	return GetRDView()->is_find_case();
}

BOOL CChildFrame::is_find_whole_word()
{
	return GetRDView()->is_find_whole_word();
}

void CChildFrame::set_find_case( BOOL iscase )
{
	GetRDView()->set_find_case( iscase );
}

void CChildFrame::set_find_whole_word( BOOL whole_word )
{
	GetRDView()->set_find_whole_word( whole_word );
}

// CChildFrame diagnostics

#ifdef _DEBUG
void CChildFrame::AssertValid() const
{
	CMDIChildWndEx::AssertValid();
}

void CChildFrame::Dump(CDumpContext& dc) const
{
	CMDIChildWndEx::Dump(dc);
}
#endif //_DEBUG

// CChildFrame message handlers
CPDFReaderView *CChildFrame::GetRDView()
{
	CView *pView = GetActiveView();
	if( pView->IsKindOf( RUNTIME_CLASS(CPDFReaderView) ) )
		return (CPDFReaderView *)pView;
	else
		return NULL;
}

void CChildFrame::proLoadPreference()
{
	if( theApp.m_preference.showOutline && theApp.m_preference.showThumbNails )
	{
		switch( theApp.m_preference.viewActive )
		{
		case 1:
			m_wndOutline.ShowPane( TRUE, FALSE, TRUE );
			break;
		case 2:
			m_wndMini.ShowPane( TRUE, FALSE, TRUE );
			break;
		}
	}
	else
	{
		if( !theApp.m_preference.showOutline )
			m_wndOutline.ShowPane( FALSE, FALSE, FALSE );
		if( !theApp.m_preference.showThumbNails )
			m_wndMini.ShowPane( FALSE, FALSE, FALSE );
	}
}

BOOL CChildFrame::OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext)
{
	m_dockManager.Create(this);

	if (!m_wndCaption.Create(WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS, this, ID_VIEW_CAPTION_BAR, -1, FALSE))
	{
		TRACE0("Failed to create caption bar\n");
		return FALSE;
	}

	BOOL bNameValid;
	CString strTemp, strTemp2;
	m_wndCaption.SetButton(_T("Property"), ID_FILE_PROPERTY, CMFCCaptionBar::ALIGN_RIGHT, FALSE);
	bNameValid = strTemp.LoadString(IDS_CAPTION_BUTTON_TIP);
	ASSERT(bNameValid);
	m_wndCaption.SetButtonToolTip(strTemp);

	bNameValid = strTemp.LoadString(IDS_CAPTION_TEXT);
	ASSERT(bNameValid);
	m_wndCaption.SetText(strTemp, CMFCCaptionBar::ALIGN_LEFT);

	m_wndCaption.SetBitmap(IDB_INFO, RGB(255, 255, 255), FALSE, CMFCCaptionBar::ALIGN_LEFT);
	bNameValid = strTemp.LoadString(IDS_CAPTION_IMAGE_TIP);
	ASSERT(bNameValid);
	bNameValid = strTemp2.LoadString(IDS_CAPTION_IMAGE_TEXT);
	ASSERT(bNameValid);
	m_wndCaption.SetImageToolTip(strTemp, strTemp2);

	if (!m_wndOutline.Create(_T("Book Marks"), this, CRect(0, 0, 200, 0), TRUE, ID_VIEW_OUTLINE, WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|CBRS_LEFT, AFX_CBRS_REGULAR_TABS))
		return FALSE; // δ�ܴ���
	if (!m_wndMini.Create(_T("Thumb Nails"), this, CRect(0, 0, 200, 0), TRUE, ID_VIEW_MINI, WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|CBRS_LEFT, AFX_CBRS_REGULAR_TABS))
		return FALSE; // δ�ܴ���
	m_wndOutline.EnableDocking(CBRS_ALIGN_ANY);
	m_wndMini.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	//EnableAutoHidePanes(CBRS_ALIGN_ANY);

	DockPane(&m_wndOutline, 0, CRect( 0, 0, 200, 200 ));
	CDockablePane* pTabbedBar = NULL;
	m_wndMini.AttachToTabWnd(&m_wndOutline, DM_SHOW, FALSE, &pTabbedBar);
	pTabbedBar->SetMinSize( CSize( 50, 100 ) );
	
	proLoadPreference();
	return CMDIChildWndEx::OnCreateClient(lpcs, pContext);
}

void CChildFrame::OnViewCaptionBar()
{
	m_wndCaption.ShowPane(!m_wndCaption.IsVisible(), FALSE, TRUE);
	RecalcLayout(FALSE);
}

void CChildFrame::OnUpdateViewCaptionBar(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_wndCaption.IsVisible());
}

void CChildFrame::OnViewOutline()
{
	m_wndOutline.ShowPane( !m_wndOutline.IsVisible(), FALSE, TRUE );
	RecalcLayout(FALSE);
}

void CChildFrame::OnUpdateViewOutline(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_wndOutline.IsVisible());
}

void CChildFrame::OnViewMini()
{
	m_wndMini.ShowPane( !m_wndMini.IsVisible(), FALSE, TRUE );
	RecalcLayout(FALSE);
}

void CChildFrame::OnUpdateViewMini(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(m_wndMini.IsVisible());
}

LRESULT CChildFrame::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	if( message == WM_INIT_UPDATE )
	{
		CPDFReaderView *pView = (CPDFReaderView *)GetActiveView();
		CPDFDocument *pDoc = pView->GetDocument()->GetRDDoc();
		pView->m_pOwnner = this;
		pView->set_views( &m_wndMini.m_wndMini, &m_wndOutline.m_wndView, &m_wndCaption );
		m_wndMini.m_wndMini.notifee = pView->get_viewer();
		m_wndMini.m_wndMini.book = pView->get_book();
		m_wndMini.m_wndMini.roll = pView->get_roll();
		m_wndOutline.m_wndView.notifee = pView->get_viewer();
		m_wndOutline.m_wndView.book = pView->get_book();
		m_wndOutline.m_wndView.roll = pView->get_roll();
		m_wndMini.m_wndMini.attach_doc( pDoc->m_lpDispatch );
		m_wndOutline.m_wndView.attach_doc( pDoc->m_lpDispatch );
	}
	return CMDIChildWndEx::DefWindowProc(message, wParam, lParam);
}
