// DlgDownload.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DlgDownload.h"


// CDlgDownload �Ի���

IMPLEMENT_DYNAMIC(CDlgDownload, CDialog)

CDlgDownload::CDlgDownload(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgDownload::IDD, pParent)
	, m_sPrompt(_T(""))
{
	m_hThread = NULL;
	m_cancel = false;
	m_url = NULL;
}

CDlgDownload::~CDlgDownload()
{
}

void CDlgDownload::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS_DOWNLOAD, m_pDownload);
	DDX_Text(pDX, IDC_STATIC_PROMPT, m_sPrompt);
}


BEGIN_MESSAGE_MAP(CDlgDownload, CDialog)
	ON_WM_DESTROY()
END_MESSAGE_MAP()

DWORD WINAPI CDlgDownload::thread_download( LPVOID param )
{
	CDlgDownload *thiz = (CDlgDownload *)param;
	while( thiz->m_url->read( 4096 ) && !thiz->m_cancel )
	{
		thiz->PostMessage( WM_USER + 1001, thiz->m_url->get_total_read(), thiz->m_url->get_file_size() );
	}
	if( !thiz->m_cancel )
		thiz->PostMessage( WM_USER + 1001, -1, 0 );//ok
	else
		thiz->PostMessage( WM_USER + 1001, -2, 0 );//cancel
	return 0;
}

// CDlgDownload ��Ϣ��������

BOOL CDlgDownload::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_cancel = false;
	m_hThread = CreateThread( NULL, 0, thread_download, this, 0, NULL );
	return TRUE;  // return TRUE unless you set the focus to a control
}

void CDlgDownload::OnDestroy()
{
	WaitForSingleObject( m_hThread, -1 );
	CloseHandle( m_hThread );
	CDialog::OnDestroy();
}

LRESULT CDlgDownload::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	if( message == WM_USER + 1001 )
	{
		if( ((int)wParam) == -1 )//end ok
		{
			EndDialog( IDOK );
			return 0;
		}
		else if( ((int)wParam) == -2 )//end cancel
		{
			EndDialog( IDCANCEL );
			return 0;
		}
		else if( lParam == 0 )//����δ֪
		{
			m_pDownload.EnableWindow( FALSE );
			m_sPrompt.Format( _T("download: %d bytes"), wParam );
			UpdateData( FALSE );
		}
		else//֪������
		{
			m_pDownload.SetRange32( 0, lParam );
			m_pDownload.SetPos( wParam );
			m_sPrompt.Format( _T("download: %d/%d bytes"), wParam, lParam );
			UpdateData( FALSE );
		}
	}
	return CDialog::DefWindowProc(message, wParam, lParam);
}
