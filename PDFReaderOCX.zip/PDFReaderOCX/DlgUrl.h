#pragma once

#include "resource.h"
// CDlgUrl �Ի���

class CDlgUrl : public CDialog
{
	DECLARE_DYNAMIC(CDlgUrl)

public:
	CDlgUrl(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgUrl();

// �Ի�������
	enum { IDD = IDD_DIALOG_URL };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CString m_sUrl;
	afx_msg void OnBnClickedOk();
};
