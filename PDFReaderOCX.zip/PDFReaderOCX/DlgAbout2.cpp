// DlgAbout2.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "DlgAbout2.h"


// CDlgAbout2 �Ի���

IMPLEMENT_DYNCREATE(CDlgAbout2, CDHtmlDialog)

CDlgAbout2::CDlgAbout2(CWnd* pParent /*=NULL*/)
	: CDHtmlDialog(CDlgAbout2::IDD, CDlgAbout2::IDH, pParent)
{

}

CDlgAbout2::~CDlgAbout2()
{
}

void CDlgAbout2::DoDataExchange(CDataExchange* pDX)
{
	CDHtmlDialog::DoDataExchange(pDX);
}

BOOL CDlgAbout2::OnInitDialog()
{
	CDHtmlDialog::OnInitDialog();
	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

BEGIN_MESSAGE_MAP(CDlgAbout2, CDHtmlDialog)
END_MESSAGE_MAP()

BEGIN_DHTML_EVENT_MAP(CDlgAbout2)
	DHTML_EVENT_ONCLICK(_T("ButtonOK"), OnButtonOK)
	DHTML_EVENT_ONCLICK(_T("ButtonCancel"), OnButtonCancel)
END_DHTML_EVENT_MAP()



// CDlgAbout2 ��Ϣ��������

HRESULT CDlgAbout2::OnButtonOK(IHTMLElement* pElement)
{
	OnOK();
	return S_OK;
}

HRESULT CDlgAbout2::OnButtonCancel(IHTMLElement* /*pElement*/)
{
	OnCancel();
	return S_OK;
}
