
// PDFReader.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "afxwinappex.h"
#include "PDFReader.h"
#include "MainFrm.h"

#include "ChildFrm.h"
#include "PDFReaderDoc.h"
#include "PDFReaderView.h"
#include "PDFWnd.h"
#include "DlgUrl.h"
#include "afxcmn.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

void RegExtType( LPCTSTR sExt, LPCTSTR sDocName, int iIcon = 0 );
void UnRegExtType( LPCTSTR sExt, LPCTSTR sDocName );
LPCTSTR LHGetFileName( LPCTSTR szFullPath );


// CPDFReaderApp

BEGIN_MESSAGE_MAP(CPDFReaderApp, CWinAppEx)
	ON_COMMAND(ID_APP_ABOUT, &CPDFReaderApp::OnAppAbout)
	// Standard file based document commands
	ON_COMMAND(ID_FILE_OPEN, &CWinAppEx::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, &CWinAppEx::OnFilePrintSetup)
	ON_COMMAND(ID_FILE_OPENURL, &CPDFReaderApp::OnFileOpenurl)
END_MESSAGE_MAP()


// CPDFReaderApp construction

CPDFReaderApp::CPDFReaderApp()
{
	m_bHiColorIcons = TRUE;
	m_docid = 0;
	// Place all significant initialization in InitInstance
}

void CPDFReaderApp::LoadPreference()
{
	m_preference.clrBack			= GetProfileInt( _T("Preference"), _T("back"), RGB(160,192,255) );
	m_preference.clrBack_Page		= GetProfileInt( _T("Preference"), _T("page_back"), RGB(255,255,255) );
	m_preference.pageLayout			= GetProfileInt( _T("Preference"), _T("page_layout"), 2 );//continuous
	m_preference.pageLayoutPara1	= GetProfileInt( _T("Preference"), _T("para1"), 0 );
	m_preference.pageLayoutPara2	= GetProfileInt( _T("Preference"), _T("para2"), 0 );
	m_preference.pageLayoutPara3	= GetProfileInt( _T("Preference"), _T("para3"), 0x100 );
	m_preference.pageLayoutPara4	= GetProfileInt( _T("Preference"), _T("para4"), 0x100 );
	m_preference.pageLayoutPara5	= GetProfileInt( _T("Preference"), _T("para5"), 0 );
	m_preference.pageLayoutPara6	= GetProfileInt( _T("Preference"), _T("para6"), 0 );
	m_preference.pageTool			= GetProfileInt( _T("Preference"), _T("page_tool"), 0 );//drag
	m_preference.showOutline		= GetProfileInt( _T("Preference"), _T("show_outline"), TRUE );//outline view
	m_preference.showThumbNails		= GetProfileInt( _T("Preference"), _T("show_thumb"), TRUE );//thubnail view
	m_preference.viewActive			= GetProfileInt( _T("Preference"), _T("active"), 1 );//active outline
	m_preference.viewRatio			= GetProfileInt( _T("Preference"), _T("ratio"), 0 )/1000.0;//0:fit width,-1:fit page
}
void CPDFReaderApp::SavePreference()
{
	WriteProfileInt( _T("Preference"), _T("back"), m_preference.clrBack );
	WriteProfileInt( _T("Preference"), _T("page_back"), m_preference.clrBack_Page );
	WriteProfileInt( _T("Preference"), _T("page_layout"), m_preference.pageLayout );//continuous
	WriteProfileInt( _T("Preference"), _T("para1"), m_preference.pageLayoutPara1 );//continuous
	WriteProfileInt( _T("Preference"), _T("para2"), m_preference.pageLayoutPara2 );//continuous
	WriteProfileInt( _T("Preference"), _T("para3"), m_preference.pageLayoutPara3 );//continuous
	WriteProfileInt( _T("Preference"), _T("para4"), m_preference.pageLayoutPara4 );//continuous
	WriteProfileInt( _T("Preference"), _T("para5"), m_preference.pageLayoutPara5 );//continuous
	WriteProfileInt( _T("Preference"), _T("para6"), m_preference.pageLayoutPara6 );//continuous
	WriteProfileInt( _T("Preference"), _T("page_tool"), m_preference.pageTool );//drag
	WriteProfileInt( _T("Preference"), _T("show_outline"), m_preference.showOutline );//outline view
	WriteProfileInt( _T("Preference"), _T("show_thumb"), m_preference.showThumbNails );//thubnail view
	WriteProfileInt( _T("Preference"), _T("active"), m_preference.viewActive );//active outline
	WriteProfileInt( _T("Preference"), _T("ratio"), m_preference.viewRatio*1000 );//0:fit width,-1:fit page
}

// The one and only CPDFReaderApp object

CPDFReaderApp theApp;
CComModule _Module;


// CPDFReaderApp initialization

BOOL CPDFReaderApp::InitInstance()
{
	if( m_lpCmdLine )
	{
		if( lstrcmp( m_lpCmdLine, _T("/reg") ) == 0 )
		{
			SHDeleteKey( HKEY_CURRENT_USER, _T("Software\\Radaee OCX") );
			RegExtType( _T(".pdf"), _T("PDFReader.PDF"), 1 );
			return false;
		}
		if( lstrcmp( m_lpCmdLine, _T("/unreg") ) == 0 )
		{
			UnRegExtType( _T(".pdf"), _T("PDFReader.PDF") );
			return false;
		}
	}

	// InitCommonControlsEx() is required on Windows XP if an application
	// manifest specifies use of ComCtl32.dll version 6 or later to enable
	// visual styles.  Otherwise, any window creation will fail.
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// Set this to include all the common control classes you want to use
	// in your application.
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	_Module.Init( NULL, m_hInstance );
	CWinAppEx::InitInstance();

	// Initialize OLE libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}
	AfxEnableControlContainer();
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Radaee OCX"));
	LoadPreference();
	LoadStdProfileSettings(6);  // Load standard INI file options (including MRU)

	InitContextMenuManager();
	InitKeyboardManager();
	InitTooltipManager();
	CMFCToolTipInfo ttParams;
	ttParams.m_bVislManagerTheme = TRUE;
	theApp.GetTooltipManager()->SetTooltipParams(AFX_TOOLTIP_TYPE_ALL,
		RUNTIME_CLASS(CMFCToolTipCtrl), &ttParams);

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views
	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(IDR_PDFTYPE,
		RUNTIME_CLASS(CPDFReaderDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CPDFReaderView));
	if (!pDocTemplate)
		return FALSE;
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame || !pMainFrame->LoadFrame(IDR_MAINFRAME))
	{
		delete pMainFrame;
		return FALSE;
	}
	m_pMainWnd = pMainFrame;
	// call DragAcceptFiles only if there's a suffix
	//  In an MDI app, this should occur immediately after setting m_pMainWnd
	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	// Enable DDE Execute open
	EnableShellOpen();
	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line.  Will return FALSE if
	// app was launched with /RegServer, /Register, /Unregserver or /Unregister.
	if( cmdInfo.m_nShellCommand == CCommandLineInfo::FileOpen )
	{
		if (!ProcessShellCommand(cmdInfo))
			return FALSE;
	}

	// The main window has been initialized, so show and update it
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	//RegisterShellFileTypes(TRUE);
	return TRUE;
}



#include "DlgAbout2.h"
// App command to run the dialog
void CPDFReaderApp::OnAppAbout()
{
	CDlgAbout2 dlg;
	dlg.DoModal();
	//CAboutDlg aboutDlg;
	//aboutDlg.DoModal();
}

// CPDFReaderApp customization load/save methods

void CPDFReaderApp::PreLoadState()
{
	BOOL bNameValid;
	CString strName;
	bNameValid = strName.LoadString(IDS_EDIT_MENU);
	ASSERT(bNameValid);
	GetContextMenuManager()->AddMenu(strName, IDR_POPUP_EDIT);
	GetContextMenuManager()->AddMenu(strName, IDR_POPUP_SAVEIMG);
}

void CPDFReaderApp::LoadCustomState()
{
}

void CPDFReaderApp::SaveCustomState()
{
}

// CPDFReaderApp message handlers




int CPDFReaderApp::ExitInstance()
{
	// TODO: �ڴ�����ר�ô����/����û���
	//CRDPDFDoc::pdf_uninit();
	return CWinAppEx::ExitInstance();
}

void CPDFReaderApp::OnFileOpenurl()
{
	CDlgUrl dlg;
	if( dlg.DoModal() != IDOK ) return;
	POSITION pos = m_pDocManager->GetFirstDocTemplatePosition();
	if( pos )
	{
		CDocTemplate *doc_tmp = m_pDocManager->GetNextDocTemplate( pos );
		CDocument *doc = doc_tmp->CreateNewDocument();
		BOOL bAutoDelete = doc->m_bAutoDelete;
		doc->m_bAutoDelete = FALSE;   // don't destroy if something goes wrong
		CFrameWnd* pFrame = doc_tmp->CreateNewFrame(doc, NULL);
		doc->m_bAutoDelete = bAutoDelete;
		if (!doc->OnOpenDocument(dlg.m_sUrl))
		{
			pFrame->DestroyWindow();
			return;
		}
		CString val = dlg.m_sUrl;
		int last = -1;
		int start = 0;
		while( (last = val.Find( '/', start )) >= 0 )
			start = last + 1;
		CString tmp = dlg.m_sUrl.Right( dlg.m_sUrl.GetLength() - start );
		if( tmp.IsEmpty() )
			tmp.Format( _T("untitle%03d"), m_docid++ );
		doc->SetTitle(tmp);
		doc_tmp->InitialUpdateFrame(pFrame, doc, true);
		//doc->SetPathName(dlg.m_sUrl);
		//doc_tmp->OpenDocumentFile(dlg.m_sUrl);
	}
}
