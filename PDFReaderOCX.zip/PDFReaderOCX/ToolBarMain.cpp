// ToolBarMain.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "ToolBarMain.h"


// CToolBarMain

IMPLEMENT_DYNAMIC(CToolBarMain, CMFCToolBar)

CToolBarMain::CToolBarMain()
{

}

CToolBarMain::~CToolBarMain()
{
}


BEGIN_MESSAGE_MAP(CToolBarMain, CMFCToolBar)
END_MESSAGE_MAP()

void CToolBarMain::set_text_goto_page( LPCTSTR str )
{
	int iBtn = CommandToIndex( ID_TOOL_GOTOPAGE );
	if( iBtn >= 0 )
	{
		CMFCToolBarEditBoxButton *pBtn = (CMFCToolBarEditBoxButton *)GetButton( iBtn );
		CString sCmp;
		pBtn->GetEditBox()->GetWindowText( sCmp );
		if( sCmp.IsEmpty() && str == NULL ) return;
		if( str && sCmp == str ) return;
		pBtn->GetEditBox()->SetWindowText( str );
	}
}

void CToolBarMain::OnReset()
{
	CMFCToolBar::OnReset();
	int iBtn = CommandToIndex( ID_TOOL_GOTOPAGE );
	if( iBtn >= 0 )
	{
		UINT id;
		UINT style;
		int img;
		GetButtonInfo( iBtn, id, style, img );
		CMFCToolBarEditBoxButton btn( ID_TOOL_GOTOPAGE, img, ES_CENTER|ES_NUMBER, 100 );
		ReplaceButton( ID_TOOL_GOTOPAGE, btn );
	}
}

// CToolBarMain ��Ϣ��������


