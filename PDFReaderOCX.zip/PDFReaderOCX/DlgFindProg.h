#pragma once
#include "afxcmn.h"


// CDlgFindProg �Ի���
class CPDFDocument;
class CPDFWndViewer;
class CDlgFindProg : public CDialog
{
	DECLARE_DYNAMIC(CDlgFindProg)

public:
	CDlgFindProg(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgFindProg();
	void SetProg( int page, int page_count );
	void SetBkColor( COLORREF clr )
	{
		if( m_clrBack == clr ) return;
		m_clrBack = clr;
		DeleteObject( m_hBack );
		m_hBack = CreateSolidBrush( m_clrBack );
	}
	CPDFDocument *m_pDoc;
	CPDFWndViewer *m_pViewer;
	OLE_HANDLE m_session;

	int m_iMode;
	afx_msg void OnBnClickedCancel();

// �Ի�������
	enum { IDD = IDD_DIALOG_PROGRESS_FIND };

protected:
	CProgressCtrl m_pFind;
	COLORREF m_clrBack;
	HBRUSH m_hBack;
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	DECLARE_MESSAGE_MAP()
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
public:
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
};
