// DlgShortcuts.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "DlgShortcuts.h"
#include "DlgShortcut.h"

// CDlgShortcuts �Ի���

IMPLEMENT_DYNAMIC(CDlgShortcuts, CDialog)

CDlgShortcuts::CDlgShortcuts(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgShortcuts::IDD, pParent)
{

}

CDlgShortcuts::~CDlgShortcuts()
{
}

void CDlgShortcuts::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST_MAIN, m_lstMain);
}


BEGIN_MESSAGE_MAP(CDlgShortcuts, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_EDIT, &CDlgShortcuts::OnBnClickedButtonEdit)
	ON_BN_CLICKED(IDC_BUTTON_ADD, &CDlgShortcuts::OnBnClickedButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, &CDlgShortcuts::OnBnClickedButtonDelete)
	ON_NOTIFY(NM_CLICK, IDC_LIST_MAIN, &CDlgShortcuts::OnNMClickListMain)
END_MESSAGE_MAP()


// CDlgShortcuts ��Ϣ��������
void CDlgShortcuts::OnOK()
{
	if( m_lstMain.GetSelectedCount() != 1 ) return;
	POSITION pos = m_lstMain.GetFirstSelectedItemPosition();
	if( pos )
	{
		int item = m_lstMain.GetNextSelectedItem( pos );
		m_sOpen = m_lstMain.GetItemText( item, 1 );
	}
	CDialog::OnOK();
}

void CDlgShortcuts::OnBnClickedButtonEdit()
{
	if( m_lstMain.GetSelectedCount() != 1 ) return;
	POSITION pos = m_lstMain.GetFirstSelectedItemPosition();
	if( pos )
	{
		int item = m_lstMain.GetNextSelectedItem( pos );
		CDlgShortcut dlg;
		dlg.m_sName = m_arrNames[item];
		dlg.m_sPath = m_arrPaths[item];
		if( dlg.DoModal() != IDOK ) return;
		m_arrNames.SetAt( item, dlg.m_sName );
		m_arrPaths.SetAt( item, dlg.m_sPath );
		OnSave();
	}
}

void CDlgShortcuts::OnBnClickedButtonAdd()
{
	CDlgShortcut dlg;
	if( dlg.DoModal() != IDOK ) return;
	m_arrNames.Add( dlg.m_sName );
	m_arrPaths.Add( dlg.m_sPath );
	int pos = m_arrNames.GetCount() - 1;
	m_lstMain.InsertItem( pos, m_arrNames[pos] );
	m_lstMain.SetItemText( pos, 1, m_arrPaths[pos] );
	OnSave();
}

void CDlgShortcuts::OnBnClickedButtonDelete()
{
	POSITION pos = m_lstMain.GetFirstSelectedItemPosition();
	if( !pos ) return;
	int isels = m_lstMain.GetSelectedCount();
	int isel = 0;
	int *sels = new int[isels];
	while( pos )
	{
		sels[isel++] = m_lstMain.GetNextSelectedItem( pos );
	}
	isel = isels-1;
	while( isel >= 0 )
	{
		m_lstMain.DeleteItem( sels[isel] );
		m_arrNames.RemoveAt( sels[isel] );
		m_arrPaths.RemoveAt( sels[isel] );
		isel--;
	}
	delete []sels;
	OnSave();
}

void CDlgShortcuts::OnSave()
{
	int count = m_arrNames.GetCount();
	theApp.WriteProfileInt( _T("Shortcuts"), _T("Count"), count );
	CString key;
	int pos = 0;
	while( pos < count )
	{
		key.Format( _T("name%02d"), pos );
		theApp.WriteProfileString( _T("Shortcuts"), key, m_arrNames[pos] );
		key.Format( _T("path%02d"), pos );
		theApp.WriteProfileString( _T("Shortcuts"), key, m_arrPaths[pos] );
		pos++;
	}
}

BOOL CDlgShortcuts::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_lstMain.InsertColumn( 0, _T("Name"), 0, 120 );
	m_lstMain.InsertColumn( 1, _T("Destination"), 0, 320 );
	int count = theApp.GetProfileInt( _T("Shortcuts"), _T("Count"), 0 );
	int pos = 0;
	CString key;
	m_arrNames.RemoveAll();
	m_arrPaths.RemoveAll();
	while( pos < count )
	{
		key.Format( _T("name%02d"), pos );
		m_arrNames.Add( theApp.GetProfileString( _T("Shortcuts"), key ) );
		key.Format( _T("path%02d"), pos );
		m_arrPaths.Add( theApp.GetProfileString( _T("Shortcuts"), key ) );
		m_lstMain.InsertItem( pos, m_arrNames[pos] );
		m_lstMain.SetItemText( pos, 1, m_arrPaths[pos] );
		pos++;
	}
	m_lstMain.SetExtendedStyle( m_lstMain.GetExtendedStyle()|LVS_EX_FULLROWSELECT );
	GetDlgItem( IDOK )->EnableWindow( FALSE );
	GetDlgItem( IDC_BUTTON_EDIT )->EnableWindow( FALSE );
	GetDlgItem( IDC_BUTTON_DELETE )->EnableWindow( FALSE );
	return TRUE;
}

void CDlgShortcuts::OnNMClickListMain(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	if( m_lstMain.GetSelectedCount() == 0 )
	{
		GetDlgItem( IDOK )->EnableWindow( FALSE );
		GetDlgItem( IDC_BUTTON_EDIT )->EnableWindow( FALSE );
		GetDlgItem( IDC_BUTTON_DELETE )->EnableWindow( FALSE );
	}
	else
	{
		GetDlgItem( IDOK )->EnableWindow( m_lstMain.GetSelectedCount() == 1 );
		GetDlgItem( IDC_BUTTON_EDIT )->EnableWindow( m_lstMain.GetSelectedCount() == 1 );
		GetDlgItem( IDC_BUTTON_DELETE )->EnableWindow( TRUE );
	}

	*pResult = 0;
}
