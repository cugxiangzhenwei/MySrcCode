#include "stdafx.h"
#include "LHBase.h"
#include "Winspool.h"
#include "lhprinter.h"
#include "math.h"
#define BMP_RESX 23622
#define BMP_RESY 23622

#define PI 3.1415926535897932384626433832795
#define RND_DIV( x, y ) ((x + (y>>1))/y)
#define RND_SCALE( x, y, z ) RND_DIV( x * y, z )

CLHPrinter::CLHPrinter()
{
	m_hdc = NULL;
	m_iRotate = 0;
}

CLHPrinter::~CLHPrinter()
{
}

int CLHPrinter::PrnOpen( const PRN_CONFIG *pConf )
{
	if( m_hdc ) return 1;
	HANDLE hPrinter;
	if( !OpenPrinter( (char *)pConf->sPrnName, &hPrinter, NULL ) )
		return 2;

	DWORD dwNeed;
	PRINTER_INFO_2 *pInfo;
	GetPrinter( hPrinter, 2, NULL, 0, &dwNeed);
	pInfo = (PRINTER_INFO_2 *)LHAlloc( dwNeed );
	GetPrinter( hPrinter, 2, (LPBYTE)pInfo, dwNeed, &dwNeed);

	CopyMemory( &m_devMode, pInfo->pDevMode, sizeof( DEVMODE ) );
	m_devMode.dmDriverExtra = 0;
	LHFree( pInfo );
	ClosePrinter( hPrinter );

	m_hdc = CreateDC( "WINSPOOL", pConf->sPrnName, NULL, NULL );
	if( m_hdc == NULL ) return 2;
	m_conf = *pConf;
	m_caps.iResX = GetDeviceCaps( m_hdc, LOGPIXELSX );
	m_caps.iResY = GetDeviceCaps( m_hdc, LOGPIXELSY );
	m_caps.iPageCX = GetDeviceCaps( m_hdc, PHYSICALWIDTH );
	m_caps.iPageCY = GetDeviceCaps( m_hdc, PHYSICALHEIGHT );
	m_caps.iMarginX = GetDeviceCaps( m_hdc, PHYSICALOFFSETX );
	m_caps.iMarginY = GetDeviceCaps( m_hdc, PHYSICALOFFSETY );
	return 0;
}

int CLHPrinter::PrnClose()
{
	if( m_hdc )
		DeleteDC( m_hdc );
	m_hdc = NULL;
	return 0;
}

int CLHPrinter::PrnDocStart( const char *sDocName )
{
	DOCINFO di;
	di.cbSize = sizeof(DOCINFO);
	di.fwType = 0;
	di.lpszDatatype = NULL;
	di.lpszOutput = NULL;
	di.lpszDocName = sDocName;
	if( StartDoc( m_hdc, &di ) )
		return 0;
	else
		return 1;
}

int CLHPrinter::PrnDocEnd()
{
	if( EndDoc( m_hdc ) )
		return 0;
	else
		return 1;
}

int CLHPrinter::PrnPageBmp( void *pBits, int w, int h )
{
	BITMAPINFO bi;
	bi.bmiHeader.biBitCount = 24;
	bi.bmiHeader.biClrImportant = 0;
	bi.bmiHeader.biClrUsed = 0;
	bi.bmiHeader.biCompression = BI_RGB;
	bi.bmiHeader.biHeight = -h;
	bi.bmiHeader.biWidth = w;
	bi.bmiHeader.biPlanes = 1;
	bi.bmiHeader.biSizeImage = (bi.bmiHeader.biWidth * 3 + 3) & (~3);
	bi.bmiHeader.biSizeImage *= bi.bmiHeader.biHeight;
	bi.bmiHeader.biSize = sizeof(bi.bmiHeader);
	bi.bmiHeader.biXPelsPerMeter = 0;
	bi.bmiHeader.biYPelsPerMeter = 0;

	StretchDIBits( m_hdc, 0, 0, w, h, 0, 0, w, h, pBits, &bi, DIB_RGB_COLORS, SRCCOPY );
	return 0;
}

int CLHPrinter::PrnPageStart()
{
	if( StartPage( m_hdc ) )
		return 0;
	else
		return 1;
}

int CLHPrinter::PrnPageEnd()
{
	if( EndPage( m_hdc ) )
		return 0;
	else
		return 1;
}

int CLHPrinter::PrnPageAdapt( PRN_PAGE_USER *pUser, PRN_PAGE_PRN *pSpaces, int iMax )
{
	int iPage;
	int iPageCX = m_caps.iPageCX;
	int iPageCY = m_caps.iPageCY;
	iPageCX *= pUser->iUserResX;
	iPageCX /= m_caps.iResX;
	iPageCY *= pUser->iUserResY;
	iPageCY /= m_caps.iResY;
	iPageCX++;
	iPageCY++;
	if( iPageCX >= pUser->iPageCX && iPageCY >= pUser->iPageCY )//����ģʽ��û�в��
	{
		if( pUser->iCenter & CENTER_HORZ )
			pSpaces[0].rcPage.left = (iPageCX - pUser->iPageCX)/2;
		else
			pSpaces[0].rcPage.left = pUser->fOffX * pUser->iUserResX / 2.54;

		if( pUser->iCenter & CENTER_VERT )
			pSpaces[0].rcPage.top = (iPageCY - pUser->iPageCY)/2;
		else
			pSpaces[0].rcPage.top = pUser->fOffY * pUser->iUserResY / 2.54;
		pSpaces[0].rcPage.right = pSpaces[0].rcPage.left + pUser->iPageCX;
		pSpaces[0].rcPage.bottom = pSpaces[0].rcPage.top + pUser->iPageCY;
		pSpaces[0].iRotate = 0;
		pSpaces[0].iUserResX = pUser->iUserResX;
		pSpaces[0].iUserResY = pUser->iUserResY;
		iPage = 1;
	}
	else
	{
		if( pUser->iAutoRotate && iPageCX >= pUser->iPageCY && iPageCY >= pUser->iPageCX )//��תģʽ
		{
			if( pUser->iCenter & CENTER_HORZ )
				pSpaces[0].rcPage.left = (iPageCX - pUser->iPageCY)/2;
			else
				pSpaces[0].rcPage.left = pUser->fOffX * pUser->iUserResX / 2.54;

			if( pUser->iCenter & CENTER_VERT )
				pSpaces[0].rcPage.top = (iPageCY - pUser->iPageCX)/2;
			else
				pSpaces[0].rcPage.top = pUser->fOffY * pUser->iUserResY / 2.54;
			pSpaces[0].rcPage.right = pSpaces[0].rcPage.left + pUser->iPageCX;
			pSpaces[0].rcPage.bottom = pSpaces[0].rcPage.top + pUser->iPageCY;
			pSpaces[0].iRotate = pUser->iAutoRotate;
			pSpaces[0].iUserResX = pUser->iUserResY;
			pSpaces[0].iUserResY = pUser->iUserResX;
			iPage = 1;
		}
		else//��ҳ
		{
			int iPageX;
			int iPageY;
			int iTotalX;
			int iTotalY;
			iTotalX = pUser->iPageCX;
			iTotalY = pUser->iPageCY;
			iPage = 0;
			if( (pUser->iCenter & CENTER_HORZ) && iTotalX < iPageCX - m_caps.iResX )//ˮƽ����
			{
				for( iPageY = 0; iTotalY >= m_caps.iResY/2; iPageY++ )
				{
					pSpaces[iPage].rcPage.left = (iPageCX - pUser->iPageCX)/2;
					pSpaces[iPage].rcPage.top = pUser->fOffY * pUser->iUserResY / 2.54;
					pSpaces[iPage].rcPage.top += iTotalY - pUser->iPageCY;
					pSpaces[iPage].rcPage.right = pSpaces[iPage].rcPage.left + iPageCX;
					pSpaces[iPage].rcPage.bottom = pSpaces[iPage].rcPage.top + iPageCY;

					pSpaces[iPage].iRotate = 0;
					pSpaces[iPage].iUserResX = pUser->iUserResX;
					pSpaces[iPage].iUserResY = pUser->iUserResY;
					iTotalY -= iPageCY;
					iPage++;
				}
			}
			else if( (pUser->iCenter & CENTER_VERT) && iTotalY < iPageCY - m_caps.iResY )//��ֱ����
			{
				for( iPageX = 0; iTotalX >= m_caps.iResX/2; iPageX++ )
				{
					pSpaces[iPage].rcPage.left = pUser->fOffX * pUser->iUserResX / 2.54;
					pSpaces[iPage].rcPage.left += iTotalX - pUser->iPageCX;
					pSpaces[iPage].rcPage.top = (iPageCY - pUser->iPageCY)/2;

					pSpaces[iPage].rcPage.right = pSpaces[iPage].rcPage.left + iPageCX;
					pSpaces[iPage].rcPage.bottom = pSpaces[iPage].rcPage.top + iPageCY;

					pSpaces[iPage].iRotate = 0;
					pSpaces[iPage].iUserResX = pUser->iUserResX;
					pSpaces[iPage].iUserResY = pUser->iUserResY;
					iTotalX -= iPageCX;
					iPage++;
				}
			}
		}
	}
	return iPage;
}

int CLHPrinter::PrnPageSetSpace( const PRN_PAGE_PRN *pSpace )
{
	XFORM form;
	form.eM11 = m_caps.iResX;
	form.eM11 /= pSpace->iUserResX;
	form.eM12 = 0;
	form.eM21 = 0;
	form.eM22 = m_caps.iResY;
	form.eM22 /= pSpace->iUserResY;
	form.eDx = pSpace->rcPage.left;
	form.eDy = pSpace->rcPage.top;
    SetGraphicsMode(m_hdc, GM_ADVANCED);
	::SetWorldTransform( m_hdc, &form );//����ת֮�ⶼ��֧�֣�
	if( m_iRotate != pSpace->iRotate )
	{
		m_iRotate = pSpace->iRotate;
		if( m_iRotate )
			m_devMode.dmOrientation = DMORIENT_PORTRAIT;
		else
			m_devMode.dmOrientation = DMORIENT_LANDSCAPE;
		ResetDC( m_hdc, &m_devMode );
	}
	return 0;
}
