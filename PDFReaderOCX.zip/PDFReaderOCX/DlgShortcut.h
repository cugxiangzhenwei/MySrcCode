#pragma once


// CDlgShortcut �Ի���

class CDlgShortcut : public CDialog
{
	DECLARE_DYNAMIC(CDlgShortcut)

public:
	CDlgShortcut(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgShortcut();

// �Ի�������
	enum { IDD = IDD_DIALOG_EDIT_SHORTCUT };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CString m_sName;
	CString m_sPath;
	BOOL m_bAddFromView;
	afx_msg void OnBnClickedBrowse();
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
};
