#pragma once

#include "resource.h"
#include "PDFWnd.h"
#include "afxcmn.h"
// CDlgDownload �Ի���

class CDlgDownload : public CDialog
{
	DECLARE_DYNAMIC(CDlgDownload)

public:
	CDlgDownload(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgDownload();

// �Ի�������
	enum { IDD = IDD_DIALOG_PROGRESS_DOWNLOAD };

	CPDFUrlBuffer *m_url;
protected:
	HANDLE m_hThread;
	BOOL m_cancel;
	static DWORD WINAPI thread_download( LPVOID pararm );

	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
protected:
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
public:
	CProgressCtrl m_pDownload;
	CString m_sPrompt;
};
