#pragma once

#include "Winspool.h"
#include "afxwin.h"
#include "PDFWnd.h"

// CDlgPrint �Ի���

class CDlgPrint : public CDialog
{
	DECLARE_DYNAMIC(CDlgPrint)

public:
	CDlgPrint(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgPrint();

// �Ի�������
	enum { IDD = IDD_DIALOG_PRINTER };


	static void PrnListInit();
	static void PrnListUninit();
	CPDFDocument *m_pDoc;
	int m_iPrnSel;
	int m_iPageCur;

	int m_iPage1;
	int m_iPage2;
	int m_iCopies;
	int m_iAlign;
	int m_iArrange;
	HANDLE get_printer(){return ms_pConfs[m_iPrnSel].hPrinter;}
	DEVMODE *get_dev_mode(){return ms_pConfs[m_iPrnSel].pDModeCur;}
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	DECLARE_MESSAGE_MAP()
	virtual BOOL OnInitDialog();
protected:
	static PRINTER_INFO_4 *ms_pInfos;
	static DWORD ms_dwNum;
	static struct PRN_CONFIG
	{
		DEVMODE *pDModeCur;
		HANDLE hPrinter;
	}* ms_pConfs;

	CComboBox m_cPrinters;
	CStatic m_sStatus;
	CStatic m_sType;
	afx_msg void OnCbnSelchangeComboPrinters();
	CComboBox m_cAlign;
	CComboBox m_cArrange;
public:
	afx_msg void OnBnClickedRadioAll();
	afx_msg void OnBnClickedRadioCurrent();
	afx_msg void OnBnClickedRadioCustom();
	afx_msg void OnBnClickedButtonProperty();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedOk();
};
