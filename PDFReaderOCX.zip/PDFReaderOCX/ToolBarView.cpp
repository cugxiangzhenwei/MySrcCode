// ToolBarView.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "ToolBarView.h"


// CToolBarView

IMPLEMENT_DYNAMIC(CToolBarView, CMFCToolBar)

CToolBarView::CToolBarView()
{

}

CToolBarView::~CToolBarView()
{
}


BEGIN_MESSAGE_MAP(CToolBarView, CMFCToolBar)
END_MESSAGE_MAP()


void CToolBarView::set_text_zoomto( LPCTSTR str )
{
	int iBtn = CommandToIndex( ID_VIEW_ZOOMTO );
	if( iBtn >= 0 )
	{
		CMFCToolBarComboBoxButton *pBtn = (CMFCToolBarComboBoxButton *)GetButton( iBtn );
		CString sCmp;
		pBtn->GetEditCtrl()->GetWindowText( sCmp );
		if( sCmp.IsEmpty() && str == NULL ) return;
		if( str && sCmp == str ) return;
		pBtn->GetEditCtrl()->SetWindowText( str );
	}
}

void CToolBarView::get_text_find( CString &val )
{
	int iBtn = CommandToIndex( ID_EDIT_FIND );
	if( iBtn >= 0 )
	{
		CMFCToolBarEditBoxButton *pBtn = (CMFCToolBarEditBoxButton *)GetButton( iBtn );
		pBtn->GetEditBox()->GetWindowText( val );
	}
}

void CToolBarView::set_text_find( LPCTSTR str )
{
	int iBtn = CommandToIndex( ID_EDIT_FIND );
	if( iBtn >= 0 )
	{
		CMFCToolBarEditBoxButton *pBtn = (CMFCToolBarEditBoxButton *)GetButton( iBtn );
		if( pBtn->GetEditBox()->GetWindowTextLength() == 0 && str == NULL ) return;
		pBtn->GetEditBox()->SetWindowText( str );
	}
}

void CToolBarView::OnReset()
{
	CMFCToolBar::OnReset();
	int iBtn = CommandToIndex( ID_VIEW_ZOOMTO );
	if( iBtn >= 0 )
	{
		UINT id;
		UINT style;
		int img;
		GetButtonInfo( iBtn, id, style, img );
		CMFCToolBarComboBoxButton btn( ID_VIEW_ZOOMTO, img, CBS_DROPDOWN, 100 );
		btn.AddItem( _T("10%") );
		btn.AddItem( _T("30%") );
		btn.AddItem( _T("50%") );
		btn.AddItem( _T("70%") );
		btn.AddItem( _T("100%") );
		btn.AddItem( _T("150%") );
		btn.AddItem( _T("200%") );
		btn.AddItem( _T("300%") );
		btn.AddItem( _T("400%") );
		btn.AddItem( _T("600%") );
		btn.SetDropDownHeight( 180 );
		ReplaceButton( ID_VIEW_ZOOMTO, btn );
	}
	if( (iBtn = CommandToIndex( ID_EDIT_FIND )) >= 0 )
	{
		UINT id;
		UINT style;
		int img;
		GetButtonInfo( iBtn, id, style, img );
		CMFCToolBarEditBoxButton btn( ID_EDIT_FIND, img, ES_AUTOHSCROLL, 120 );
		ReplaceButton( ID_EDIT_FIND, btn );
	}

	if( (iBtn = CommandToIndex( ID_INTERNAL_FINDOPTION )) >= 0 )
	{
		HMENU menu = LoadMenu( theApp.m_hInstance, MAKEINTRESOURCE(IDR_POPUP_FIND_OPTION) );
		HMENU sub = GetSubMenu( menu, 0 );
		CMFCToolBarMenuButton btn( ID_INTERNAL_FINDOPTION, sub, -1, NULL, TRUE );
		ReplaceButton( ID_INTERNAL_FINDOPTION, btn );
	}
}

// CToolBarView ��Ϣ��������


