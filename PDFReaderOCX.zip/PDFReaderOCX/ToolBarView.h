#pragma once


// CToolBarView

class CToolBarView : public CMFCToolBar
{
	DECLARE_DYNAMIC(CToolBarView)

public:
	CToolBarView();
	virtual ~CToolBarView();
	void set_text_zoomto( LPCTSTR str );
	void set_text_find( LPCTSTR str );
	void get_text_find( CString &val );
protected:
	virtual void OnReset();
	DECLARE_MESSAGE_MAP()
};


