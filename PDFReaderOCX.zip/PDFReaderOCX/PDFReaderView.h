// PDFReaderView.h : interface of the CPDFReaderView class
//

#pragma once
#include "PDFWnd.h"
#include "DlgFindProg.h"
#include "DlgPrinting.h"

#define WM_INIT_UPDATE (WM_USER + 1001)

class CPDFReaderDoc;
class CWndMini;
class CWndOutlines;
class CToolBarView;
class CToolBarMain;
class CPDFReaderView : public CView
{
protected: // create from serialization only
	CPDFReaderView();
	DECLARE_DYNCREATE(CPDFReaderView)
// Implementation
public:
	virtual ~CPDFReaderView();
	void roll_papers( int papers )
	{
		if( m_viewStyle == 6 )
		{
			m_roll.roll_pages( papers );
		}
		if( m_viewStyle == 5 )
		{
			if( papers > 0 )
				m_book.roll_papers_forward( papers );
			if( papers < 0 )
				m_book.roll_papers_backward( -papers );
		}
	}
	void goto_page( int page )
	{
		if( m_viewStyle == 6 )
			m_roll.put_current_page( page );
		else if( m_viewStyle == 5 )
			m_book.put_current_page( page );
		else
			m_viewer.goto_pos( page, 0 );
	}
	void goto_bm( int page, double top )
	{
		if( m_viewStyle == 6 )
			m_roll.put_current_page( page );
		else if( m_viewStyle == 5 )
			m_book.put_current_page( page );
		else
			m_viewer.goto_pos( page, top );
	}
	void set_ratio( double ratio )
	{
		m_viewer.put_ratio( ratio );
	}
	double get_ratio(){return m_viewer.get_ratio();}
	void set_view_style( int type )
	{
		CPDFReaderDoc *pDoc = GetDocument();
		CPDFDocument *pRDDoc = pDoc->GetRDDoc();
		RECT rect;
		GetClientRect( &rect );
		if( type == 6 )
		{
			if( m_viewStyle != 6 )
			{
				int page;
				if( m_viewStyle == 5 )
					page = m_book.get_current_page();
				else
					page = m_viewer.get_current_page();
				m_viewer.detach_doc();
				m_book.detach_doc();
				m_roll.put_Orientation( theApp.m_preference.pageLayoutPara6 );
				m_roll.attach_doc( pRDDoc->m_lpDispatch );
				m_roll.put_current_page( page );
				m_viewStyle = 6;
				OnSize( SIZE_RESTORED, rect.right - rect.left, rect.bottom - rect.top );
			}
		}
		else if( type == 5 )
		{
			if( m_viewStyle != 5 )
			{
				int page;
				if( m_viewStyle == 6 )
					page = m_roll.get_current_page();
				else
					page = m_viewer.get_current_page();
				m_viewer.detach_doc();
				m_roll.detach_doc();
				m_book.attach_doc( pRDDoc->m_lpDispatch );
				m_book.put_current_page( page );
				m_viewStyle = 5;
				OnSize( SIZE_RESTORED, rect.right - rect.left, rect.bottom - rect.top );
			}
		}
		else
		{
			switch( type )
			{
			case 1:
				m_viewer.put_ShowCover( theApp.m_preference.pageLayoutPara1 & 0xFF );
				m_viewer.put_PagesLeftToRight( theApp.m_preference.pageLayoutPara1 >> 8 );
				break;
			case 2:
				m_viewer.put_ShowCover( theApp.m_preference.pageLayoutPara2 & 0xFF );
				m_viewer.put_PagesLeftToRight( theApp.m_preference.pageLayoutPara2 >> 8 );
				break;
			case 3:
				m_viewer.put_ShowCover( theApp.m_preference.pageLayoutPara3 & 0xFF );
				m_viewer.put_PagesLeftToRight( theApp.m_preference.pageLayoutPara3 >> 8 );
				break;
			case 4:
				m_viewer.put_ShowCover( theApp.m_preference.pageLayoutPara4 & 0xFF );
				m_viewer.put_PagesLeftToRight( theApp.m_preference.pageLayoutPara4 >> 8 );
				break;
			}
			m_viewer.put_layout( type - 1 );
			if( m_viewStyle > 4 )
			{
				int page;
				if( m_viewStyle == 5 )
					page = m_book.get_current_page();
				else
					page = m_roll.get_current_page();
				m_book.detach_doc();
				m_roll.detach_doc();
				m_viewer.attach_doc( pRDDoc->m_lpDispatch );
				m_viewer.put_current_page( page );
				m_viewStyle = type;
				OnSize( SIZE_RESTORED, rect.right - rect.left, rect.bottom - rect.top );
			}
			m_viewStyle = type;
		}
	}
	int get_page_count()
	{
		return m_doc->get_page_count();
	}
	int get_view_style()
	{
		return m_viewStyle;
	}
	void get_page_size_inch( int page, double &inch_width, double &inch_height )
	{
		inch_width = m_doc->get_page_width( page )/72;
		inch_height = m_doc->get_page_height( page )/72;
	}
	int get_pageno()
	{
		if( m_viewStyle == 6 )
			return m_roll.get_current_page();
		else if( m_viewStyle == 5 )
			return m_book.get_current_page();
		else
			return m_viewer.get_current_page();
	}
	pdf_tool get_drag_mode()
	{
		return (pdf_tool)m_viewer.get_tool();
	}
	pdf_fit_mode get_fit_mode()
	{
		return (pdf_fit_mode)m_viewer.get_fit_mode();
	}
	void set_fit_mode( pdf_fit_mode mode )
	{
		m_viewer.put_fit_mode( mode );
	}
	void set_drag_mode( pdf_tool mode )
	{
		m_viewer.put_tool( mode );
	}
	BOOL is_find_case(){return m_findCase;}
	BOOL is_find_whole_word(){return m_findWholeWord;}
	void set_find_case( BOOL iscase ){m_findCase = iscase;}
	void set_find_whole_word( BOOL whole_word ){m_findWholeWord = whole_word;}
	void set_views(CPDFWndThumbs *pMini, CPDFWndBMTree *pOutline, CMFCCaptionBar *pCaption)
	{
		m_pMini = pMini;
		m_pOutlines = pOutline;
		m_pCaption = pCaption;
		CString sVal;
		CString sTmp;
		sVal = _T("Version:[");
		sVal += m_doc->get_meta_data( _T("#ver") );
		sVal += _T("]  Title:[");
		sTmp = m_doc->get_meta_data( _T("Title") );
		if( sTmp.IsEmpty() )
			sVal += _T("null");
		else
			sVal += sTmp;
		sVal += _T("]  Author:[");
		sTmp = m_doc->get_meta_data( _T("Author") );
		if( sTmp.IsEmpty() )
			sVal += _T("null");
		else
			sVal += sTmp;
		sVal += _T("]");

		m_pCaption->SetText(sVal, CMFCCaptionBar::ALIGN_LEFT);
		m_viewer.notifee = pMini;
	}
	CPDFDocument *get_doc(){return m_doc;}
	CPDFWndViewer *get_viewer(){return &m_viewer;}
	CPDFWndBook *get_book(){return &m_book;}
	CPDFWndRoll *get_roll(){return &m_roll;}
	void do_print( HANDLE prn, int page_start, int page_end, int copies, int align, int arrange );
	inline void page_down(){if( m_viewStyle < 5 ) m_viewer.scroll_page_down();}
	inline void page_up(){if( m_viewStyle < 5 ) m_viewer.scroll_page_up();}
// Attributes
public:
	inline CPDFReaderDoc* GetDocument() const {return reinterpret_cast<CPDFReaderDoc*>(m_pDocument);}

// Operations
public:
	CDlgFindProg m_dlgFind;
	CDlgPrinting m_dlgPrint;
	CMDIChildWndEx *m_pOwnner;
	CPDFWndThumbs *m_pMini;
	CPDFWndBMTree *m_pOutlines;
	CMFCCaptionBar *m_pCaption;
	CToolBarView *m_pTView;
	CToolBarMain *m_pTMain;
// Overrides
protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

protected:
	CPDFDocument *m_doc;
	CPDFWndViewer m_viewer;
	CPDFWndBook m_book;
	CPDFWndRoll m_roll;
	int m_viewStyle;
	bool m_findCase;
	bool m_findUp;
	bool m_findWholeWord;
	bool m_findStatus;
	bool m_bAutoScroll;
	CString m_sFind;
	int m_findPage;
	int m_findObj;
	int m_iSavePage;
	POINT m_ptSavePage;
	OLE_HANDLE m_finder;
	void proLoadPreference();

// Generated message map functions
protected:
	virtual void OnInitialUpdate();
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
	afx_msg void OnFilePrintPreview();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnDestroy();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnEditCopy();
	afx_msg void OnUpdateEditCopy(CCmdUI *pCmdUI);
	afx_msg void OnFileProperty();
	afx_msg void OnUpdateFindCase(CCmdUI *pCmdUI);
	afx_msg void OnFindCase();
	afx_msg void OnUpdateFindWholeword(CCmdUI *pCmdUI);
	afx_msg void OnFindWholeword();
	afx_msg void OnEditFind();
	afx_msg void OnInternalFindup();
	afx_msg void OnInternalFinddown();
	afx_msg void OnFileSaveAs();
	afx_msg void OnToolAddshortcuts();
	afx_msg void OnViewAutoscroll();
	afx_msg void OnViewLineDown();
	afx_msg void OnViewLineUp();
	afx_msg void OnViewPageDown();
	afx_msg void OnViewPageUp();
	afx_msg void OnUpdateViewAutoscroll(CCmdUI *pCmdUI);
	afx_msg void OnKillFocus(CWnd* pNewWnd);
	afx_msg void OnSaveClipboard();
	afx_msg void OnSaveFile();
	afx_msg void OnEditSaveimage();
	afx_msg void OnUpdateEditSaveimage(CCmdUI *pCmdUI);
	afx_msg void OnFileSaveCopy();
};
