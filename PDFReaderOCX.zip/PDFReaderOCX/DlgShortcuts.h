#pragma once
#include "afxcmn.h"


// CDlgShortcuts �Ի���

class CDlgShortcuts : public CDialog
{
	DECLARE_DYNAMIC(CDlgShortcuts)

public:
	CDlgShortcuts(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgShortcuts();
	CString m_sOpen;
// �Ի�������
	enum { IDD = IDD_DIALOG_SHORTCUTS };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
	CListCtrl m_lstMain;
	CStringArray m_arrNames;
	CStringArray m_arrPaths;
	void OnSave();

	afx_msg void OnBnClickedButtonEdit();
	afx_msg void OnBnClickedButtonAdd();
	afx_msg void OnBnClickedButtonDelete();
	virtual BOOL OnInitDialog();
	afx_msg void OnNMClickListMain(NMHDR *pNMHDR, LRESULT *pResult);
	virtual void OnOK();
};
