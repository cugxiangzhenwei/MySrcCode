#pragma once

// CDlgProperty �Ի���

class CDlgProperty : public CDialog
{
	DECLARE_DYNAMIC(CDlgProperty)

public:
	CDlgProperty(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgProperty();

// �Ի�������
	enum { IDD = IDD_DIALOG_PROPERTY };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CString m_sVer;
	int m_iPages;
	CString m_sTitle;
	CString m_sAuthor;
	CString m_sCreator;
	CString m_sProducer;
	CString m_sKeywords;
	CString m_sFileName;
};
