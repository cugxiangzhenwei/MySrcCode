// DlgPrinting.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "DlgPrinting.h"


// CDlgPrinting �Ի���

IMPLEMENT_DYNAMIC(CDlgPrinting, CDialog)

CDlgPrinting::CDlgPrinting(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPrinting::IDD, pParent)
{

}

CDlgPrinting::~CDlgPrinting()
{
}

void CDlgPrinting::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS_PRINT, m_pPrint);
}


BEGIN_MESSAGE_MAP(CDlgPrinting, CDialog)
END_MESSAGE_MAP()


// CDlgPrinting ��Ϣ��������

BOOL CDlgPrinting::OnInitDialog()
{
	CDialog::OnInitDialog();
	double ratio = 1;
	switch( arrange )
	{
	case 0:
		ratio = 1;
		break;
	case 1:
		ratio = .7171;
		break;
	case 2:
		ratio = .5;
		break;
	}
	m_session = doc->print( wsTitle, page_start, page_end, ratio, copies, align, (long)printer );
	if( m_session == NULL )
	{
		MessageBox( _T("this document is not allowed to print!") );
		EndDialog( IDOK );
	}
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlgPrinting::OnCancel()
{
	doc->cancel_session( m_session );
}

LRESULT CDlgPrinting::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch( message )
	{
	case WM_PRINTING:
		if( (int)wParam < 0 )
		{
			if( lParam )
				EndDialog( IDOK );
			else
				EndDialog( IDCANCEL );
		}
		else
		{
			m_pPrint.SetRange32( 0, lParam );
			m_pPrint.SetPos( wParam );
		}
		return 0;
	default:
		return CDialog::DefWindowProc(message, wParam, lParam);
	}
	//return CDialog::DefWindowProc(message, wParam, lParam);
}
