#ifndef _LH_CLASS_PRINTER_H_
#define _LH_CLASS_PRINTER_H_

#define MAX_PRNNAME 64
#define CENTER_NONE 0
#define CENTER_HORZ 1
#define CENTER_VERT 2

#define PAGES_ALL 0
#define PAGES_CUR -1
typedef struct _PRN_CONFIG
{
	char sPrnName[MAX_PRNNAME];
	int iPageStart;
	int iPageCount;
	int iCopies;
	int iRotates;//��ת�Ƕ�
	int iCenter;
	float fOffX;
	float fOffY;
}PRN_CONFIG;

typedef struct _PRN_CAPS
{
	int iResX;
	int iResY;
	int iPageCX;
	int iPageCY;
	int iMarginX;
	int iMarginY;
}PRN_CAPS;

typedef struct _PRN_PAGE_USER
{
	int iUserResX;
	int iUserResY;
	float fOffX;//����������
	float fOffY;//����������
	int iPageCX;
	int iPageCY;
	int iCenter;
	int iAutoRotate;
}PRN_PAGE_USER;

typedef struct _PRN_PAGE_PRN
{
	int iUserResX;
	int iUserResY;
	int iRotate;//��ת�Ƕ�
	RECT rcPage;//��ת֮ǰ�ģ���������
}PRN_PAGE_PRN;


class CLHPrinter
{
public:
	CLHPrinter();
	virtual ~CLHPrinter();
	int PrnOpen( const PRN_CONFIG *pConf );
	int PrnClose();
	int PrnDocStart( const char *sDocName );
	int PrnDocEnd();
	int PrnPageStart();

	int PrnPageAdapt( PRN_PAGE_USER *pUser, PRN_PAGE_PRN *pSpaces, int iMax );//ҳ������Ӧ
	int PrnPageSetSpace( const PRN_PAGE_PRN *pSpace );

	int PrnPageEnd();

	int PrnPageBmp( void *pBits, int w, int h );

protected:
	PRN_CONFIG m_conf;
	PRN_CAPS m_caps;
	HDC m_hdc;
	DEVMODE m_devMode;
	int m_iFonts;
	int m_iRotate;
};

#endif
