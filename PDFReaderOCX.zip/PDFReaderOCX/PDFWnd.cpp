#include "StdAfx.h"
#include "PDFWnd.h"




/////////////////////////////////////////////////////////////////////////////
// CPDFWndBMTree

IMPLEMENT_DYNCREATE(CPDFWndBMTree, CWnd)

/////////////////////////////////////////////////////////////////////////////
// CPDFWndBMTree ����

/////////////////////////////////////////////////////////////////////////////
// CPDFWndBMTree ����
STDMETHODIMP CPDFWndBMTree::OnItemSelected( BSTR label, LONG page_no, DOUBLE top )
{
	if(notifee) notifee->goto_pos( page_no, top );
	if( book ) book->put_current_page( page_no );
	if( roll ) roll->put_current_page( page_no );
	return S_OK;
}

STDMETHODIMP CPDFWndBMTree::OnAccessURI( BSTR uri )
{
	if(notifee) notifee->access_uri( uri );
	return S_OK;
}




/////////////////////////////////////////////////////////////////////////////
// CPDFWndThumbs

IMPLEMENT_DYNCREATE(CPDFWndThumbs, CWnd)

/////////////////////////////////////////////////////////////////////////////
// CPDFWndThumbs ����

/////////////////////////////////////////////////////////////////////////////
// CPDFWndThumbs ����

STDMETHODIMP CPDFWndThumbs::OnClickPage( LONG page )
{
	if(notifee) notifee->goto_pos( page, 0 );
	if( book ) book->put_current_page( page );
	if( roll ) roll->put_current_page( page );
	return S_OK;
}




/////////////////////////////////////////////////////////////////////////////
// CPDFWndViewer

IMPLEMENT_DYNCREATE(CPDFWndViewer, CWnd)

/////////////////////////////////////////////////////////////////////////////
// CPDFWndViewer ����

/////////////////////////////////////////////////////////////////////////////
// CPDFWndViewer ����

STDMETHODIMP CPDFWndViewer::OnFinding( LONG page_no, LONG page_count )
{
	if(ownner) ownner->PostMessage( WM_FINDING, page_no, page_count );
	return S_OK;
}

STDMETHODIMP CPDFWndViewer::OnPageNoChanged( LONG page )
{
	if(notifee) notifee->goto_page( page );
	if(ownner) ownner->PostMessage( WM_PAGE_CHANGED, page, 0 );
	return S_OK;
}

STDMETHODIMP CPDFWndViewer::OnRatioChanged( DOUBLE ratio )
{
	if(ownner) ownner->PostMessage( WM_RATIO_CHANGED, 0, 0 );
	return S_OK;
}

STDMETHODIMP CPDFWndViewer::OnSnapshot( LONG x, LONG y )
{
	if(ownner) ownner->PostMessage( WM_SNAPSHOT, x, y );
	return S_OK;
}

STDMETHODIMP CPDFWndViewer::OnAccessURI( BSTR uri )
{
	access_uri( uri );
	return S_OK;
}

/////////////////////////////////////////////////////////////////////////////
// CPDFWndBook

IMPLEMENT_DYNCREATE(CPDFWndBook, CWnd)

/////////////////////////////////////////////////////////////////////////////
// CPDFWndBook ����

/////////////////////////////////////////////////////////////////////////////
// CPDFWndBook ����

STDMETHODIMP CPDFWndBook::OnPageNoChanged( LONG page )
{
	if(ownner) ownner->PostMessage( WM_PAGE_CHANGED, page, 0 );
	return S_OK;
}


/////////////////////////////////////////////////////////////////////////////
// CPDFWndRoll

IMPLEMENT_DYNCREATE(CPDFWndRoll, CWnd)

/////////////////////////////////////////////////////////////////////////////
// CPDFWndRoll ����

/////////////////////////////////////////////////////////////////////////////
// CPDFWndRoll ����

STDMETHODIMP CPDFWndRoll::OnPageNoChanged( LONG page )
{
	if(ownner) ownner->PostMessage( WM_PAGE_CHANGED, page, 0 );
	return S_OK;
}
