#pragma once

#include "resource.h"
// CDlgSave �Ի���

class CDlgSave : public CDialog
{
	DECLARE_DYNAMIC(CDlgSave)

public:
	CDlgSave(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgSave();

// �Ի�������
	enum { IDD = IDD_DIALOG_SAVE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CString m_sDest;
	BOOL m_bRemPassword;
	afx_msg void OnBnClickedButtonBrowse();
	afx_msg void OnBnClickedOk();
};
