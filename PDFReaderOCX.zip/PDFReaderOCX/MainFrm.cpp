
// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "PDFReader.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "DlgShortcuts.h"
#include "DlgPreference.h"
#include "DlgPrint.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CMDIFrameWndEx)

const int  iMaxUserToolbars = 10;
const UINT uiFirstUserToolBarId = AFX_IDW_CONTROLBAR_FIRST + 40;
const UINT uiLastUserToolBarId = uiFirstUserToolBarId + iMaxUserToolbars - 1;

BEGIN_MESSAGE_MAP(CMainFrame, CMDIFrameWndEx)
	ON_WM_CREATE()
	ON_COMMAND(ID_WINDOW_MANAGER, &CMainFrame::OnWindowManager)
	ON_COMMAND(ID_VIEW_CUSTOMIZE, &CMainFrame::OnViewCustomize)
	ON_REGISTERED_MESSAGE(AFX_WM_CREATETOOLBAR, &CMainFrame::OnToolbarCreateNew)
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_OFF_2007_AQUA, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_OFF_2007_AQUA, &CMainFrame::OnUpdateApplicationLook)
	ON_COMMAND(ID_HELP_RADAEEHOME, &CMainFrame::OnHelpRadaeehome)
	ON_COMMAND(ID_VIEW_FULLSCREEN, &CMainFrame::OnViewFullscreen)
	ON_UPDATE_COMMAND_UI(ID_EDIT_FIND, &CMainFrame::OnUpdateEditFind)
	ON_UPDATE_COMMAND_UI(ID_INTERNAL_FINDOPTION, &CMainFrame::OnUpdateInternalFindoption)
	ON_COMMAND(ID_INTERNAL_FINDOPTION, &CMainFrame::OnInternalFindoption)
	ON_UPDATE_COMMAND_UI(ID_INTERNAL_FINDUP, &CMainFrame::OnUpdateInternalFindup)
	ON_UPDATE_COMMAND_UI(ID_INTERNAL_FINDDOWN, &CMainFrame::OnUpdateInternalFinddown)
	ON_COMMAND(ID_INTERNAL_FINDDOWN, &CMainFrame::OnInternalFinddown)
	ON_COMMAND(ID_INTERNAL_FINDUP, &CMainFrame::OnInternalFindup)
	ON_UPDATE_COMMAND_UI(ID_TOOL_GOTOPAGE, &CMainFrame::OnUpdateToolGotopage)
	ON_COMMAND(ID_TOOL_GOTOPAGE, &CMainFrame::OnToolGotopage)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOMTO, &CMainFrame::OnUpdateViewZoomto)
	ON_UPDATE_COMMAND_UI(ID_TOOL_DRAG, &CMainFrame::OnUpdateToolDrag)
	ON_COMMAND(ID_TOOL_DRAG, &CMainFrame::OnToolDrag)
	ON_UPDATE_COMMAND_UI(ID_TOOL_TEXTSELECTION, &CMainFrame::OnUpdateToolTextselection)
	ON_COMMAND(ID_TOOL_TEXTSELECTION, &CMainFrame::OnToolTextselection)
	ON_COMMAND(ID_TOOL_FIRSTPAGE, &CMainFrame::OnToolFirstpage)
	ON_UPDATE_COMMAND_UI(ID_TOOL_FIRSTPAGE, &CMainFrame::OnUpdateToolFirstpage)
	ON_COMMAND(ID_TOOL_PREVIOUSPAGE, &CMainFrame::OnToolPreviouspage)
	ON_UPDATE_COMMAND_UI(ID_TOOL_PREVIOUSPAGE, &CMainFrame::OnUpdateToolPreviouspage)
	ON_COMMAND(ID_TOOL_NEXTPAGE, &CMainFrame::OnToolNextpage)
	ON_UPDATE_COMMAND_UI(ID_TOOL_NEXTPAGE, &CMainFrame::OnUpdateToolNextpage)
	ON_COMMAND(ID_TOOL_LASTPAGE, &CMainFrame::OnToolLastpage)
	ON_UPDATE_COMMAND_UI(ID_TOOL_LASTPAGE, &CMainFrame::OnUpdateToolLastpage)
	ON_COMMAND(ID_PAGELAYOUT_SINGLE, &CMainFrame::OnPagelayoutSingle)
	ON_UPDATE_COMMAND_UI(ID_PAGELAYOUT_SINGLE, &CMainFrame::OnUpdatePagelayoutSingle)
	ON_COMMAND(ID_PAGELAYOUT_CONTINUOUS, &CMainFrame::OnPagelayoutContinuous)
	ON_UPDATE_COMMAND_UI(ID_PAGELAYOUT_CONTINUOUS, &CMainFrame::OnUpdatePagelayoutContinuous)
	ON_COMMAND(ID_PAGELAYOUT_FOLIO, &CMainFrame::OnPagelayoutFolio)
	ON_UPDATE_COMMAND_UI(ID_PAGELAYOUT_FOLIO, &CMainFrame::OnUpdatePagelayoutFolio)
	ON_COMMAND(ID_PAGELAYOUT_FOLIOCONTINUOUS, &CMainFrame::OnPagelayoutFoliocontinuous)
	ON_UPDATE_COMMAND_UI(ID_PAGELAYOUT_FOLIOCONTINUOUS, &CMainFrame::OnUpdatePagelayoutFoliocontinuous)
	ON_COMMAND(ID_VIEW_ZOOMIN, &CMainFrame::OnViewZoomin)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOMIN, &CMainFrame::OnUpdateViewZoomin)
	ON_COMMAND(ID_VIEW_ZOOMOUT, &CMainFrame::OnViewZoomout)
	ON_UPDATE_COMMAND_UI(ID_VIEW_ZOOMOUT, &CMainFrame::OnUpdateViewZoomout)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FITWIDTH, &CMainFrame::OnUpdateViewFitwidth)
	ON_COMMAND(ID_VIEW_FITWIDTH, &CMainFrame::OnViewFitwidth)
	ON_UPDATE_COMMAND_UI(ID_VIEW_FITPAGE, &CMainFrame::OnUpdateViewFitpage)
	ON_COMMAND(ID_VIEW_FITPAGE, &CMainFrame::OnViewFitpage)
	ON_COMMAND(ID_TOOL_SHORTCUTS, &CMainFrame::OnToolShortcuts)
	ON_COMMAND(ID_TOOL_PREFERENCE, &CMainFrame::OnToolPreference)
	ON_COMMAND(ID_TOOL_SNAPSHOT, &CMainFrame::OnToolSnapshot)
	ON_UPDATE_COMMAND_UI(ID_TOOL_SNAPSHOT, &CMainFrame::OnUpdateToolSnapshot)
	ON_UPDATE_COMMAND_UI(ID_INTERNAL_ZOOMTO, &CMainFrame::OnUpdateInternalZoomto)
	ON_UPDATE_COMMAND_UI(ID_INTERNAL_GOTOPAGE, &CMainFrame::OnUpdateInternalGotopage)
	ON_UPDATE_COMMAND_UI(ID_INTERNAL_PAGESIZE, &CMainFrame::OnUpdateInternalPagesize)
	ON_COMMAND(ID_FILE_PRINT, &CMainFrame::OnFilePrint)
	ON_UPDATE_COMMAND_UI(ID_FILE_PRINT, &CMainFrame::OnUpdateFilePrint)
	ON_WM_DROPFILES()
	ON_UPDATE_COMMAND_UI(ID_PAGELAYOUT_BOOKSTYLE, &CMainFrame::OnUpdatePagelayoutBookstyle)
	ON_COMMAND(ID_PAGELAYOUT_BOOKSTYLE, &CMainFrame::OnPagelayoutBookstyle)
	ON_COMMAND(ID_PAGELAYOUT_ROLLPAGE, &CMainFrame::OnPagelayoutRollpage)
	ON_UPDATE_COMMAND_UI(ID_PAGELAYOUT_ROLLPAGE, &CMainFrame::OnUpdatePagelayoutRollpage)
	ON_COMMAND(ID_HELP_HELP, &CMainFrame::OnHelpHelp)
END_MESSAGE_MAP()

// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	/*
	CFile src;
	CFile dst;
	src.Open( _T("D:\\gry.bmp"), CFile::modeRead );
	dst.Open( _T("D:\\gry.txt"), CFile::modeCreate|CFile::modeWrite );
	BYTE buf[64];
	char str[32];
	int row = 10;
	src.Read( buf, 54 );
	while( row > 0 )
	{
		src.Read( buf, 32 );
		int col = 10;
		BYTE *tmp = buf;
		while( col > 0 )
		{
			sprintf( str, "0,0,0,%u, ", 255-tmp[0] );
			dst.Write( str, strlen( str ) );
			tmp += 3;
			col--;
		}
		dst.Write( "\r\n", 2 );
		row--;
	}
	src.Close();
	dst.Close();
	*/
	// TODO: add member initialization code here
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_OFF_2007_BLUE);
}

CMainFrame::~CMainFrame()
{
	CDlgPrint::PrnListUninit();
}

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INTERNAL_GOTOPAGE,
	ID_INTERNAL_ZOOMTO,
	ID_INTERNAL_PAGESIZE,
	//ID_INDICATOR_CAPS,
	//ID_INDICATOR_NUM,
	//ID_INDICATOR_SCRL,
};

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	//DWORD dwExStyle = GetWindowLong( m_hWnd, GWL_EXSTYLE );
	//DragAcceptFiles();
	if (CMDIFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;
	// set the visual manager and style based on persisted value
	OnApplicationLook(theApp.m_nAppLook);

	CMDITabInfo mdiTabParams;
	mdiTabParams.m_style = CMFCTabCtrl::STYLE_3D_VS2005;//STYLE_3D_ONENOTE; // other styles available...
	mdiTabParams.m_bActiveTabCloseButton = FALSE;      // set to FALSE to place close button at right of tab area
	mdiTabParams.m_bTabIcons = FALSE;    // set to TRUE to enable document icons on MDI taba
	mdiTabParams.m_bAutoColor = TRUE;    // set to FALSE to disable auto-coloring of MDI tabs
	mdiTabParams.m_bDocumentMenu = TRUE; // enable the document menu at the right edge of the tab area
	mdiTabParams.m_bAutoColor = FALSE;
	mdiTabParams.m_bEnableTabSwap = TRUE;
	mdiTabParams.m_bFlatFrame = TRUE;
	mdiTabParams.m_bTabCloseButton = TRUE;
	mdiTabParams.m_bTabCustomTooltips = TRUE;
	EnableMDITabbedGroups(TRUE, mdiTabParams);

	if (!m_wndMenuBar.Create(this))
	{
		TRACE0("Failed to create menubar\n");
		return -1;      // fail to create
	}

	m_wndMenuBar.SetPaneStyle(m_wndMenuBar.GetPaneStyle() | CBRS_SIZE_DYNAMIC | CBRS_TOOLTIPS | CBRS_FLYBY);
	m_wndMenuBar.SetShowAllCommands();

	// prevent the menu bar from taking the focus on activation
	CMFCPopupMenu::SetForceMenuFocus(FALSE);

	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC, CRect(1,1,1,1), IDR_MAINFRAME) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME) )
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	CString strToolBarName;
	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_MAIN);
	ASSERT(bNameValid);
	m_wndToolBar.SetWindowText(strToolBarName);

	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);
	m_wndToolBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);


	if (!m_wndViewBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC, CRect(1,1,1,1), IDR_TOOLBAR_VIEW) ||
		!m_wndViewBar.LoadToolBar(IDR_TOOLBAR_VIEW))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}
	bNameValid = strToolBarName.LoadString(IDS_TOOLBAR_VIEW);
	ASSERT(bNameValid);
	m_wndViewBar.SetWindowText( strToolBarName );
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);
	m_wndViewBar.EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);

	// Allow user-defined toolbars operations:
	InitUserToolbars(NULL, uiFirstUserToolBarId, uiLastUserToolBarId);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

	// TODO: Delete these five lines if you don't want the toolbar and menubar to be dockable
	m_wndMenuBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	m_wndViewBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockPane(&m_wndMenuBar);
	DockPane(&m_wndToolBar);
	DockPane(&m_wndViewBar);

	// enable Visual Studio 2005 style docking window behavior
	CDockingManager::SetDockingMode(DT_SMART);
	// enable Visual Studio 2005 style docking window auto-hide behavior
	EnableAutoHidePanes(CBRS_ALIGN_ANY);

	// Enable enhanced windows management dialog
	EnableWindowsDialog(ID_WINDOW_MANAGER, IDS_WINDOWS_MANAGER, TRUE);

	// Enable toolbar and docking window menu replacement
	EnablePaneMenu(TRUE, ID_VIEW_CUSTOMIZE, strCustomize, ID_VIEW_TOOLBAR);

	// enable quick (Alt+drag) toolbar customization
	CMFCToolBar::EnableQuickCustomization();

	/*
	if (CMFCToolBar::GetUserImages() == NULL)
	{
		// load user-defined toolbar images
		if (m_UserImages.Load(_T(".\\UserImages.bmp")))
		{
			m_UserImages.SetImageSize(CSize(16, 16), FALSE);
			CMFCToolBar::SetUserImages(&m_UserImages);
		}
	}
	*/

	// enable menu personalization (most-recently used commands)
	// TODO: define your own basic commands, ensuring that each pulldown menu has at least one basic command.
	CList<UINT, UINT> lstBasicCommands;

	lstBasicCommands.AddTail(ID_FILE_OPEN);
	lstBasicCommands.AddTail(ID_FILE_SAVE_AS);
	lstBasicCommands.AddTail(ID_FILE_CLOSE);
	//lstBasicCommands.AddTail(ID_FILE_SAVE);
	lstBasicCommands.AddTail(ID_FILE_PRINT);
	lstBasicCommands.AddTail(ID_APP_EXIT);
	lstBasicCommands.AddTail(ID_EDIT_FIND);
	lstBasicCommands.AddTail(ID_EDIT_COPY);
	//lstBasicCommands.AddTail(ID_EDIT_CUT);
	//lstBasicCommands.AddTail(ID_EDIT_PASTE);
	//lstBasicCommands.AddTail(ID_EDIT_UNDO);
	lstBasicCommands.AddTail(ID_VIEW_STATUS_BAR);
	lstBasicCommands.AddTail(ID_VIEW_TOOLBAR);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2003);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_VS_2005);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLUE);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_SILVER);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_BLACK);
	lstBasicCommands.AddTail(ID_VIEW_APPLOOK_OFF_2007_AQUA);
	lstBasicCommands.AddTail(ID_VIEW_ZOOMIN);
	lstBasicCommands.AddTail(ID_VIEW_ZOOMOUT);
	lstBasicCommands.AddTail(ID_VIEW_FITWIDTH);
	lstBasicCommands.AddTail(ID_VIEW_FITPAGE);
	lstBasicCommands.AddTail(ID_VIEW_AUTOSCROLL);
	lstBasicCommands.AddTail(ID_VIEW_FULLSCREEN);

	lstBasicCommands.AddTail(ID_TOOL_FIRSTPAGE);
	lstBasicCommands.AddTail(ID_TOOL_PREVIOUSPAGE);
	lstBasicCommands.AddTail(ID_TOOL_NEXTPAGE);
	lstBasicCommands.AddTail(ID_TOOL_LASTPAGE);
	lstBasicCommands.AddTail(ID_TOOL_DRAG);
	lstBasicCommands.AddTail(ID_TOOL_TEXTSELECTION);
	lstBasicCommands.AddTail(ID_TOOL_PREFERENCE);
	lstBasicCommands.AddTail(ID_WINDOW_NEW);

	lstBasicCommands.AddTail(ID_HELP_RADAEEHOME);
	lstBasicCommands.AddTail(ID_HELP_HELP);
	lstBasicCommands.AddTail(ID_APP_ABOUT);

	lstBasicCommands.AddTail(ID_FIND_CASE);
	lstBasicCommands.AddTail(ID_FIND_WHOLEWORD);

	lstBasicCommands.AddTail(ID_PAGELAYOUT_SINGLE);
	lstBasicCommands.AddTail(ID_PAGELAYOUT_CONTINUOUS);


	CMFCToolBar::SetBasicCommands(lstBasicCommands);

	EnableFullScreenMode( ID_VIEW_FULLSCREEN );
	EnableFullScreenMainMenu( FALSE );
	m_wndStatusBar.SetPaneWidth( 1, 80 );
	m_wndStatusBar.SetPaneWidth( 2, 60 );
	m_wndStatusBar.SetPaneWidth( 3, 180 );
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.dwExStyle |= WS_EX_ACCEPTFILES;
	if( !CMDIFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CMDIFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CMDIFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame message handlers

void CMainFrame::OnWindowManager()
{
	ShowWindowsDialog();
}

void CMainFrame::OnViewCustomize()
{
	CMFCToolBarsCustomizeDialog* pDlgCust = new CMFCToolBarsCustomizeDialog(this, TRUE /* scan menus */);
	pDlgCust->EnableUserDefinedToolbars();
	pDlgCust->Create();
}

LRESULT CMainFrame::OnToolbarCreateNew(WPARAM wp,LPARAM lp)
{
	LRESULT lres = CMDIFrameWndEx::OnToolbarCreateNew(wp,lp);
	if (lres == 0)
	{
		return 0;
	}

	CMFCToolBar* pUserToolbar = (CMFCToolBar*)lres;
	ASSERT_VALID(pUserToolbar);

	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
	return lres;
}

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
	}

	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}

BOOL CMainFrame::LoadFrame(UINT nIDResource, DWORD dwDefaultStyle, CWnd* pParentWnd, CCreateContext* pContext) 
{
	// base class does the real work

	if (!CMDIFrameWndEx::LoadFrame(nIDResource, dwDefaultStyle, pParentWnd, pContext))
	{
		return FALSE;
	}

	// enable customization button for all user toolbars
	BOOL bNameValid;
	CString strCustomize;
	bNameValid = strCustomize.LoadString(IDS_TOOLBAR_CUSTOMIZE);
	ASSERT(bNameValid);

	for (int i = 0; i < iMaxUserToolbars; i ++)
	{
		CMFCToolBar* pUserToolbar = GetUserToolBarByIndex(i);
		if (pUserToolbar != NULL)
		{
			pUserToolbar->EnableCustomizeButton(TRUE, ID_VIEW_CUSTOMIZE, strCustomize);
		}
	}

	return TRUE;
}

void CMainFrame::OnHelpRadaeehome()
{
	ShellExecute(NULL, NULL, _T("http://www.radaee.com/en"), NULL, NULL, SW_SHOWNORMAL);
}

void CMainFrame::OnViewFullscreen()
{
	ShowFullScreen();
	RecalcLayout();
}

void CMainFrame::OnUpdateEditFind(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
	{
		pCmdUI->Enable( TRUE );
	}
	else
	{
		m_wndViewBar.set_text_find( NULL );
		pCmdUI->Enable( FALSE );
	}
}

void CMainFrame::OnInternalFindoption()
{
}

void CMainFrame::OnUpdateInternalFindoption(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	pCmdUI->Enable( cf && cf->get_view_style() < 5 );
}

void CMainFrame::OnUpdateInternalFindup(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	pCmdUI->Enable( cf && cf->get_view_style() < 5 );
}

void CMainFrame::OnUpdateInternalFinddown(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	pCmdUI->Enable( cf && cf->get_view_style() < 5 );
}

void CMainFrame::OnInternalFinddown()
{
}

void CMainFrame::OnInternalFindup()
{
}

void CMainFrame::OnUpdateInternalGotopage(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		CString sVal;
		sVal.Format( _T("%d/%d"), pFrame->get_pageno(), pFrame->get_page_count() );
		m_wndStatusBar.SetPaneText( 1, sVal);
	}
	else
	{
		m_wndStatusBar.SetPaneText( 1, _T("Page Number"));
		pCmdUI->Enable( FALSE );
	}
}

void CMainFrame::OnUpdateToolGotopage(CCmdUI *pCmdUI)
{
	if( get_active_child() )
		pCmdUI->Enable( TRUE );
	else
	{
		if( pCmdUI->m_pOther == &m_wndToolBar )
			m_wndToolBar.set_text_goto_page( NULL );
		pCmdUI->Enable( FALSE );
	}
}

void CMainFrame::OnToolGotopage()
{
}

void CMainFrame::OnUpdateInternalZoomto(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		double ratio = pFrame->get_ratio();
		int tmp = ratio * 1000;
		CString sVal;
		if( tmp % 10 == 0 )
			sVal.Format( _T("%d%%"), tmp/10 );
		else
			sVal.Format( _T("%d.%d%%"), tmp/10, tmp%10 );
		m_wndStatusBar.SetPaneText( 2, sVal );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		m_wndStatusBar.SetPaneText( 2, _T("Ratio") );
	}
}

void CMainFrame::OnUpdateInternalPagesize(CCmdUI *pCmdUI)
{
	if( get_active_child() )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		double width;
		double height;
		CString sVal;
		pFrame->get_page_size_inch( pFrame->get_pageno(), width, height );
		sVal.Format( _T("Current Page:%.2f X %.2f (in)"), width, height );
		m_wndStatusBar.SetPaneText( 3, sVal );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		m_wndStatusBar.SetPaneText( 3, _T("Page Size") );
	}
}

void CMainFrame::OnUpdateViewZoomto(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
	{
		pCmdUI->Enable( TRUE );
	}
	else
	{
		m_wndViewBar.set_text_zoomto( NULL );
		pCmdUI->Enable( FALSE );
	}
}

void CMainFrame::OnUpdateToolDrag(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_drag_mode() == tool_drag );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnToolDrag()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_drag_mode( tool_drag );
}

void CMainFrame::OnUpdateToolTextselection(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_drag_mode() ==tool_sel );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnToolTextselection()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_drag_mode(tool_sel );
}

void CMainFrame::OnToolFirstpage()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->goto_page( 1 );
}

void CMainFrame::OnUpdateToolFirstpage(CCmdUI *pCmdUI)
{
	if( get_active_child() )
	{
		CChildFrame *pFrame = get_active_child();
		pCmdUI->Enable( pFrame->get_pageno() > 1 );
	}
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnToolPreviouspage()
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
		cf->goto_page( cf->get_pageno() - 1 );
	else
		cf->roll_papers( -1 );
}

void CMainFrame::OnUpdateToolPreviouspage(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf )
	{
		CChildFrame *pFrame = get_active_child();
		pCmdUI->Enable( pFrame->get_pageno() > 1 );
	}
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnToolNextpage()
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
		cf->goto_page( cf->get_pageno() + 1 );
	else
		cf->roll_papers( 1 );
}

void CMainFrame::OnUpdateToolNextpage(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf )
	{
		CChildFrame *pFrame = get_active_child();
		pCmdUI->Enable( pFrame->get_pageno() < pFrame->get_page_count() );
	}
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnToolLastpage()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->goto_page( pFrame->get_page_count() );
}

void CMainFrame::OnUpdateToolLastpage(CCmdUI *pCmdUI)
{
	if( get_active_child() )
	{
		CChildFrame *pFrame = get_active_child();
		pCmdUI->Enable( pFrame->get_pageno() < pFrame->get_page_count() );
	}
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnPagelayoutSingle()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_view_style(1);
}

void CMainFrame::OnUpdatePagelayoutSingle(CCmdUI *pCmdUI)
{
	if( get_active_child() )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_view_style() == 1 );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnPagelayoutContinuous()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_view_style(2);
}

void CMainFrame::OnUpdatePagelayoutContinuous(CCmdUI *pCmdUI)
{
	if( get_active_child() )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_view_style() == 2 );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnPagelayoutFolio()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_view_style(3);
}

void CMainFrame::OnUpdatePagelayoutFolio(CCmdUI *pCmdUI)
{
	if( get_active_child() )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_view_style() == 3 );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnPagelayoutFoliocontinuous()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_view_style(4);
}

void CMainFrame::OnUpdatePagelayoutFoliocontinuous(CCmdUI *pCmdUI)
{
	if( get_active_child() )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_view_style() == 4 );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnUpdatePagelayoutBookstyle(CCmdUI *pCmdUI)
{
	if( get_active_child() )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_view_style() == 5 );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnPagelayoutBookstyle()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_view_style(5);
}

void CMainFrame::OnPagelayoutRollpage()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_view_style(6);
}

void CMainFrame::OnUpdatePagelayoutRollpage(CCmdUI *pCmdUI)
{
	if( get_active_child() )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_view_style() == 6 );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnViewZoomin()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_ratio( pFrame->get_ratio() * 1.25 );
}

void CMainFrame::OnUpdateViewZoomin(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnViewZoomout()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_ratio( pFrame->get_ratio() * .8 );
}

void CMainFrame::OnUpdateViewZoomout(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
		pCmdUI->Enable( TRUE );
	else
		pCmdUI->Enable( FALSE );
}

void CMainFrame::OnUpdateViewFitwidth(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_fit_mode() == fit_width );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnViewFitwidth()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_fit_mode( fit_width );
}

void CMainFrame::OnUpdateViewFitpage(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
	{
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_fit_mode() == fit_page );
		pCmdUI->Enable( TRUE );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnViewFitpage()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_fit_mode( fit_page );
}

BOOL CMainFrame::OnCommand(WPARAM wParam, LPARAM lParam)
{
	if( LOWORD(wParam) == ID_TOOL_GOTOPAGE && HIWORD(wParam) == 0 )
	{
		int index = m_wndToolBar.CommandToIndex( ID_TOOL_GOTOPAGE );
		if( index >= 0 )
		{
			CMFCToolBarEditBoxButton *pBtn = (CMFCToolBarEditBoxButton *)m_wndToolBar.GetButton( index );
			CString sVal = pBtn->GetContentsAll( ID_TOOL_GOTOPAGE );
			int iPage = _tstoi( sVal );
			CChildFrame *pFrame = get_active_child();
			pFrame->goto_page( iPage );
			pBtn->GetEditBox()->SetFocus();
		}
	}
	if( LOWORD(wParam) == ID_VIEW_ZOOMTO )
	{
		if( HIWORD(wParam) == 0 || HIWORD(wParam) == CBN_SELENDOK )
		{
			int index = m_wndViewBar.CommandToIndex( ID_VIEW_ZOOMTO );
			if( index >= 0 )
			{
				CMFCToolBarComboBoxButton *pBtn = (CMFCToolBarComboBoxButton *)m_wndViewBar.GetButton( index );
				CString sVal = pBtn->GetTextAll( ID_VIEW_ZOOMTO );
				double ratio = _tstof( sVal );
				CChildFrame *pFrame = get_active_child();
				pFrame->set_ratio( ratio/100 );
				pBtn->GetComboBox()->SetFocus();
			}
		}
	}
	return CMDIFrameWndEx::OnCommand(wParam, lParam);
}

void CMainFrame::OnToolShortcuts()
{
	CDlgShortcuts dlg;
	if( dlg.DoModal() != IDOK ) return;
	POSITION pos =theApp.GetFirstDocTemplatePosition();   
	CDocTemplate* pTemplate = theApp.GetNextDocTemplate(pos);   
	CDocument* pOpenDocument = NULL;   
	if( pTemplate->MatchDocType(dlg.m_sOpen, pOpenDocument) == CDocTemplate::yesAlreadyOpen )
	{
		POSITION pos = pOpenDocument->GetFirstViewPosition();
		CView *pView = pOpenDocument->GetNextView(pos);
		((CMDIChildWndEx *)pView->GetParent())->ActivateFrame( SW_SHOW );
	}
	else
		pTemplate->OpenDocumentFile(dlg.m_sOpen);
}

void CMainFrame::OnToolPreference()
{
	CDlgPreference dlg;
	dlg.DoModal();
}

void CMainFrame::OnToolSnapshot()
{
	CChildFrame *pFrame = get_active_child();
	pFrame->set_drag_mode( tool_snapshot );
}

void CMainFrame::OnUpdateToolSnapshot(CCmdUI *pCmdUI)
{
	CChildFrame *cf = get_active_child();
	if( cf && cf->get_view_style() < 5 )
	{
		pCmdUI->Enable( TRUE );
		CChildFrame *pFrame = get_active_child();
		pCmdUI->SetCheck( pFrame->get_drag_mode() == tool_snapshot );
	}
	else
	{
		pCmdUI->Enable( FALSE );
		pCmdUI->SetCheck( FALSE );
	}
}

void CMainFrame::OnFilePrint()
{
	CDlgPrint dlg;
	dlg.m_pDoc = get_active_child()->get_doc();
	dlg.m_iPageCur = get_active_child()->get_pageno();
	if( dlg.DoModal() != IDOK ) return;
	get_active_child()->do_print( dlg.get_printer(), dlg.m_iPage1, dlg.m_iPage2, dlg.m_iCopies, dlg.m_iAlign, dlg.m_iArrange );
}

void CMainFrame::OnUpdateFilePrint(CCmdUI *pCmdUI)
{
	pCmdUI->Enable( get_active_child() != NULL );
}

void CMainFrame::OnDropFiles(HDROP hDropInfo)
{
	/*
	UINT uFiles = DragQueryFile( hDropInfo, 0xFFFFFFFF, NULL, 0 );
	UINT uFile;
	TCHAR sPath[MAX_PATH];
	for( uFile = 0; uFile < uFiles; uFile++ )
	{
		DragQueryFile( hDropInfo, uFile, sPath, MAX_PATH );
		theApp.OpenDocumentFile( sPath );
	}
	*/
	CMDIFrameWndEx::OnDropFiles(hDropInfo);
}
/*
#include "dde.h"
LRESULT CMainFrame::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch( message )
	{
	case WM_DDE_INITIATE:
		{
			ATOM atopic = LOWORD(lParam);
			TCHAR sTopic[64];
			GlobalGetAtomName( atopic, sTopic, 64 );
			CWinApp *pApp = AfxGetApp();
			if( StrCmpI( pApp->m_pszExeName, sTopic ) == 0 ||
				StrCmpI( pApp->m_pszAppName, sTopic ) == 0 )
				::SendMessage((HWND)wParam, WM_DDE_ACK, (WPARAM)m_hWnd,lParam);
		}
		return 0;
		break;
	case WM_DDE_EXECUTE:
		{
			int ioff;
			int iend;
			UINT unused;
			HGLOBAL hData;
			UnpackDDElParam(WM_DDE_EXECUTE, lParam, &unused, (UINT*)&hData);
			if( IsWindowUnicode( (HWND)wParam ) )
			{
				wchar_t szCommand[MAX_PATH * 2];
				wchar_t szFile[MAX_PATH] = {0};
				wchar_t *lpsz = (wchar_t *)GlobalLock(hData);
				wcscpy( szCommand, lpsz );
				GlobalUnlock(hData);
				::PostMessage((HWND)wParam, WM_DDE_ACK, (WPARAM)m_hWnd,
					ReuseDDElParam(lParam, WM_DDE_EXECUTE, WM_DDE_ACK, (UINT)0x8000, (UINT)hData));

				for( ioff = 0; szCommand[ioff]!='(' && szCommand[ioff]; ioff++ );
				if( szCommand[ioff] == '(' && szCommand[ioff + 1] == '\"' )
				{
					ioff += 2;
					for( iend = ioff; szCommand[iend] != '\"'; iend++ );
					if( szCommand[iend] == '\"' )
					{
						wcsncpy( szFile, szCommand + ioff, iend - ioff );
						szFile[iend - ioff] = 0;
					}
					else
						szFile[0] = 0;
				}
#ifdef _UNICODE
				theApp.OpenDocumentFile( szFile );
				//proOpenFile( szFile );
#else
				char szTmp[MAX_PATH];
				::WideCharToMultiByte( CP_ACP, 0, szFile, -1, szTmp, MAX_PATH, NULL, NULL );
				proOpenFile( szTmp );
#endif
			}
			else
			{
				char szCommand[MAX_PATH * 2];
				char szFile[MAX_PATH] = {0};
				char *lpsz = (char *)GlobalLock(hData);
				strcpy( szCommand, lpsz );
				GlobalUnlock(hData);
				::PostMessage((HWND)wParam, WM_DDE_ACK, (WPARAM)m_hWnd,
					ReuseDDElParam(lParam, WM_DDE_EXECUTE, WM_DDE_ACK, (UINT)0x8000, (UINT)hData));

				for( ioff = 0; szCommand[ioff]!='(' && szCommand[ioff]; ioff++ );
				if( szCommand[ioff] == '(' && szCommand[ioff + 1] == '\"' )
				{
					ioff += 2;
					for( iend = ioff; szCommand[iend] != '\"'; iend++ );
					if( szCommand[iend] == '\"' )
					{
						strncpy( szFile, szCommand + ioff, iend - ioff );
						szFile[iend - ioff] = 0;
					}
					else
						szFile[0] = 0;
				}
#ifdef _UNICODE
				TCHAR szTmp[MAX_PATH];
				::MultiByteToWideChar( CP_ACP, 0, szFile, -1, szTmp, MAX_PATH );
				theApp.OpenDocumentFile( szTmp );
#else
				proOpenFile( szFile );
#endif
			}
		}
		return 0;
		break;
	case WM_DDE_TERMINATE:
		::PostMessage((HWND)wParam, WM_DDE_TERMINATE, (WPARAM)m_hWnd, lParam);
		return 0;
		break;
	}
	return CMDIFrameWndEx::DefWindowProc(message, wParam, lParam);
}
*/

void CMainFrame::OnHelpHelp()
{
	TCHAR base_path[MAX_PATH];
	GetModuleFileName( AfxGetApp()->m_hInstance, base_path, MAX_PATH );
	int len = _tcslen( base_path ) - 1;
	while( base_path[len] != '\\' ) len--;
	base_path[len] = 0;
	_tcscat( base_path, _T("\\rdhelp.chm") );
	ShellExecute( m_hWnd, _T("open"), base_path, NULL, NULL, SW_SHOW );
}
