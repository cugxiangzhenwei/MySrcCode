#pragma once
#include "afxcolorbutton.h"
#include "afxwin.h"


// CDlgPreference �Ի���

class CDlgPreference : public CDialog
{
	DECLARE_DYNAMIC(CDlgPreference)

public:
	CDlgPreference(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlgPreference();

// �Ի�������
	enum { IDD = IDD_DIALOG_PREFERENCE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CMFCColorButton m_btnBackPage;
	CMFCColorButton m_btnBack;
	CComboBox m_cLayout;
	CComboBox m_cRatio;
	CComboBox m_cTool;
	CComboBox m_cActive;
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedCheckOutline();
	afx_msg void OnBnClickedCheckThumb();
	afx_msg void OnCbnSelchangeComboLayout();
	CComboBox m_cParas1;
	CStatic m_sDisp1;
	CComboBox m_cParas2;
	CStatic m_sDisp2;
};
