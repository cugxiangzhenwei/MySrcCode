// DlgSave.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DlgSave.h"


// CDlgSave �Ի���

IMPLEMENT_DYNAMIC(CDlgSave, CDialog)

CDlgSave::CDlgSave(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSave::IDD, pParent)
	, m_sDest(_T(""))
	, m_bRemPassword(FALSE)
{

}

CDlgSave::~CDlgSave()
{
}

void CDlgSave::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_DESTINATION, m_sDest);
	DDX_Check(pDX, IDC_CHECK_REMOVE, m_bRemPassword);
}


BEGIN_MESSAGE_MAP(CDlgSave, CDialog)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE, &CDlgSave::OnBnClickedButtonBrowse)
	ON_BN_CLICKED(IDOK, &CDlgSave::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgSave ��Ϣ��������

void CDlgSave::OnBnClickedButtonBrowse()
{
	UpdateData();
	CFileDialog dlg( FALSE, NULL, m_sDest, 6, _T("Adobe PDF Files(*.pdf)|*.pdf||") );
	if( dlg.DoModal() != IDOK ) return;
	m_sDest = dlg.GetPathName();
	UpdateData(FALSE);
}

void CDlgSave::OnBnClickedOk()
{
	UpdateData();
	if( m_sDest.IsEmpty() )
		MessageBox( _T("Invalid File Name!") );
	else
		OnOK();
}
