
// PDFReader.h : main header file for the PDFReader application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols

// CPDFReaderApp:
// See PDFReader.cpp for the implementation of this class
//
typedef struct _PREFERENCE
{
	COLORREF clrBack;
	COLORREF clrBack_Page;
	int pageLayout;//1:single, 2:continuous
	int pageLayoutPara1;
	int pageLayoutPara2;
	int pageLayoutPara3;
	int pageLayoutPara4;
	int pageLayoutPara5;
	int pageLayoutPara6;
	int pageTool;//0:drag, 1:selection
	double viewRatio;//0:fit width, -1:fit page
	int viewActive;//0:disable, 1:active outlines, 2:active thumb nails
	BOOL showOutline;
	BOOL showThumbNails;
}PREFERENCE;

class CPDFReaderApp : public CWinAppEx
{
public:
	CPDFReaderApp();

	void LoadPreference();
	void SavePreference();
// Overrides
public:
	virtual BOOL InitInstance();
	PREFERENCE m_preference;
// Implementation
	UINT  m_nAppLook;
	BOOL  m_bHiColorIcons;
	UINT  m_docid;

	virtual void PreLoadState();
	virtual void LoadCustomState();
	virtual void SaveCustomState();

	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
	virtual int ExitInstance();
	afx_msg void OnFileOpenurl();
};

extern CPDFReaderApp theApp;
