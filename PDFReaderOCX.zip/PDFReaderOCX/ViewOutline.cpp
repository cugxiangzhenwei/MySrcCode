// ViewOutline.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "ViewOutline.h"


// CViewOutline

IMPLEMENT_DYNAMIC(CViewOutline, CDockablePane)

CViewOutline::CViewOutline()
{

}

CViewOutline::~CViewOutline()
{
}


BEGIN_MESSAGE_MAP(CViewOutline, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()

// CViewOutline ��Ϣ��������

int CViewOutline::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;
	CRect rectDummy;
	rectDummy.SetRectEmpty();
	if (!m_wndView.Create( NULL, WS_CHILD|WS_VISIBLE|WS_CLIPSIBLINGS|WS_CLIPCHILDREN|
		TVS_LINESATROOT|TVS_HASBUTTONS|TVS_FULLROWSELECT|TVS_SHOWSELALWAYS|TVS_TRACKSELECT,
		rectDummy, this, 2))
	{
		TRACE0("δ�ܴ�������ͼ\n");
		return -1;      // δ�ܴ���
	}
	m_wndView.put_BackColor( theApp.m_preference.clrBack );
	return 0;
}

void CViewOutline::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	if( IsWindow(m_wndView) )
		m_wndView.MoveWindow( 0, 0, cx, cy );
}
