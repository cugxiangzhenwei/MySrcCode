
// PDFReaderView.cpp : implementation of the CPDFReaderView class
//

#include "stdafx.h"
#include "PDFReader.h"
#include "Winspool.h"

#include "MainFrm.h"
#include "PDFWnd.h"
#include "PDFReaderDoc.h"
#include "PDFReaderView.h"
#include "DlgProperty.h"
#include "DlgShortcut.h"
#include "DlgPrinting.h"
#include "DlgSave.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CPDFReaderView

IMPLEMENT_DYNCREATE(CPDFReaderView, CView)

BEGIN_MESSAGE_MAP(CPDFReaderView, CView)
	// Standard printing commands
	//ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	//ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	//ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CPDFReaderView::OnFilePrintPreview)
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_CONTEXTMENU()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONUP()
	ON_WM_CREATE()
	ON_WM_MOUSEWHEEL()
	ON_WM_SETCURSOR()
	ON_WM_SETFOCUS()
	ON_COMMAND(ID_EDIT_COPY, &CPDFReaderView::OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, &CPDFReaderView::OnUpdateEditCopy)
	ON_COMMAND(ID_FILE_PROPERTY, &CPDFReaderView::OnFileProperty)
	ON_UPDATE_COMMAND_UI(ID_FIND_CASE, &CPDFReaderView::OnUpdateFindCase)
	ON_COMMAND(ID_FIND_CASE, &CPDFReaderView::OnFindCase)
	ON_UPDATE_COMMAND_UI(ID_FIND_WHOLEWORD, &CPDFReaderView::OnUpdateFindWholeword)
	ON_COMMAND(ID_FIND_WHOLEWORD, &CPDFReaderView::OnFindWholeword)
	ON_COMMAND(ID_EDIT_FIND, &CPDFReaderView::OnEditFind)
	ON_COMMAND(ID_INTERNAL_FINDUP, &CPDFReaderView::OnInternalFindup)
	ON_COMMAND(ID_INTERNAL_FINDDOWN, &CPDFReaderView::OnInternalFinddown)
	ON_COMMAND(ID_FILE_SAVE_AS, &CPDFReaderView::OnFileSaveAs)
	ON_COMMAND(ID_TOOL_ADDSHORTCUTS, &CPDFReaderView::OnToolAddshortcuts)
	ON_COMMAND(ID_VIEW_AUTOSCROLL, &CPDFReaderView::OnViewAutoscroll)
	ON_COMMAND(ID_VIEW_LINE_DOWN, &CPDFReaderView::OnViewLineDown)
	ON_COMMAND(ID_VIEW_LINE_UP, &CPDFReaderView::OnViewLineUp)
	ON_COMMAND(ID_VIEW_PAGE_DOWN, &CPDFReaderView::OnViewPageDown)
	ON_COMMAND(ID_VIEW_PAGE_UP, &CPDFReaderView::OnViewPageUp)
	ON_UPDATE_COMMAND_UI(ID_VIEW_AUTOSCROLL, &CPDFReaderView::OnUpdateViewAutoscroll)
	ON_WM_KILLFOCUS()
	ON_COMMAND(ID_SAVE_CLIPBOARD, &CPDFReaderView::OnSaveClipboard)
	ON_COMMAND(ID_SAVE_FILE, &CPDFReaderView::OnSaveFile)
	ON_COMMAND(ID_EDIT_SAVEIMAGE, &CPDFReaderView::OnEditSaveimage)
	ON_UPDATE_COMMAND_UI(ID_EDIT_SAVEIMAGE, &CPDFReaderView::OnUpdateEditSaveimage)
	ON_COMMAND(ID_FILE_SAVE_COPY, &CPDFReaderView::OnFileSaveCopy)
END_MESSAGE_MAP()

// CPDFReaderView construction/destruction

CPDFReaderView::CPDFReaderView()
{
	m_pTView = &((CMainFrame *)AfxGetMainWnd())->m_wndViewBar;
	m_pTMain = &((CMainFrame *)AfxGetMainWnd())->m_wndToolBar;
	m_pOwnner = NULL;
	m_pMini = NULL;
	m_pOutlines = NULL;
	m_findCase = FALSE;
	m_findWholeWord = FALSE;
	m_sFind.Empty();
	m_findStatus = FALSE;
	m_bAutoScroll = FALSE;
	m_findPage = 0;
	m_findObj = 0;
	m_viewStyle = 0;
}

CPDFReaderView::~CPDFReaderView()
{
}

BOOL CPDFReaderView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	//cs.style |= WS_VSCROLL|WS_HSCROLL;
	cs.dwExStyle &= WS_EX_CLIENTEDGE;
	return CView::PreCreateWindow(cs);
}

int CPDFReaderView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	m_dlgFind.Create( IDD_DIALOG_PROGRESS_FIND, this );
	RECT rcClient;
	GetClientRect( &rcClient );
	m_viewer.Create( NULL, WS_VISIBLE|WS_CHILD, rcClient, this, 100 );
	m_viewer.ownner = this;
	m_viewer.ShowWindow( SW_HIDE );
	m_book.Create( NULL, WS_VISIBLE|WS_CHILD, rcClient, this, 101 );
	m_book.ownner = this;
	m_roll.Create( NULL, WS_VISIBLE|WS_CHILD, rcClient, this, 102 );
	m_roll.ownner = this;
	return 0;
}

// CPDFReaderView drawing

BOOL CPDFReaderView::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;
	return CView::OnEraseBkgnd(pDC);
}

void CPDFReaderView::OnDraw(CDC* pDC)
{
}

// CPDFReaderView printing

void CPDFReaderView::OnFilePrintPreview()
{
	//AFXPrintPreview(this);
}

BOOL CPDFReaderView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPDFReaderView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPDFReaderView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CPDFReaderView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	RECT rcClient;
	GetClientRect( &rcClient );
	ClientToScreen( &rcClient );
	if( point.x < rcClient.left || point.x > rcClient.right ||
		point.y < rcClient.top || point.y > rcClient.bottom )
		CView::OnContextMenu( pWnd, point );
	else
	{
		m_iSavePage = m_viewer.point_to_page( point.x, point.y );
		m_ptSavePage = point;
		theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, AfxGetMainWnd(), TRUE);
	}
}


// CPDFReaderView diagnostics
// CPDFReaderView message handlers

void CPDFReaderView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
}

void CPDFReaderView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
}

void CPDFReaderView::OnSize(UINT nType, int cx, int cy)
{
	if( nType != SIZE_MINIMIZED && IsWindow(m_viewer) )
	{
		//CPDFReaderDoc *pDoc = GetDocument();
		//CPDFDocument *pRDDoc = pDoc->GetRDDoc();
		if( m_viewStyle == 6 )
		{
			m_viewer.MoveWindow( 0, 0, 0, 0 );
			m_book.MoveWindow( 0, 0, 0, 0 );
			m_roll.MoveWindow( 0, 0, cx, cy );
		}
		else if( m_viewStyle == 5 )
		{
			m_viewer.MoveWindow( 0, 0, 0, 0 );
			m_book.MoveWindow( 0, 0, cx, cy );
			m_roll.MoveWindow( 0, 0, 0, 0 );
		}
		else
		{
			m_viewer.MoveWindow( 0, 0, cx, cy );
			m_book.MoveWindow( 0, 0, 0, 0 );
			m_roll.MoveWindow( 0, 0, 0, 0 );
		}
	}
	CView::OnSize(nType, cx, cy);
}

void CPDFReaderView::proLoadPreference()
{
	CPDFReaderDoc* pDoc = GetDocument();
	if (!pDoc) return;
	CPDFDocument *pRDDoc = pDoc->GetRDDoc();
	if( !pRDDoc ) return;
	m_dlgFind.m_pDoc = pRDDoc;
	m_dlgFind.m_pViewer = &m_viewer;
	RECT rect;
	GetClientRect( &rect );
	if( theApp.m_preference.pageLayout == 6 )
	{
		m_viewStyle = theApp.m_preference.pageLayout;
		OnSize( SIZE_RESTORED, rect.right - rect.left, rect.bottom - rect.top );
		m_viewer.detach_doc();
		m_book.detach_doc();
		m_roll.attach_doc( pRDDoc->m_lpDispatch );
		m_roll.put_Orientation( theApp.m_preference.pageLayoutPara6 );
	}
	else if( theApp.m_preference.pageLayout == 5 )
	{
		m_viewStyle = theApp.m_preference.pageLayout;
		OnSize( SIZE_RESTORED, rect.right - rect.left, rect.bottom - rect.top );
		m_viewer.detach_doc();
		m_roll.detach_doc();
		m_book.attach_doc( pRDDoc->m_lpDispatch );
	}
	else
	{
		m_viewStyle = theApp.m_preference.pageLayout;
		OnSize( SIZE_RESTORED, rect.right - rect.left, rect.bottom - rect.top );
		m_book.detach_doc();
		m_roll.detach_doc();

		switch( theApp.m_preference.pageLayout )
		{
		case 1:
			m_viewer.put_ShowCover( theApp.m_preference.pageLayoutPara1 & 0xFF );
			m_viewer.put_PagesLeftToRight( theApp.m_preference.pageLayoutPara1 >> 8 );
			break;
		case 2:
			m_viewer.put_ShowCover( theApp.m_preference.pageLayoutPara2 & 0xFF );
			m_viewer.put_PagesLeftToRight( theApp.m_preference.pageLayoutPara2 >> 8 );
			break;
		case 3:
			m_viewer.put_ShowCover( theApp.m_preference.pageLayoutPara3 & 0xFF );
			m_viewer.put_PagesLeftToRight( theApp.m_preference.pageLayoutPara3 >> 8 );
			break;
		case 4:
			m_viewer.put_ShowCover( theApp.m_preference.pageLayoutPara4 & 0xFF );
			m_viewer.put_PagesLeftToRight( theApp.m_preference.pageLayoutPara4 >> 8 );
			break;
		}

		m_viewer.put_layout( theApp.m_preference.pageLayout - 1 );
		m_viewer.attach_doc( pRDDoc->m_lpDispatch );
	}
	m_book.put_PageBackColor( theApp.m_preference.clrBack_Page );
	m_book.put_BackColor( theApp.m_preference.clrBack );
	m_roll.put_PageBackColor( theApp.m_preference.clrBack_Page );
	m_roll.put_BackColor( theApp.m_preference.clrBack );
	m_viewer.put_PageBackColor( theApp.m_preference.clrBack_Page );
	m_viewer.put_BackColor( theApp.m_preference.clrBack );
	if( theApp.m_preference.viewRatio == 0 )
	{
		set_fit_mode( fit_width );
	}
	else if( theApp.m_preference.viewRatio < 0 )
	{
		set_fit_mode( fit_page );
	}
	else
	{
		set_fit_mode( fit_none );
		set_ratio( theApp.m_preference.viewRatio );
	}
	switch( theApp.m_preference.pageTool )
	{
	case 0:
		set_drag_mode( tool_drag );
		break;
	case 1:
		set_drag_mode( tool_sel );
		break;
	case 2:
		set_drag_mode( tool_snapshot );
		break;
	}

}

void CPDFReaderView::OnInitialUpdate()
{
	CView::OnInitialUpdate();
	m_doc = GetDocument()->GetRDDoc();
	m_doc->ownner = this;
	proLoadPreference();
	GetParent()->PostMessage( WM_INIT_UPDATE );
}

LRESULT CPDFReaderView::DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	switch( message )
	{
	case WM_SNAPSHOT:
		theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_SAVEIMG, wParam, lParam, AfxGetMainWnd(), TRUE);
		return 0;
		break;
	case WM_PRINTING:
		m_dlgPrint.PostMessage( message, wParam, lParam );
		return 0;
		break;
	case WM_SAVING:
		if( (int)wParam <= 0 )
		{
			m_findStatus = false;
			m_dlgFind.ShowWindow( SW_HIDE );
		}
		else
			m_dlgFind.SetProg( wParam, lParam );
		return 0;
		break;
	case WM_FINDING:
		if( (int)wParam <= 0 || (int)wParam > m_doc->get_page_count() )
		{
			m_dlgFind.ShowWindow( SW_HIDE );
			m_findStatus = FALSE;
			if( (int)wParam == 0 )
				MessageBox( _T("Reader has finished serching to top.\nNo more found!") );
			else if( (int)wParam > m_doc->get_page_count() )
				MessageBox( _T("Reader has finished serching to bottom.\nNo more found!") );
			else//wParam == -1
			{
				if( lParam )
				{
					m_findObj = (short)LOWORD(lParam);
					m_findPage = (short)HIWORD(lParam);
				}
			}
		}
		else
			m_dlgFind.SetProg( wParam, lParam );
		return 0;
		break;
	case WM_RATIO_CHANGED:
		{
			int ratio =  m_viewer.get_ratio() * 1000;
			CString sVal;
			if( ratio % 10 )
				sVal.Format( _T("%d.%d%%"), ratio/10, ratio%10 );
			else
				sVal.Format( _T("%d%%"), ratio/10 );
			m_pTView->set_text_zoomto( sVal );
		}
		return 0;
	case WM_PAGE_CHANGED:
		{
			CString sVal;
			sVal.Format( _T("%d/%d"), wParam, m_doc->get_page_count() );
			m_pTMain->set_text_goto_page( sVal );
		}
		return 0;
	default:
		return CView::DefWindowProc(message, wParam, lParam);
		break;
	}
}

void CPDFReaderView::OnTimer(UINT_PTR nIDEvent)
{
	if( nIDEvent == 200 )
		m_viewer.scroll_line_down();
	//CView::OnTimer(nIDEvent);
}

void CPDFReaderView::OnDestroy()
{
	if( m_findStatus )
	{
		m_dlgFind.OnBnClickedCancel();
		while( m_findStatus && ContinueModal() );
	}
	m_viewer.detach_doc();
	m_book.detach_doc();
	m_roll.detach_doc();
	CView::OnDestroy();
}

void CPDFReaderView::OnLButtonDown(UINT nFlags, CPoint point)
{
}

void CPDFReaderView::OnMouseMove(UINT nFlags, CPoint point)
{
}

void CPDFReaderView::OnLButtonUp(UINT nFlags, CPoint point)
{
}

BOOL CPDFReaderView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	m_viewer.mouse_wheel( zDelta );
	return CView::OnMouseWheel(nFlags, zDelta, pt);
}

BOOL CPDFReaderView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	return CView::OnSetCursor(pWnd, nHitTest, message);
}

void CPDFReaderView::OnSetFocus(CWnd* pOldWnd)
{
	if( m_bAutoScroll )
		SetTimer( 200, 50, NULL );
	m_viewer.SetFocus();
}

void CPDFReaderView::OnEditCopy()
{
	EmptyClipboard();
	if( OpenClipboard() )
	{
		CString sVal = m_viewer.get_selected_string();
		HGLOBAL global = GlobalAlloc( GMEM_MOVEABLE, (sVal.GetLength() + 1) * sizeof( wchar_t ) );
		wchar_t *wsTxt = (wchar_t *)GlobalLock( global );
		wcscpy( wsTxt, sVal );
		GlobalUnlock( global );
		SetClipboardData( CF_UNICODETEXT, global );
		CloseClipboard();
	}
}

void CPDFReaderView::OnUpdateEditCopy(CCmdUI *pCmdUI)
{
	if( m_viewStyle > 4 )
		pCmdUI->Enable( FALSE );
	else
	{
		CString sVal = m_viewer.get_selected_string();
		pCmdUI->Enable( sVal.GetAt(0) );
	}
}

void CPDFReaderView::OnFileProperty()
{
	CDlgProperty dlg;
	dlg.m_sVer = m_doc->get_meta_data( _T("#ver") );
	dlg.m_iPages = m_doc->get_page_count();
	dlg.m_sTitle = m_doc->get_meta_data( _T("Title") );
	dlg.m_sProducer = m_doc->get_meta_data( _T("Producer") );
	dlg.m_sCreator = m_doc->get_meta_data( _T("Creator") );
	dlg.m_sAuthor = m_doc->get_meta_data( _T("Author") );
	dlg.m_sKeywords = m_doc->get_meta_data( _T("Keywords") );
	dlg.m_sFileName = GetDocument()->GetPathName();
	dlg.DoModal();
}

void CPDFReaderView::OnUpdateFindCase(CCmdUI *pCmdUI)
{
	if( m_viewStyle > 4 )
		pCmdUI->Enable( FALSE );
	else
	{
		pCmdUI->Enable( TRUE );
		pCmdUI->SetCheck( m_findCase );
	}
}

void CPDFReaderView::OnFindCase()
{
	m_findCase = !m_findCase;
}

void CPDFReaderView::OnUpdateFindWholeword(CCmdUI *pCmdUI)
{
	if( m_viewStyle > 4 )
		pCmdUI->Enable( FALSE );
	else
	{
		pCmdUI->Enable( TRUE );
		pCmdUI->SetCheck( m_findWholeWord );
	}
}

void CPDFReaderView::OnFindWholeword()
{
	m_findWholeWord = !m_findWholeWord;
}

#define WND_FIND_GAP 20
void CPDFReaderView::OnEditFind()
{
	OnInternalFinddown();
}

void CPDFReaderView::OnInternalFindup()
{
	CString str;
	m_pTView->get_text_find( str );
	if( str.IsEmpty() ) return;//do nothing
	if( m_findStatus ) return;
	m_findStatus = TRUE;
	if( m_sFind != str )
	{
		m_sFind = str;
		m_findPage = m_doc->get_page_count() + 1;
		m_findObj = 0;
	}
	m_findUp = true;
	m_finder = m_viewer.find( str, m_findPage, m_findObj, m_findUp, m_findCase, m_findWholeWord );
	RECT rcClient;
	GetClientRect( &rcClient );
	RECT rcWnd;
	m_dlgFind.GetWindowRect( &rcWnd );
	m_dlgFind.m_session = m_finder;
	m_dlgFind.m_iMode = 0;
	rcClient.left = rcClient.right - (rcWnd.right - rcWnd.left) - WND_FIND_GAP;
	rcClient.top = rcClient.bottom - (rcWnd.bottom - rcWnd.top) - WND_FIND_GAP;
	rcClient.right = rcClient.left + (rcWnd.right - rcWnd.left);
	rcClient.bottom = rcClient.top + (rcWnd.bottom - rcWnd.top);
	m_dlgFind.SetProg( m_findPage, m_doc->get_page_count() );
	COLORREF color;
	::OleTranslateColor( m_viewer.get_BackColor(), NULL, &color );
	m_dlgFind.SetBkColor( color );
	m_dlgFind.MoveWindow( &rcClient );
	m_dlgFind.ShowWindow( SW_SHOW );
}

void CPDFReaderView::OnInternalFinddown()
{
	CString str;
	m_pTView->get_text_find( str );
	if( str.IsEmpty() ) return;//do nothing
	if( m_findStatus ) return;
	m_findStatus = TRUE;
	if( m_sFind != str )
	{
		m_sFind = str;
		m_findPage = 0;
		m_findObj = 0;
	}
	m_findUp = false;
	m_finder = m_viewer.find( str, m_findPage, m_findObj, m_findUp, m_findCase, m_findWholeWord );
	RECT rcClient;
	GetClientRect( &rcClient );
	RECT rcWnd;
	m_dlgFind.GetWindowRect( &rcWnd );
	m_dlgFind.m_session = m_finder;
	rcClient.left = rcClient.right - (rcWnd.right - rcWnd.left) - WND_FIND_GAP;
	rcClient.top = rcClient.bottom - (rcWnd.bottom - rcWnd.top) - WND_FIND_GAP;
	rcClient.right = rcClient.left + (rcWnd.right - rcWnd.left);
	rcClient.bottom = rcClient.top + (rcWnd.bottom - rcWnd.top);
	m_dlgFind.m_iMode = 0;
	m_dlgFind.SetProg( m_findPage, m_doc->get_page_count() );
	COLORREF color;
	::OleTranslateColor( m_viewer.get_BackColor(), NULL, &color );
	m_dlgFind.SetBkColor( color );
	m_dlgFind.MoveWindow( &rcClient );
	m_dlgFind.ShowWindow( SW_SHOW );
}

void CPDFReaderView::OnFileSaveAs()
{
	if( m_findStatus ) return;
	CFileDialog dlg( FALSE, _T("*.txt"), NULL, 6, _T("Text Files(*.txt)|*.txt||") );
	if( dlg.DoModal() != IDOK ) return;
	m_findStatus = TRUE;
	m_finder = m_doc->save_as( dlg.GetPathName(), 0 );
	RECT rcClient;
	GetClientRect( &rcClient );
	RECT rcWnd;
	m_dlgFind.GetWindowRect( &rcWnd );
	m_dlgFind.m_session = m_finder;
	rcClient.left = rcClient.right - (rcWnd.right - rcWnd.left) - WND_FIND_GAP;
	rcClient.top = rcClient.bottom - (rcWnd.bottom - rcWnd.top) - WND_FIND_GAP;
	rcClient.right = rcClient.left + (rcWnd.right - rcWnd.left);
	rcClient.bottom = rcClient.top + (rcWnd.bottom - rcWnd.top);
	m_dlgFind.m_iMode = 1;
	m_dlgFind.SetProg( 0, m_doc->get_page_count() );
	COLORREF color;
	OleTranslateColor( m_viewer.get_BackColor(), NULL, &color );
	m_dlgFind.SetBkColor( color );
	m_dlgFind.MoveWindow( &rcClient );
	m_dlgFind.ShowWindow( SW_SHOW );
}

void CPDFReaderView::OnToolAddshortcuts()
{
	CDlgShortcut dlg;
	dlg.m_bAddFromView = TRUE;
	dlg.m_sPath = GetDocument()->GetPathName();
	if( dlg.DoModal() != IDOK ) return;
	int count = theApp.GetProfileInt( _T("Shortcuts"), _T("Count"), 0 );
	CString key;
	key.Format( _T("name%02d"), count );
	theApp.WriteProfileString( _T("Shortcuts"), key, dlg.m_sName );
	key.Format( _T("path%02d"), count );
	theApp.WriteProfileString( _T("Shortcuts"), key, dlg.m_sPath );
	count++;
	theApp.WriteProfileInt( _T("Shortcuts"), _T("Count"), count );
}

void CPDFReaderView::OnViewAutoscroll()
{
	if( m_bAutoScroll )
	{
		m_bAutoScroll = FALSE;
		KillTimer( 200 );
	}
	else
	{
		SetTimer( 200, 50, NULL );
		m_bAutoScroll = TRUE;
	}
}

void CPDFReaderView::OnViewLineDown()
{
	if( m_viewStyle < 5 )
		m_viewer.scroll_line_down();
}

void CPDFReaderView::OnViewLineUp()
{
	if( m_viewStyle < 5 )
		m_viewer.scroll_line_up();
}

void CPDFReaderView::OnViewPageDown()
{
	if( m_viewStyle < 5 )
		m_viewer.scroll_page_down();
}

void CPDFReaderView::OnViewPageUp()
{
	if( m_viewStyle < 5 )
		m_viewer.scroll_page_up();
}

void CPDFReaderView::OnUpdateViewAutoscroll(CCmdUI *pCmdUI)
{
	if( m_viewStyle > 4 )
		pCmdUI->Enable( FALSE );
	else
	{
		pCmdUI->Enable( TRUE );
		pCmdUI->SetCheck( m_bAutoScroll );
	}
}

void CPDFReaderView::OnKillFocus(CWnd* pNewWnd)
{
	if( m_bAutoScroll ) KillTimer( 200 );
	CView::OnKillFocus(pNewWnd);
}

void CPDFReaderView::OnSaveClipboard()
{
	m_viewer.save_snapshot_to_clipboard();
}

void CPDFReaderView::OnSaveFile()
{
	CFileDialog dlg( FALSE, _T("*.bmp"), NULL, 6, _T("Bitmap Files(*.bmp)|*.bmp||") );
	if( dlg.DoModal() != IDOK ) return;
	if( !m_viewer.save_snapshot_to_file(dlg.GetPathName()) )
			MessageBox( _T("Can't create the file!") );
}

void CPDFReaderView::OnEditSaveimage()
{
	CFileDialog dlg( FALSE, _T("*.bmp"), NULL, 6, _T("Bitmap Files(*.bmp)|*.bmp||") );
	if( dlg.DoModal() != IDOK ) return;
	if( !m_viewer.save_page_from_point( m_iSavePage, dlg.GetPathName() ) )
		MessageBox( _T("Can't create the file!") );
}

void CPDFReaderView::OnUpdateEditSaveimage(CCmdUI *pCmdUI)
{
	if( m_viewStyle > 4 )
		pCmdUI->Enable( FALSE );
	else
	{
		pCmdUI->Enable( TRUE );
		pCmdUI->Enable( m_doc && m_iSavePage > 0 && m_iSavePage <= m_doc->get_page_count() );
	}
}

void CPDFReaderView::do_print( HANDLE prn, int page_start, int page_end, int copies, int align, int arrange )
{
	m_dlgPrint.printer = prn;
	wcscpy( m_dlgPrint.wsTitle, GetDocument()->GetTitle() );
	m_dlgPrint.doc = m_doc;
	m_dlgPrint.page_start = page_start;
	m_dlgPrint.page_end = page_end;
	m_dlgPrint.copies = copies;
	m_dlgPrint.align = align;
	m_dlgPrint.arrange = arrange;
	m_dlgPrint.DoModal();
}

void CPDFReaderView::OnFileSaveCopy()
{
	if( m_findStatus ) return;
	CDlgSave dlg;
	if( dlg.DoModal() != IDOK ) return;
	if( !m_doc->save_copy( dlg.m_sDest, dlg.m_bRemPassword ) )
		MessageBox( _T("Save failed!") );
}
