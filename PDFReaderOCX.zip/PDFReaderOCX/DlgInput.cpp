// DlgInput.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "DlgInput.h"


// CDlgInput �Ի���

IMPLEMENT_DYNAMIC(CDlgInput, CDialog)

CDlgInput::CDlgInput(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgInput::IDD, pParent)
{

}

CDlgInput::~CDlgInput()
{
}

void CDlgInput::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgInput, CDialog)
END_MESSAGE_MAP()


// CDlgInput ��Ϣ��������

void CDlgInput::OnOK()
{
	GetDlgItemText( IDC_EDIT_CONTENT, m_sContent );
	CDialog::OnOK();
}
