// PDFReaderDoc.h : interface of the CPDFReaderDoc class
//

#pragma once
#include "PDFWnd.h"


class CPDFReaderDoc : public CDocument
{
protected: // create from serialization only
	CPDFReaderDoc();
	DECLARE_DYNCREATE(CPDFReaderDoc)

// Attributes
public:
	CPDFDocument *GetRDDoc(){return &m_doc;}
// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CPDFReaderDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CPDFDocument m_doc;
	CPDFUrlBuffer m_url;
// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	virtual void OnCloseDocument();
};


