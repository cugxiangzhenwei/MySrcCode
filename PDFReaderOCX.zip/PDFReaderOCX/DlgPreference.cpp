// DlgPreference.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "DlgPreference.h"


// CDlgPreference �Ի���

IMPLEMENT_DYNAMIC(CDlgPreference, CDialog)

CDlgPreference::CDlgPreference(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgPreference::IDD, pParent)
{

}

CDlgPreference::~CDlgPreference()
{
}

void CDlgPreference::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_BUTTON_BPAGE, m_btnBackPage);
	DDX_Control(pDX, IDC_BUTTON_BVIEWER, m_btnBack);
	DDX_Control(pDX, IDC_COMBO_LAYOUT, m_cLayout);
	DDX_Control(pDX, IDC_COMBO_RATIO, m_cRatio);
	DDX_Control(pDX, IDC_COMBO_TOOL, m_cTool);
	DDX_Control(pDX, IDC_COMBO_ACTIVE, m_cActive);
	DDX_Control(pDX, IDC_COMBO_PARA1, m_cParas1);
	DDX_Control(pDX, IDC_STATIC_PARA1, m_sDisp1);
	DDX_Control(pDX, IDC_COMBO_PARA2, m_cParas2);
	DDX_Control(pDX, IDC_STATIC_PARA2, m_sDisp2);
}


BEGIN_MESSAGE_MAP(CDlgPreference, CDialog)
	ON_BN_CLICKED(IDOK, &CDlgPreference::OnBnClickedOk)
	ON_BN_CLICKED(IDC_CHECK_OUTLINE, &CDlgPreference::OnBnClickedCheckOutline)
	ON_BN_CLICKED(IDC_CHECK_THUMB, &CDlgPreference::OnBnClickedCheckThumb)
	ON_CBN_SELCHANGE(IDC_COMBO_LAYOUT, &CDlgPreference::OnCbnSelchangeComboLayout)
END_MESSAGE_MAP()


// CDlgPreference ��Ϣ��������

void CDlgPreference::OnBnClickedOk()
{
	theApp.m_preference.pageLayout = m_cLayout.GetCurSel() + 1;
	switch( theApp.m_preference.pageLayout - 1 )
	{
	case 2:
		theApp.m_preference.pageLayoutPara3 = m_cParas1.GetCurSel();
		if( m_cParas2.GetCurSel() )
			theApp.m_preference.pageLayoutPara3 &= 0xff;
		else
			theApp.m_preference.pageLayoutPara3 |= 0x100;
		break;
	case 3:
		theApp.m_preference.pageLayoutPara4 = m_cParas1.GetCurSel();
		if( m_cParas2.GetCurSel() )
			theApp.m_preference.pageLayoutPara4 &= 0xff;
		else
			theApp.m_preference.pageLayoutPara4 |= 0x100;
		break;
	case 5:
		if( m_cParas1.GetCurSel() == 0 )
			theApp.m_preference.pageLayoutPara5 = 1;
		else
			theApp.m_preference.pageLayoutPara5 = -1;
		break;
	default:
		break;
	}

	CString sVal;
	m_cRatio.GetWindowText( sVal );
	if( sVal == _T("fit width") )
		theApp.m_preference.viewRatio = 0;
	else if( sVal == _T("fit page") )
		theApp.m_preference.viewRatio = -1;
	else
	{
		theApp.m_preference.viewRatio = _tstof( sVal )/100;
		if( theApp.m_preference.viewRatio < .1 )
			theApp.m_preference.viewRatio = .1;
		if( theApp.m_preference.viewRatio > 8 )
			theApp.m_preference.viewRatio = 8;
	}
	theApp.m_preference.pageTool = m_cTool.GetCurSel();
	theApp.m_preference.viewActive = m_cActive.GetCurSel() + 1;
	theApp.m_preference.clrBack = m_btnBack.GetColor();
	if( theApp.m_preference.clrBack == 0xFFFFFFFF )
		theApp.m_preference.clrBack = m_btnBack.GetAutomaticColor();
	theApp.m_preference.clrBack_Page = m_btnBackPage.GetColor();
	if( theApp.m_preference.clrBack_Page == 0xFFFFFFFF )
		theApp.m_preference.clrBack_Page = m_btnBackPage.GetAutomaticColor();
	theApp.m_preference.showOutline = IsDlgButtonChecked( IDC_CHECK_OUTLINE );
	theApp.m_preference.showThumbNails = IsDlgButtonChecked( IDC_CHECK_THUMB );
	theApp.SavePreference();
	OnOK();
}

BOOL CDlgPreference::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_cLayout.AddString( _T("Single") );
	m_cLayout.AddString( _T("Continuous") );
	m_cLayout.AddString( _T("Folio") );
	m_cLayout.AddString( _T("Folio Continuous") );
	m_cLayout.AddString( _T("Roll papers like a book") );
	m_cLayout.AddString( _T("Roll pages") );
	m_cRatio.AddString( _T("10%") );
	m_cRatio.AddString( _T("30%") );
	m_cRatio.AddString( _T("50%") );
	m_cRatio.AddString( _T("70%") );
	m_cRatio.AddString( _T("100%") );
	m_cRatio.AddString( _T("150%") );
	m_cRatio.AddString( _T("200%") );
	m_cRatio.AddString( _T("300%") );
	m_cRatio.AddString( _T("fit width") );
	m_cRatio.AddString( _T("fit page") );
	m_cTool.AddString( _T("drag") );
	m_cTool.AddString( _T("selection") );
	m_cActive.AddString( _T("Bookmarks view") );
	m_cActive.AddString( _T("Thumb nails view") );

	m_cLayout.SetCurSel( theApp.m_preference.pageLayout - 1 );
	if( theApp.m_preference.viewRatio == 0 )
		m_cRatio.SelectString( -1, _T("fit width") );
	else if( theApp.m_preference.viewRatio < 0 )
		m_cRatio.SelectString( -1, _T("fit page") );
	else
	{
		CString sVal;
		int ratio = theApp.m_preference.viewRatio * 1000;
		if( ratio % 10 )
		{
			sVal.Format( _T("%d.%d%%"), ratio/100, ratio % 10 );
			m_cRatio.SetWindowText( sVal );
		}
		else
		{
			sVal.Format( _T("%d%%"), ratio/10 );
			m_cRatio.SetWindowText( sVal );
		}
	}
	m_cTool.SetCurSel( theApp.m_preference.pageTool );
	m_cActive.SetCurSel( theApp.m_preference.viewActive - 1 );
	m_btnBack.EnableAutomaticButton( _T("Default"), RGB(160,192,255) );
	m_btnBack.EnableOtherButton( _T("Others") );
	m_btnBack.SetColor( theApp.m_preference.clrBack );
	m_btnBackPage.EnableAutomaticButton( _T("Default"), RGB(255,255,255) );
	m_btnBackPage.EnableOtherButton( _T("Others") );
	m_btnBackPage.SetColor( theApp.m_preference.clrBack_Page );
	CheckDlgButton( IDC_CHECK_OUTLINE, theApp.m_preference.showOutline );
	CheckDlgButton( IDC_CHECK_THUMB, theApp.m_preference.showThumbNails );
	m_cActive.EnableWindow( theApp.m_preference.showOutline && theApp.m_preference.showThumbNails );
	OnCbnSelchangeComboLayout();
	return TRUE;
}

void CDlgPreference::OnBnClickedCheckOutline()
{
	m_cActive.EnableWindow( IsDlgButtonChecked( IDC_CHECK_OUTLINE ) && IsDlgButtonChecked( IDC_CHECK_THUMB ) );
}

void CDlgPreference::OnBnClickedCheckThumb()
{
	m_cActive.EnableWindow( IsDlgButtonChecked( IDC_CHECK_OUTLINE ) && IsDlgButtonChecked( IDC_CHECK_THUMB ) );
}

void CDlgPreference::OnCbnSelchangeComboLayout()
{
	switch( m_cLayout.GetCurSel() )
	{
	case 2:
		m_sDisp1.SetWindowText( _T("Show cover:") );
		m_cParas1.ResetContent();
		m_cParas1.EnableWindow( true );
		m_cParas1.AddString( _T("as normal page.") );
		m_cParas1.AddString( _T("as single page.") );
		m_cParas1.SetCurSel( theApp.m_preference.pageLayoutPara3&0xff );

		m_sDisp2.SetWindowText( _T("Direction:") );
		m_cParas2.ResetContent();
		m_cParas2.EnableWindow( true );
		m_cParas2.AddString( _T("Left to right.") );
		m_cParas2.AddString( _T("Right to left.") );
		m_cParas2.SetCurSel( (theApp.m_preference.pageLayoutPara3>>8)?0:1 );
		break;
	case 3:
		m_sDisp1.SetWindowText( _T("Show cover:") );
		m_cParas1.ResetContent();
		m_cParas1.EnableWindow( true );
		m_cParas1.AddString( _T("as normal page.") );
		m_cParas1.AddString( _T("as single page.") );
		m_cParas1.SetCurSel( theApp.m_preference.pageLayoutPara4&0xff );

		m_sDisp2.SetWindowText( _T("Direction:") );
		m_cParas2.ResetContent();
		m_cParas2.EnableWindow( true );
		m_cParas2.AddString( _T("Left to right.") );
		m_cParas2.AddString( _T("Right to left.") );
		m_cParas2.SetCurSel( (theApp.m_preference.pageLayoutPara4>>8)?0:1 );
		break;
	case 5:
		m_sDisp1.SetWindowText( _T("Roll papers:") );
		m_cParas1.ResetContent();
		m_cParas1.EnableWindow( true );
		m_cParas1.AddString( _T("Left to right.") );
		m_cParas1.AddString( _T("Right to left.") );
		m_cParas1.SetCurSel( theApp.m_preference.pageLayoutPara6 );
		m_sDisp2.SetWindowText( NULL );
		m_cParas2.ResetContent();
		m_cParas2.EnableWindow( false );
		break;
	default:
		m_sDisp1.SetWindowText( NULL );
		m_sDisp2.SetWindowText( NULL );
		m_cParas1.ResetContent();
		m_cParas1.EnableWindow( false );
		m_cParas2.ResetContent();
		m_cParas2.EnableWindow( false );
		break;
	}
}
