
// ChildFrm.h : interface of the CChildFrame class
//

#pragma once
#include "ViewOutline.h"
#include "ViewMini.h"

class CPDFReaderView;
class CChildFrame : public CMDIChildWndEx
{
	DECLARE_DYNCREATE(CChildFrame)
public:
	CChildFrame();
	void page_down();
	void page_up();
	void set_ratio( double ratio );
	double get_ratio();
	void goto_page( int page );
	void roll_papers( int papers );
	int get_pageno();
	void get_page_size_inch( int page, double &inch_width, double &inch_height );
	int get_page_count();
	void set_view_style( int style );
	int get_view_style();
	pdf_tool get_drag_mode();
	void set_drag_mode( pdf_tool mode );
	pdf_fit_mode get_fit_mode();
	void set_fit_mode( pdf_fit_mode mode );
	BOOL is_find_case();
	BOOL is_find_whole_word();
	void set_find_case( BOOL iscase );
	void set_find_whole_word( BOOL whole_word );
	CPDFDocument *get_doc();
	void do_print( HANDLE prn, int page_start, int page_end, int copies, int align, int arrange );

// Attributes
public:

// Operations
public:

// Overrides
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CChildFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	void proLoadPreference();
	CPDFReaderView *GetRDView();
	CMFCCaptionBar m_wndCaption;
	CViewOutline m_wndOutline;
	CViewMini m_wndMini;
// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	virtual LRESULT DefWindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	afx_msg void OnViewCaptionBar();
	afx_msg void OnUpdateViewCaptionBar(CCmdUI *pCmdUI);
	afx_msg void OnViewOutline();
	afx_msg void OnViewMini();
	afx_msg void OnUpdateViewOutline(CCmdUI *pCmdUI);
	afx_msg void OnUpdateViewMini(CCmdUI *pCmdUI);
};
