// DlgUrl.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "DlgUrl.h"


// CDlgUrl �Ի���

IMPLEMENT_DYNAMIC(CDlgUrl, CDialog)

CDlgUrl::CDlgUrl(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgUrl::IDD, pParent)
	, m_sUrl(_T(""))
{

}

CDlgUrl::~CDlgUrl()
{
}

void CDlgUrl::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_CONTENT, m_sUrl);
}


BEGIN_MESSAGE_MAP(CDlgUrl, CDialog)
	ON_BN_CLICKED(IDOK, &CDlgUrl::OnBnClickedOk)
END_MESSAGE_MAP()


// CDlgUrl ��Ϣ��������

void CDlgUrl::OnBnClickedOk()
{
	UpdateData();
	if( m_sUrl.Left( 7 ).CompareNoCase( _T("http://") ) )
		MessageBox( _T("Bad http link!") );
	else
		OnOK();
}
