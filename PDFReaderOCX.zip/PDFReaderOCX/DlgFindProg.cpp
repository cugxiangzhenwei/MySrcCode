// DlgFindProg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "PDFReader.h"
#include "DlgFindProg.h"
#include "PDFWnd.h"

// CDlgFindProg �Ի���

IMPLEMENT_DYNAMIC(CDlgFindProg, CDialog)

CDlgFindProg::CDlgFindProg(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgFindProg::IDD, pParent)
{
	m_clrBack = RGB(192,192,192);
	m_hBack = CreateSolidBrush( m_clrBack );
	m_iMode = 0;
}

CDlgFindProg::~CDlgFindProg()
{
	DeleteObject( m_hBack );
}

void CDlgFindProg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS_FIND, m_pFind);
}


BEGIN_MESSAGE_MAP(CDlgFindProg, CDialog)
	ON_BN_CLICKED(IDCANCEL, &CDlgFindProg::OnBnClickedCancel)
	ON_WM_CTLCOLOR()
	ON_WM_SETCURSOR()
END_MESSAGE_MAP()

void CDlgFindProg::SetProg( int page, int page_count )
{
	m_pFind.SetRange32( 0, page_count );
	m_pFind.SetPos( page );
	CString sVal;
	if( m_iMode == 0 )
		sVal.Format( _T("search in page %d of %d"), page, page_count );
	else
		sVal.Format( _T("saving page %d of %d"), page, page_count );
	SetDlgItemText( IDC_STATIC_PROMPT, sVal );
}

// CDlgFindProg ��Ϣ��������
void CDlgFindProg::OnBnClickedCancel()
{
	if( m_iMode == 0 )
		m_pViewer->cancel_find( m_session );
	else
		m_pDoc->cancel_session( m_session );
	ShowWindow( SW_HIDE );
}

HBRUSH CDlgFindProg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	if( nCtlColor == CTLCOLOR_DLG )
		return m_hBack;
	if( nCtlColor == CTLCOLOR_STATIC )
	{
		pDC->SetBkMode( TRANSPARENT );
		return m_hBack;
	}
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	return hbr;
}

BOOL CDlgFindProg::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	SetCursor( LoadCursor( NULL, IDC_ARROW ) );
	return TRUE;
	//return CDialog::OnSetCursor(pWnd, nHitTest, message);
}
