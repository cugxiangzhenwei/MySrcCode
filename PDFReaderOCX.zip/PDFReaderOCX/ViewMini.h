#pragma once
#include "PDFWnd.h"

// CViewMini

class CViewMini : public CDockablePane
{
	DECLARE_DYNAMIC(CViewMini)

public:
	CViewMini();
	virtual ~CViewMini();
	CPDFWndThumbs m_wndMini;
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


