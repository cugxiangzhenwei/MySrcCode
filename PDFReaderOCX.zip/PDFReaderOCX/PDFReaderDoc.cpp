
// PDFReaderDoc.cpp : implementation of the CPDFReaderDoc class
//

#include "stdafx.h"
#include "PDFReader.h"

#include "PDFReaderDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CPDFReaderDoc

IMPLEMENT_DYNCREATE(CPDFReaderDoc, CDocument)

BEGIN_MESSAGE_MAP(CPDFReaderDoc, CDocument)
END_MESSAGE_MAP()


// CPDFReaderDoc construction/destruction

CPDFReaderDoc::CPDFReaderDoc()
{
	// TODO: add one-time construction code here

}

CPDFReaderDoc::~CPDFReaderDoc()
{
}

BOOL CPDFReaderDoc::OnNewDocument()
{
	return FALSE;
	//if (!CDocument::OnNewDocument())
	//	return FALSE;
	return TRUE;
}


// CPDFReaderDoc serialization

void CPDFReaderDoc::Serialize(CArchive& ar)//���ú��������ᱻִ��
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CPDFReaderDoc diagnostics

#ifdef _DEBUG
void CPDFReaderDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPDFReaderDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

#include "DlgInput.h"
#include "DlgDownload.h"
// CPDFReaderDoc commands

BOOL CPDFReaderDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	//if (!CDocument::OnOpenDocument(lpszPathName))
	//	return FALSE;
	m_doc.Create();
	if( lpszPathName[1] != ':' )
	{
		m_url.Create();
		if( !m_url.open( lpszPathName ) )
		{
			AfxMessageBox( _T("Can't open the document!\nConnect failed or Invalid pdf file."), MB_ICONERROR );
			m_url.close();
			m_url.ReleaseDispatch();
			return FALSE;
		}
		if( m_url.get_is_support_rc() )
		{
			if( !m_doc.open_url( m_url.m_lpDispatch, NULL ) )
			{
				CDlgInput dlg;
				do
				{
					if( m_doc.get_error_code() != err_encrypted )
					{
						AfxMessageBox( _T("Can't open the document!\nConnect failed or Invalid pdf file."), MB_ICONERROR );
						return FALSE;
					}
					if( dlg.DoModal() != IDOK ) return FALSE;
				}while( !m_doc.open( lpszPathName, dlg.m_sContent ) );
			}
		}
		else//display the progress dialog
		{
			CDlgDownload download;
			download.m_url = &m_url;
			if( download.DoModal() != IDOK )
			{
				m_url.close();
				m_url.ReleaseDispatch();
				return FALSE;
			}
			if( !m_doc.open_url( m_url.m_lpDispatch, NULL ) )
			{
				CDlgInput dlg;
				do
				{
					if( m_doc.get_error_code() != err_encrypted )
					{
						AfxMessageBox( _T("Can't open the document!\nConnect failed or Invalid pdf file."), MB_ICONERROR );
						return FALSE;
					}
					if( dlg.DoModal() != IDOK ) return FALSE;
				}while( !m_doc.open( lpszPathName, dlg.m_sContent ) );
			}
		}
	}
	else
	{
		if( !m_doc.open( lpszPathName, NULL ) )
		{
			CDlgInput dlg;
			do
			{
				if( m_doc.get_error_code() != err_encrypted )
				{
					AfxMessageBox( _T("Can't open the document!\nFile locked or Invalid pdf file."), MB_ICONERROR );
					return FALSE;
				}
				if( dlg.DoModal() != IDOK ) return FALSE;
			}while( !m_doc.open( lpszPathName, dlg.m_sContent ) );
		}
	}
	// TODO:  �ڴ�������ר�õĴ�������
	//m_doc.set_mark( _T("F:\\001.jpg"), 0, 0, 300, 180, 2, 2, 3 );
	//m_doc.save_page( _T("d:\\test.bmp"), 1, 96, 96 );//96 DPI for screen

	/*
	void *data = m_doc.save_page_mem(1, 96, 96);//96 DPI for screen
	CFile file;
	if( file.Open( _T("D:\\test.bmp"), CFile::modeWrite|CFile::modeCreate ) )
	{
		BITMAPFILEHEADER *bfh = (BITMAPFILEHEADER *)data;
		file.Write( data, bfh->bfSize );
		file.Close();
	}
	m_doc.release_page_mem( data );//free memory.
	*/
	return TRUE;
}

void CPDFReaderDoc::OnCloseDocument()
{
	m_doc.close();
	m_doc.ReleaseDispatch();
	m_url.close();
	m_url.ReleaseDispatch();
	CDocument::OnCloseDocument();
}
