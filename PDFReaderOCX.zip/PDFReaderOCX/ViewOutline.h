#pragma once
#include "PDFWnd.h"

// CViewOutline

class CViewOutline : public CDockablePane
{
	DECLARE_DYNAMIC(CViewOutline)

public:
	CViewOutline();
	virtual ~CViewOutline();

	CPDFWndBMTree m_wndView;
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


